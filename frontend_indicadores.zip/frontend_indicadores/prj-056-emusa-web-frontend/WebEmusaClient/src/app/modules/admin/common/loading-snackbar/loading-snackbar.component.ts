import { Component, OnInit, Inject, Input } from "@angular/core";
import {
  MatSnackBarRef,
  MAT_SNACK_BAR_DATA
} from "@angular/material/snack-bar";
import { ProgressBar } from "app/shared/models/response/common/common-response.interface";
import { GeneralService } from "app/shared/services/common/general.service";

@Component({
  selector: 'app-loading-snackbar',
  templateUrl: './loading-snackbar.component.html',
  styleUrls: ['./loading-snackbar.component.scss']
})
export class LoadingSnackbarComponent implements OnInit {

  progressBar: ProgressBar = new ProgressBar();
  constructor(
    private _generalService : GeneralService,
    public sbRef: MatSnackBarRef<LoadingSnackbarComponent>,
    @Inject(MAT_SNACK_BAR_DATA) public data: any
  ) {
    
  }

  ngOnInit(): void {
    this._generalService.dispProgress.subscribe(data => {
      this.progressBar = data as ProgressBar;
    });
  }


}
