import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { Chart } from 'angular-highcharts';
import { GeneralPagination } from 'app/shared/models/response/common/general-response.interface';
import { IndicadorERI, IndicadorERICurrent, IndicadorERIResponse, TablaERIInd, TablaERIResponse } from 'app/shared/models/response/indicador/indicadores-response.interface';
import { ItemAlmacen, ListAlmacenResponse } from 'app/shared/models/response/reporte/almacen.interface';
import { ItemLinea, ListLineaResponse } from 'app/shared/models/response/reporte/linea.interface';
import { ItemSublinea, ListSublineaResponse } from 'app/shared/models/response/reporte/sublinea.interface';
import { IndicadorService } from 'app/shared/services/indicador/indicador.service';
import { ReporteService } from 'app/shared/services/reporte/reporte.service';
import { SeriesOptionsType } from 'highcharts';
import { cloneDeep } from 'lodash';
import { IndicadorERIRequest } from '../../../../shared/models/request/indicador/indicador-eri-request.interface';
import { Subject, takeUntil } from 'rxjs';
import { Sort } from '@angular/material/sort';

@Component({
  selector: 'app-exactitud-inventario',
  templateUrl: './exactitud-inventario.component.html',
  styleUrls: ['./exactitud-inventario.component.scss']
})
export class ExactitudInventarioComponent implements OnInit {

  chart: Chart;
  almacen: ItemAlmacen[]=[];
  linea: ItemLinea[]=[];
  sublinea: ItemSublinea[]=[];
  caForm: FormGroup;

  tbMPSource: TablaERIInd[] = [];
  tbMP: TablaERIInd[] = [];
  pagination: GeneralPagination;

  tbPP: TablaERIInd[] = [];
 
  tbPTSource: TablaERIInd[] = [];
  tbPT: TablaERIInd[] = [];
  paginationPT: GeneralPagination;


  currentState: IndicadorERICurrent = new IndicadorERICurrent();
  isLoading: boolean = false;
  isLoadingTb: boolean = false;

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: FormBuilder,
    private _reporteService: ReporteService,
    private _indicadorService: IndicadorService
  ) { }
  
  ngOnInit(): void {
    this.caForm = this._formBuilder.group({
      AlmacenSerie: [''],
      Linea: [''],
      SubLinea: [''],
      SubAlmacen: [''],
      TextLinea: [''],
      TextSubLinea: ['']
    });
    
    this.getAlmacen();
    this.getLinea();

    this.caForm.get('SubAlmacen').setValue('MP');
    this.getDataGraphic();
    this.getTablaERI();
  }

  refresh(){
    this.getDataGraphic();
    this.getTablaERI();
  }

  getLinea(): void{
    this._reporteService.obtenerLinea()
        .subscribe(
            (response: ListLineaResponse) => {
                this.linea = response.result.linea;
                this._changeDetectorRef.markForCheck();
                //console.log('Lineas kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
  }
  
  selectLinea(data: MatSelectChange){
      this.caForm.get('TextLinea').setValue(data.source.triggerValue);
      this.caForm.get('SubLinea').setValue('');
      this.getDataGraphic();
      this.getTablaERI();
      this.getSublinea(String(data.value));
  }

  selectSubLinea(data: MatSelectChange){
      this.caForm.get('TextSubLinea').setValue(data.source.triggerValue);
      this.getDataGraphic();
      this.getTablaERI();
  }
  
  getSublinea(codLinea: string): void{
      //console.log('Sublineas kardex',codLinea);
      this._reporteService.obtenerSublinea(codLinea)
          .subscribe(
              (response: ListSublineaResponse) => {
                  this.sublinea = response.result.sublinea;
                  this._changeDetectorRef.markForCheck();
                  // console.log('Sublineas kardex',codLinea);
                  // console.log('Sublineas kardex',response);
              },
              (error: HttpErrorResponse) => {
                  console.log(error);
              }
          );
  }
  
  getAlmacen(): void{
    this._reporteService.obtenerAlmacen()
        .subscribe(
            (response: ListAlmacenResponse) => {
                this.almacen = response.result.almacen;
                this._changeDetectorRef.markForCheck();
                //console.log('almacenes kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
  }

  cleanFilter(): void{
      this.caForm.get('AlmacenSerie').setValue(null);
      this.caForm.get('Linea').setValue('');
      this.caForm.get('SubLinea').setValue('');
  }

  init() {
    let chart = new Chart({
      chart: {
        type: 'line'
      },
      title: {
        text: 'Linechart'
      },
      credits: {
        enabled: false
      },
      series: [{
        name: 'Line 1',
        type: 'line',
        data: [1,2,3]
      }]
    });
    chart.addPoint(4);
    this.chart = chart;
    chart.addPoint(5);
    setTimeout(() => {
      chart.addPoint(6);
    }, 2000);

    chart.ref$.subscribe(console.log);
  }

  getDataGraphic() {
   
    this.isLoading = true;
    let request = new IndicadorERIRequest();
    request.almacen = this.caForm.get('AlmacenSerie').value != null ? this.caForm.get('AlmacenSerie').value : '';
    request.subAlmacen = this.caForm.get('SubAlmacen').value != null ? this.caForm.get('SubAlmacen').value : '';
    request.linea = this.caForm.get('Linea').value != null ? this.caForm.get('Linea').value : '';
    request.subLinea = this.caForm.get('SubLinea').value != null ? this.caForm.get('SubLinea').value : '';

    console.log('REQUEST PIE', request);
    this._indicadorService.ObtenerDatosERI(request)
    .subscribe(
      (response: IndicadorERIResponse) => {
       console.log('RESP INDICADOR', response);
       this.isLoading = false;
       
        this.loadChart(request, response.result);
      },
      (error: HttpErrorResponse) => {
        console.log(error);
        this.isLoading = false;
      }
    );

  }

  loadChart(param: IndicadorERIRequest, data: IndicadorERI){

    let series = this.getSeries(param, data);

    let chart = new Chart({
        chart: {
            type: 'pie'
        },
        title: {
            text: null,
            align: 'center'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.value}</b>'
        },
        accessibility: {
              announceNewData: {
                enabled: true
            },
            point: {
                valueSuffix: '%'
            }
        },
        plotOptions: {
            series: {
              dataLabels: {
                  enabled: true,
                  format: '{point.name}: {point.y:.1f}%'
              }
          }
        },
        series: [{    type: 'pie',
                      name: 'Exactitud de registro',
                      colorByPoint: true,
                      data: series
                  }]
    });
    this.chart = chart;

  }

  getSeries(param: IndicadorERIRequest, data: IndicadorERI) : any[] {
    
    let perCnt = 0;
    let perOthers = 0;

    let totalValues6 = 0;
    let perInsumoAvance = 0;
    let perInsumoFalta = 0;
    let perMateriaPrimaAvance = 0;
    let perMateriaPrimaFalta = 0;
    let perSuministroAvance = 0;
    let perSuministroFalta = 0;

    let totalValues4 = 0;
    let perProductoTerminadoInventariado = 0;
    let perProductoTerminadoNoInventariado = 0;
    let perMuestraVentaInventariada = 0;
    let perMuestraVentaNoInventariada = 0;

    let series = [];

    if(param.subAlmacen == 'MP'){

      let type = param.linea == '' ? 'values_6' : 'values_2'
      switch (type) {
        case 'values_6':
          totalValues6 = (data.insumoAvance + data.insumoFalta + data.materiaPrimaAvance + data.materiaPrimaFalta + data.suministroAvance + data.suministroFalta);
          perInsumoAvance = Number(((data.insumoAvance * 100) / totalValues6).toFixed(2));
          perInsumoFalta = Number(((data.insumoFalta * 100) / totalValues6).toFixed(2));
          perMateriaPrimaAvance = Number(((data.materiaPrimaAvance * 100) / totalValues6).toFixed(2));
          perMateriaPrimaFalta = Number(((data.materiaPrimaFalta * 100) / totalValues6).toFixed(2));
          perSuministroAvance = Number(((data.suministroAvance * 100) / totalValues6).toFixed(2));
          perSuministroFalta = Number(((data.suministroFalta * 100) / totalValues6).toFixed(2));
  
          if(data.suministroAvance > 0){
            series.push({
              name: 'Suministros <br> Invent.',
              y: perSuministroAvance,
              color: '#ff960d',
              value: data.suministroAvance
            });
          }
          
          if(data.suministroFalta > 0){
            series.push({
              name: 'Suministros <br> No Invent.',
              y: perSuministroFalta,
              color: '#f24b4b',
              value: data.suministroFalta
            });
          }

          if(data.insumoAvance > 0){
            series.push({
              name: 'Insumos <br> Invent.',
              y: perInsumoAvance,
              color: '#61d476',
              value: data.insumoAvance
            });
          }
          
          if(data.insumoFalta > 0){
            series.push({
              name: 'Insumos <br> No Invent.',
              y: perInsumoFalta,
              color: '#f24b4b',
              value: data.insumoFalta
            });
          }
          
          if(data.materiaPrimaAvance > 0){
            series.push({
              name: 'Materia Prima <br> Invent.',
              y: perMateriaPrimaAvance,
              color: '#1b1fe3',
              value: data.materiaPrimaAvance
            });
          }
          
          if(data.materiaPrimaFalta > 0){
            series.push({
              name: 'Materia Prima <br> No Invent.',
              y: perMateriaPrimaFalta,
              color: '#f24b4b',
              value: data.materiaPrimaFalta
            });
          }
          
          // series = [{
          //             name: 'Suministros <br> Invent.',
          //             y: perSuministroAvance,
          //             color: '#ff960d',
          //             value: data.suministroAvance
          //           },{
          //             name: 'Suministros <br> No Invent.',
          //             y: perSuministroFalta,
          //             color: '#f24b4b',
          //             value: data.suministroFalta
          //           },{
          //             name: 'Insumos <br> Invent.',
          //             y: perInsumoAvance,
          //             color: '#61d476',
          //             value: data.insumoAvance
          //           },{
          //             name: 'Insumos <br> No Invent.',
          //             y: perInsumoFalta,
          //             color: '#f24b4b',
          //             value: data.insumoFalta
          //           },{
          //             name: 'Materia Prima <br> Invent.',
          //             y: perMateriaPrimaAvance,
          //             color: '#1b1fe3',
          //             value: data.materiaPrimaAvance
          //           },{
          //             name: 'Materia Prima <br> No Invent.',
          //             y: perMateriaPrimaFalta,
          //             color: '#f24b4b',
          //             value: data.materiaPrimaFalta
          //           }];
  
          break;
        case 'values_2':
          perCnt = Number(((data.cantidad * 100) / data.total).toFixed(2));
          perOthers = Number((100 - perCnt).toFixed(2));
  
          let name = param.subLinea == '' ? this.linea.find(l => l.lineaCodigo == param.linea).lineaDescripcion : this.sublinea.find(s => s.sublineaCodigo == param.subLinea).sublineaDescripcion;

          if(data.cantidad > 0){
            series.push({
              name: `${name} <br> Inventariadas`,
              y: perCnt,
              color: '#61d476',
              value: data.cantidad
            });
          }
          
          if((data.total - data.cantidad) > 0){
              series.push({
                name: `${name} <br> No Inventariadas`,
                y: perOthers,
                color: '#f24b4b',
                value: data.total - data.cantidad
            });
          }

          // series = [{
          //               name: `${name} <br> Inventariadas`,
          //               y: perCnt,
          //               color: '#61d476',
          //               value: data.cantidad
          //             },{
          //               name: `${name} <br> No Inventariadas`,
          //               y: perOthers,
          //               color: '#f24b4b',
          //               value: data.total - data.cantidad
          //           }];
  
          break;
      }

    }else if(param.subAlmacen == 'PP'){

          perCnt = Number(((data.cantidad * 100) / data.total).toFixed(2));
          perOthers = Number((100 - perCnt).toFixed(2));
  
          let name = '';
          if(param.linea == ''){
            name = 'Productos en Proceso';
          }else{
            name = param.subLinea == '' ? this.linea.find(l => l.lineaCodigo == param.linea).lineaDescripcion : this.sublinea.find(s => s.sublineaCodigo == param.subLinea).sublineaDescripcion;
          }

          if((data.total - data.cantidad) > 0){
            series.push({
              name: `${name} <br> Inventariadas`,
              y: perOthers,
              color: '#61d476',
              value: data.total - data.cantidad
            });
          }

          if(data.cantidad > 0){
              series.push({
                name: `${name} <br> No Inventariadas`,
                y: perCnt,
                color: '#f24b4b',
                value: data.cantidad
            });
          }

          // series = [{
          //               name: `${name} <br> Inventariadas`,
          //               y: perOthers,
          //               color: '#61d476',
          //               value: data.total - data.cantidad
          //             },{
          //               name: `${name} <br> No Inventariadas`,
          //               y: perCnt,
          //               color: '#f24b4b',
          //               value: data.cantidad
          //           }];
  
    }else{
      let type = param.linea == '' ? 'values_4' : 'values_2'
      switch (type) {
        case 'values_4':
          totalValues4 = (data.productoTerminadoInventariado + data.productoTerminadoNoInventariado + data.muestraVentaInventariada + data.muestraVentaNoInventariada);
          perProductoTerminadoInventariado = Number(((data.productoTerminadoInventariado * 100) / totalValues4).toFixed(2));
          perProductoTerminadoNoInventariado = Number(((data.productoTerminadoNoInventariado * 100) / totalValues4).toFixed(2));
          perMuestraVentaInventariada = Number(((data.muestraVentaInventariada * 100) / totalValues4).toFixed(2));
          perMuestraVentaNoInventariada = Number(((data.muestraVentaNoInventariada * 100) / totalValues4).toFixed(2));
  
          if(data.productoTerminadoInventariado > 0){
            series.push({
              name: 'Producto Terminado <br> Inventariado',
              y: perProductoTerminadoInventariado,
              color: '#ff960d',
              value: data.productoTerminadoInventariado
            });
          }
          
          if(data.productoTerminadoNoInventariado > 0){
            series.push({
              name: 'Producto Terminado <br> No Inventariado',
              y: perProductoTerminadoNoInventariado,
              color: '#f24b4b',
              value: data.productoTerminadoNoInventariado
            });
          }
          
          if(data.muestraVentaInventariada > 0){
            series.push({
              name: 'Muestra Para Venta <br> Inventariada',
              y: perMuestraVentaInventariada,
              color: '#61d476',
              value: data.muestraVentaInventariada
            });
          }
          
          if(data.muestraVentaNoInventariada > 0){
            series.push({
              name: 'Muestra Para Venta <br> No Inventariada',
              y: perMuestraVentaNoInventariada,
              color: '#f24b4b',
              value: data.muestraVentaNoInventariada
            });
          }
          

          // series = [{
          //             name: 'Producto Terminado <br> Inventariado',
          //             y: perProductoTerminadoInventariado,
          //             color: '#ff960d',
          //             value: data.productoTerminadoInventariado
          //           },{
          //             name: 'Producto Terminado <br> No Inventariado',
          //             y: perProductoTerminadoNoInventariado,
          //             color: '#f24b4b',
          //             value: data.productoTerminadoNoInventariado
          //           },{
          //             name: 'Muestra Para Venta <br> Inventariada',
          //             y: perMuestraVentaInventariada,
          //             color: '#61d476',
          //             value: data.muestraVentaInventariada
          //           },{
          //             name: 'Muestra Para Venta <br> No Inventariada',
          //             y: perMuestraVentaNoInventariada,
          //             color: '#f24b4b',
          //             value: data.muestraVentaNoInventariada
          //           }];
  
          break;
        case 'values_2':
          perCnt = Number(((data.cantidad * 100) / data.total).toFixed(2));
          perOthers = Number((100 - perCnt).toFixed(2));
  
          let name = param.subLinea == '' ? this.linea.find(l => l.lineaCodigo == param.linea).lineaDescripcion : this.sublinea.find(s => s.sublineaCodigo == param.subLinea).sublineaDescripcion;

          if(data.cantidad > 0){
            series.push({
              name: `${name} <br> Inventariadas`,
              y: perCnt,
              color: '#61d476',
              value: data.cantidad
            });
          }
          
          if((data.total - data.cantidad) > 0){
            series.push({
                name: `${name} <br> No Inventariadas`,
                y: perOthers,
                color: '#f24b4b',
                value: data.total - data.cantidad
            });
          }
          

          // series = [{
          //               name: `${name} <br> Inventariadas`,
          //               y: perCnt,
          //               color: '#61d476',
          //               value: data.cantidad
          //             },{
          //               name: `${name} <br> No Inventariadas`,
          //               y: perOthers,
          //               color: '#f24b4b',
          //               value: data.total - data.cantidad
          //           }];
  
          break;
      }
    }

    return series;
  }

  getTablaERI() {
   
    this.isLoadingTb = true;
    let request = new IndicadorERIRequest();
    request.almacen = this.caForm.get('AlmacenSerie').value != null ? this.caForm.get('AlmacenSerie').value : '';
    request.subAlmacen = this.caForm.get('SubAlmacen').value != null ? this.caForm.get('SubAlmacen').value : '';

    console.log('REQUEST TABLA ERI', request);
    this._indicadorService.ObtenerDatosTablaERI(request)
    .subscribe(
      (response: TablaERIResponse) => {
       console.log('RESP TABLA ERI', response);
       this.isLoadingTb = false;
       if(response.result != null){
        
        switch (request.subAlmacen) {
          case 'MP':
            this.tbMPSource = response.result;
            this.getPageTablaMP();
            this.tbPP = [];
            this.tbPTSource = [];
            this.tbPT = [];
            break;        
          case 'PP':
            this.tbPP = [{ cantidad: response.result[0].cantidad, peso: response.result[0].peso }]
            this.tbMPSource = [];
            this.tbMP = [];
            this.tbPTSource = [];
            this.tbPT = [];
            break;
          case 'PT':
            this.tbPTSource = response.result;
            this.getPageTablaPT();
            this.tbMPSource = [];
            this.tbMP = [];
            this.tbPP = [];
            break;
        }
       }else{
        this.tbMPSource = [];
        this.tbMP = [];
        this.tbPP = [];
        this.tbPTSource = [];
        this.tbPT = [];
       }
      },
      (error: HttpErrorResponse) => {
        console.log(error);
        this.isLoadingTb = false;
      }
    );

  }

  getPageTablaMP(page: number = 0, size: number = 10): void{
    page = page ?? 1, 10;

    let data: TablaERIInd[] | null = cloneDeep(this.tbMPSource);

              const dataLength = data.length;

              const begin = page * size;
              const end = Math.min((size * (page + 1)), dataLength);
              const lastPage = Math.max(Math.ceil(dataLength / size), 1);

              let pagination = {};

              if ( page > lastPage )
              {
                  data = null;
                  pagination = {
                      lastPage
                  };
              }
              else
              {
                  data = data.slice(begin, end);

                  pagination = {
                      length    : dataLength,
                      size      : size,
                      page      : page,
                      lastPage  : lastPage,
                      startIndex: begin,
                      endIndex  : end - 1
                  };
              }
        this.tbMP = data;
        this.pagination = pagination as GeneralPagination;
  }

  handlePageMP(e: PageEvent): PageEvent {
    this.getPageTablaMP(e.pageIndex, e.pageSize);
    return e;
  }

  getPageTablaPT(page: number = 0, size: number = 10): void{
    page = page ?? 1, 10;

    let data: TablaERIInd[] | null = cloneDeep(this.tbPTSource);

              const dataLength = data.length;

              const begin = page * size;
              const end = Math.min((size * (page + 1)), dataLength);
              const lastPage = Math.max(Math.ceil(dataLength / size), 1);

              let pagination = {};

              if ( page > lastPage )
              {
                  data = null;
                  pagination = {
                      lastPage
                  };
              }
              else
              {
                  data = data.slice(begin, end);

                  pagination = {
                      length    : dataLength,
                      size      : size,
                      page      : page,
                      lastPage  : lastPage,
                      startIndex: begin,
                      endIndex  : end - 1
                  };
              }
        this.tbPT = data;
        this.paginationPT = pagination as GeneralPagination;
  }

  handlePagePT(e: PageEvent): PageEvent {
    this.getPageTablaPT(e.pageIndex, e.pageSize);
    return e;
  }

  eventSortTableMP(sort: Sort){
    switch (sort.active) {
      case 'Origen':
        this.tbMPSource = sort.direction == 'asc' ?
                          this.tbMPSource.sort((a,b) => a.origenDescripcion.toString().toUpperCase().localeCompare(b.origenDescripcion.toString().toUpperCase())) :
                          this.tbMPSource.sort((a,b) => b.origenDescripcion.toString().toUpperCase().localeCompare(a.origenDescripcion.toString().toUpperCase()));
        break;
      case 'Unidad':
        this.tbMPSource = sort.direction == 'asc' ?
                          this.tbMPSource.sort((a,b) => a.unidadCodigo.toString().toUpperCase().localeCompare(b.unidadCodigo.toString().toUpperCase())) :
                          this.tbMPSource.sort((a,b) => b.unidadCodigo.toString().toUpperCase().localeCompare(a.unidadCodigo.toString().toUpperCase()));
        break;
      case 'Linea':
        this.tbMPSource = sort.direction == 'asc' ?
                          this.tbMPSource.sort((a,b) => a.lineaDescripcion.toString().toUpperCase().localeCompare(b.lineaDescripcion.toString().toUpperCase())) :
                          this.tbMPSource.sort((a,b) => b.lineaDescripcion.toString().toUpperCase().localeCompare(a.lineaDescripcion.toString().toUpperCase()));
        break;
      case 'Cantidad':
        this.tbMPSource = sort.direction == 'asc' ? this.tbMPSource.sort((a,b) => a.cantidad - b.cantidad) : this.tbMPSource.sort((a,b) => b.cantidad - a.cantidad);
        break;
      case 'Peso':
        this.tbMPSource = sort.direction == 'asc' ? this.tbMPSource.sort((a,b) => a.peso - b.peso) : this.tbMPSource.sort((a,b) => b.peso - a.peso);
        break;
    }
    this.getPageTablaMP(0, 10);
  }

  eventSortTablePT(sort: Sort){
    switch (sort.active) {
      case 'Origen':
        this.tbPTSource = sort.direction == 'asc' ?
                          this.tbPTSource.sort((a,b) => a.origenDescripcion.toString().toUpperCase().localeCompare(b.origenDescripcion.toString().toUpperCase())) :
                          this.tbPTSource.sort((a,b) => b.origenDescripcion.toString().toUpperCase().localeCompare(a.origenDescripcion.toString().toUpperCase()));
        break;
      case 'Cliente':
        this.tbPTSource = sort.direction == 'asc' ?
                          this.tbPTSource.sort((a,b) => a.clienteCodigo.toString().toUpperCase().localeCompare(b.clienteCodigo.toString().toUpperCase())) :
                          this.tbPTSource.sort((a,b) => b.clienteCodigo.toString().toUpperCase().localeCompare(a.clienteCodigo.toString().toUpperCase()));
        break;
      case 'Sucursal':
        this.tbPTSource = sort.direction == 'asc' ?
                          this.tbPTSource.sort((a,b) => a.sucursalDescripcion.toString().toUpperCase().localeCompare(b.sucursalDescripcion.toString().toUpperCase())) :
                          this.tbPTSource.sort((a,b) => b.sucursalDescripcion.toString().toUpperCase().localeCompare(a.sucursalDescripcion.toString().toUpperCase()));
        break;
      case 'Cantidad':
        this.tbPTSource = sort.direction == 'asc' ? this.tbPTSource.sort((a,b) => a.cantidad - b.cantidad) : this.tbPTSource.sort((a,b) => b.cantidad - a.cantidad);
        break;
      case 'Peso':
        this.tbPTSource = sort.direction == 'asc' ? this.tbPTSource.sort((a,b) => a.peso - b.peso) : this.tbPTSource.sort((a,b) => b.peso - a.peso);
        break;
    }
    this.getPageTablaPT(0, 10);
  }

  public transformThousands(value: any) {
      return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

}
