import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Chart } from 'angular-highcharts';
import { IndicadorRORequest } from 'app/shared/models/request/indicador/indicador-ro-request.interface';
import { GlobalProduccionResponse, GlobalRotacionResponse, IndicadorROResponse, ItemProduccionResponse } from 'app/shared/models/response/indicador/indicadores-response.interface';
import { ItemAlmacen, ListAlmacenResponse } from 'app/shared/models/response/reporte/almacen.interface';
import { ItemLinea, ListLineaResponse } from 'app/shared/models/response/reporte/linea.interface';
import { ItemSublinea, ListSublineaResponse } from 'app/shared/models/response/reporte/sublinea.interface';
import { IndicadorService } from 'app/shared/services/indicador/indicador.service';
import { ReporteService } from 'app/shared/services/reporte/reporte.service';


@Component({
  selector: 'app-indicador-rotacion',
  templateUrl: './indicador-rotacion.component.html',
  styleUrls: ['./indicador-rotacion.component.scss']
})
export class IndicadorRotacionComponent implements OnInit {

  rotacionForm: FormGroup;
  chart: Chart;
  almacen: ItemAlmacen[]=[];
  linea: ItemLinea[]=[];
  sublinea: ItemSublinea[]=[];
  anios: any[] = [];
  
  isLoading: boolean = false;

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: FormBuilder,
    private _reporteService: ReporteService,
    private _indicadorService: IndicadorService,
    private _snackBar: MatSnackBar,) { }

  ngOnInit(): void {
    
    this.rotacionForm = this._formBuilder.group({
      AlmacenSerie: [''],
      SubAlmacen: [''],
      Linea: [''],
      SubLinea: [''],
      Anio: [null]
    });

    this.rotacionForm.get('SubAlmacen').setValue('MP');
    this.getAnios();
    this.getAlmacen();
    this.getLinea();
  }

  getAnios() {
    let init = 2000;
    let anio = (new Date()).getFullYear();
    let diff = anio - init;
    for(let d = 0; d < diff; d++){
        this.anios.push(init + (d + 1));
    }
    this.rotacionForm.get('Anio').setValue(anio);
  }

  getLinea(): void{
    this._reporteService.obtenerLinea()
        .subscribe(
            (response: ListLineaResponse) => {
                this.linea = response.result.linea;
                this._changeDetectorRef.markForCheck();
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
  }

  selectLinea(data: MatSelectChange){
      this.rotacionForm.get('SubLinea').setValue('');
      this.getDataGraphic();
      this.getSublinea(String(data.value));
  }

  getSublinea(codLinea: string): void{
      this._reporteService.obtenerSublinea(codLinea)
          .subscribe(
              (response: ListSublineaResponse) => {
                  this.sublinea = response.result.sublinea;
                  this._changeDetectorRef.markForCheck();
              },
              (error: HttpErrorResponse) => {
                  console.log(error);
              }
          );
  }

  getAlmacen(): void{
    this._reporteService.obtenerAlmacen()
        .subscribe(
            (response: ListAlmacenResponse) => {
                this.almacen = response.result.almacen;
                this.rotacionForm.get('AlmacenSerie').setValue('020');
                this._changeDetectorRef.markForCheck();
                this.getDataGraphic();
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
  }
  
  getDataGraphic() {

    this.isLoading = true;
    let request = new IndicadorRORequest();
    request.almacen = this.rotacionForm.get('AlmacenSerie').value != null ? this.rotacionForm.get('AlmacenSerie').value : '';
    request.subAlmacen = this.rotacionForm.get('SubAlmacen').value != null ? this.rotacionForm.get('SubAlmacen').value : '';
    request.linea = this.rotacionForm.get('Linea').value != null ? this.rotacionForm.get('Linea').value : '';
    request.subLinea = this.rotacionForm.get('SubLinea').value != null ? this.rotacionForm.get('SubLinea').value : '';
    request.anio = this.rotacionForm.get('Anio').value != null ? this.rotacionForm.get('Anio').value : '';

    this._indicadorService.ObtenerDatosRO(request)
    .subscribe(
      (response: IndicadorROResponse) => {
        this.isLoading = false;
       this.loadChart(response.result.itemsRotacion);

      },
      (error: HttpErrorResponse) => {
        console.log(error);
        this.isLoading = false;
      }
    );

  }

  loadChart(data: Array<GlobalRotacionResponse>){

    

    let chart = new Chart({
        chart: {
            type: 'column'
        },
        title: {
            text: 'Indicador de Rotación',
            align: 'center'
        },
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b>'
        },
        accessibility: {
            announceNewData: {
                enabled: true
            }
        },
        xAxis: {
            type: 'category'
        },
        yAxis: {
            title: {
                text: 'Total de rotación'
            }
    
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: true,
                    format: '{point.y}'
                }
            }
        },
        
        series: [{
            type: 'column',
            name: 'Meses',
            colorByPoint: true,
            data: [{
                name: 'Enero',
                y: data.find(d => d.id == 1).cantidad,
                drilldown: 'Enero',
                color: '#eb4242'
            }, {
                name: 'Febrero',
                y: data.find(d => d.id == 2).cantidad,
                drilldown: 'Febrero',
                color: '#eb9442'
            }, {
                name: 'Marzo',
                y: data.find(d => d.id == 3).cantidad,
                drilldown: 'Marzo',
                color: '#ebeb42'
            }, {
                name: 'Abril',
                y: data.find(d => d.id == 4).cantidad,
                drilldown: 'Abril',
                color: '#77d63c'
            }, {
                name: 'Mayo',
                y: data.find(d => d.id == 5).cantidad,
                drilldown: 'Mayo',
                color: '#3cd6ba'
            }, {
                name: 'Junio',
                y: data.find(d => d.id == 6).cantidad,
                drilldown: 'Junio',
                color: '#3c6fd6'
            }, {
                name: 'Julio',
                y: data.find(d => d.id == 7).cantidad,
                drilldown: 'Julio',
                color: '#7c3cd6'
            }, {
                name: 'Agosto',
                y: data.find(d => d.id == 8).cantidad,
                drilldown: 'Agosto',
                color: '#d63ccc'
            }, {
                name: 'Setiembre',
                y: data.find(d => d.id == 9).cantidad,
                drilldown: 'Setiembre',
                color: '#67b585'
            }, {
                name: 'Octubre',
                y: data.find(d => d.id == 10).cantidad,
                drilldown: 'Octubre',
                color: '#2e8c89'
            }, {
                name: 'Noviembre',
                y: data.find(d => d.id == 11).cantidad,
                drilldown: 'Noviembre',
                color: '#876e8f'
            }, {
                name: 'Diciembre',
                y: data.find(d => d.id == 12).cantidad,
                drilldown: 'Diciembre',
                color: '#fa7e3c'
            }]
        }],
        drilldown: {
            breadcrumbs: {
                position: {
                    align: 'right'
                }
            },
            series: [
                {
                    type: 'column',
                    name: 'Enero',
                    id: 'Enero',
                    // data: [
                    //     //['Día 23', 89]
                    // ],
                    data: this.obtenerValuesDrill(data.find(d => d.id == 1).items)
                },
                {
                    type: 'column',
                    name: 'Febrero',
                    id: 'Febrero',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 2).items)
                },
                {
                    type: 'column',
                    name: 'Marzo',
                    id: 'Marzo',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 3).items)
                },
                {
                    type: 'column',
                    name: 'Abril',
                    id: 'Abril',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 4).items)
                },
                {
                    type: 'column',
                    name: 'Mayo',
                    id: 'Mayo',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 5).items)
                },
                {
                    type: 'column',
                    name: 'Junio',
                    id: 'Junio',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 6).items)
                },
                {
                    type: 'column',
                    name: 'Julio',
                    id: 'Julio',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 7).items)
                },
                {
                    type: 'column',
                    name: 'Agosto',
                    id: 'Agosto',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 8).items)
                },
                {
                    type: 'column',
                    name: 'Setiembre',
                    id: 'Setiembre',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 9).items)
                },
                {
                    type: 'column',
                    name: 'Octubre',
                    id: 'Octubre',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 10).items)
                },
                {
                    type: 'column',
                    name: 'Noviembre',
                    id: 'Noviembre',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 11).items)
                },
                {
                    type: 'column',
                    name: 'Diciembre',
                    id: 'Diciembre',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 12).items)
                }
            ]
        }
    });
    this.chart = chart;
  }

  obtenerValuesDrill(data: Array<ItemProduccionResponse>): any {
    
    let values = [];

    for(let d of data){
        values.push([`Día ${d.fecha.split('-')[2]}`, d.cantidad]);
    }

    return values;
  }
  
  refresh(){
    this.getDataGraphic();
  }

}
