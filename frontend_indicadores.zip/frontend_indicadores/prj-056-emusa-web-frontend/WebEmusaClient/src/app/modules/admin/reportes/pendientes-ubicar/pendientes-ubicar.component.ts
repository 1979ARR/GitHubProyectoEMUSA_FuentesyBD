import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { MateriaPrimaComponent } from './materia-prima/materia-prima.component';
import { ProductosProcesoComponent } from './productos-proceso/productos-proceso.component';
import { ProductosTerminadosComponent } from './productos-terminados/productos-terminados.component';

@Component({
  selector: 'app-pendientes-ubicar',
  templateUrl: './pendientes-ubicar.component.html',
  styleUrls: ['./pendientes-ubicar.component.scss']
})
export class PendientesUbicarComponent implements OnInit {

  typeView: string = 'MP';
  emitCollapsed = false;
  
  @ViewChild(MateriaPrimaComponent) materiaPrima: MateriaPrimaComponent;
  @ViewChild(ProductosProcesoComponent) productosProceso: ProductosProcesoComponent;
  @ViewChild(ProductosTerminadosComponent) productosTerminados: ProductosTerminadosComponent;

  constructor() { }

  ngOnInit(): void {
  }

  cleanFilter = () => {
    switch (this.typeView) {
      case 'MP':
        this.materiaPrima.cleanFilter();
        break;
      case 'PP':
        this.productosProceso.cleanFilter();
        break;
      case 'PT':
        this.productosTerminados.cleanFilter();
        break;
    }
  }

}
