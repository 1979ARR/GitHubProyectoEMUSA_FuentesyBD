import { ChangeDetectionStrategy, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { fuseAnimations } from '@fuse/animations';

@Component({
  selector: 'app-reportes',
  templateUrl: './reportes.component.html',
  styleUrls: ['./reportes.component.scss'],
  encapsulation  : ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations     : fuseAnimations
})
export class ReportesComponent implements OnInit {

  title = 'Pendientes por Ubicar';

  constructor() { }

  ngOnInit(): void {
    
  }

  selectedTab(event: MatTabChangeEvent){
    
    switch (event.index) {
      case 0:
        this.title = event.tab.textLabel;
        break;
      case 1:
        this.title = event.tab.textLabel;
        break;
      case 2:
        this.title = event.tab.textLabel;
        break;
      case 3:
        this.title = event.tab.textLabel;
        break;
      case 4:
        this.title = event.tab.textLabel;
        break;
    }
  }

}
