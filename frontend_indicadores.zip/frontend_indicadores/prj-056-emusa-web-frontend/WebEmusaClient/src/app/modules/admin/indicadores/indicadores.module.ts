import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatSelectModule } from '@angular/material/select';
import { MatDialogModule } from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatMenuModule } from '@angular/material/menu';
import { MatRippleModule, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatSortModule } from '@angular/material/sort';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatRadioModule } from '@angular/material/radio';
import { MatStepperModule } from '@angular/material/stepper';
import { BasicSnackbarModule } from '../common/basic-snackbar/basic-snackbar.module';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { NgxMatDatetimePickerModule, NgxMatNativeDateModule, NgxMatTimepickerModule } from '@angular-material-components/datetime-picker';
import { MatDividerModule } from '@angular/material/divider';
import { HeaderFormsModule } from '../common/header-forms/header-forms.module';
import { MatTabsModule } from '@angular/material/tabs';

import { IndicadoresRoutingModule } from './indicadores-routing.module';
import { IndicadoresComponent } from './indicadores.component';
import { ExactitudInventarioComponent } from './exactitud-inventario/exactitud-inventario.component';
import { CapacidadAlmacenamientoComponent } from './capacidad-almacenamiento/capacidad-almacenamiento.component';
import { FifoComponent } from './fifo/fifo.component';
import { ProduccionUsuarioComponent } from './produccion-usuario/produccion-usuario.component';
import { IndicadorRotacionComponent } from './indicador-rotacion/indicador-rotacion.component';
import { ChartModule, HIGHCHARTS_MODULES } from 'angular-highcharts';
import * as more from 'highcharts/highcharts-more.src';
import * as exporting from 'highcharts/modules/exporting.src';
import * as drilldown from 'highcharts/modules/drilldown.src';

@NgModule({
  declarations: [
    IndicadoresComponent,
    ExactitudInventarioComponent,
    CapacidadAlmacenamientoComponent,
    FifoComponent,
    ProduccionUsuarioComponent,
    IndicadorRotacionComponent
  ],
  imports: [
    CommonModule,
    IndicadoresRoutingModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatIconModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
    MatMomentDateModule,
    MatSelectModule,
    FormsModule,
    MatDialogModule,
    MatPaginatorModule,
    MatCheckboxModule,
    MatMenuModule,
    MatRippleModule,
    MatSortModule,
    MatSlideToggleModule,
    MatTooltipModule,
    MatProgressBarModule,
    MatRadioModule,
    MatStepperModule,
    MatSnackBarModule,
    BasicSnackbarModule,
    MatAutocompleteModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule,
    MatDividerModule,
    MatTabsModule,
    HeaderFormsModule,
    ChartModule
  ],
  providers   : [
    { provide: MAT_DATE_LOCALE, useValue: 'es-ES' },
    { provide: HIGHCHARTS_MODULES, useFactory: () => [ more, exporting, drilldown ] }
  ]
})
export class IndicadoresModule { }
