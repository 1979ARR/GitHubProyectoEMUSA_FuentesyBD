import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';

@Component({
  selector: 'app-indicadores',
  templateUrl: './indicadores.component.html',
  styleUrls: ['./indicadores.component.scss']
})
export class IndicadoresComponent implements OnInit {

  title = 'Porcentaje de Exactitud de Registro de Inventario (ERI)';

  constructor() { }

  ngOnInit(): void {
  }

  selectedTab(event: MatTabChangeEvent){
    
    switch (event.index) {
      case 0:
        this.title = 'Porcentaje de Exactitud de Registro de Inventario (ERI)';
        break;
      case 1:
        this.title = event.tab.textLabel;
        break;
      case 2:
        this.title = event.tab.textLabel;
        break;
      case 3:
        this.title = event.tab.textLabel;
        break;
      case 4:
        this.title = event.tab.textLabel;
        break;
    }
  }



}
