import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FuseNavigationService, FuseVerticalNavigationComponent } from '@fuse/components/navigation';
import { AuthService } from 'app/shared/services/authentication/auth.service';

@Component({
  selector: 'app-header-forms',
  templateUrl: './header-forms.component.html',
  styleUrls: ['./header-forms.component.scss']
})
export class HeaderFormsComponent implements OnInit {

  @Input()
  title: string;
  constructor(
    private _fuseNavigationService: FuseNavigationService,
    private _authService: AuthService,
    private _router: Router
  ) { }

  ngOnInit(): void {
  }

  
  toggleNavigation(name: string): void
  {
      // Get the navigation
      const navigation = this._fuseNavigationService.getComponent<FuseVerticalNavigationComponent>(name);

      if ( navigation )
      {
          // Toggle the opened status
          navigation.toggle();
      }
  }

  signOff(): void
    {
        this._authService.signOff();
        this._router.navigate(['/sign-out']);
    }


}
