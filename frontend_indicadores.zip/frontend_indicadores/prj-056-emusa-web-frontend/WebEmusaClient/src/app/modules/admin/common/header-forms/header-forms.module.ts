import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderFormsComponent } from './header-forms.component';
import { FuseFullscreenModule } from '@fuse/components/fullscreen/fullscreen.module';
import { MatButtonModule } from '@angular/material/button';
import { ReactiveFormsModule } from '@angular/forms';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { UserModule } from 'app/layout/common/user/user.module';


@NgModule({
  declarations: [
    HeaderFormsComponent
  ],
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    FuseFullscreenModule,
    ReactiveFormsModule,
    MatMenuModule,
    UserModule
  ],
  exports:  [
    HeaderFormsComponent
  ]
})
export class HeaderFormsModule { }
