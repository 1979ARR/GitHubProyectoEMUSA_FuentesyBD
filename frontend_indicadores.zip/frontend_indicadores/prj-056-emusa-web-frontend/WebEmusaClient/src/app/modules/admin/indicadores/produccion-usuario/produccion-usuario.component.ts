import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Chart } from 'angular-highcharts';
import { IndicadorPURequest } from 'app/shared/models/request/indicador/indicador-pu-request.interface';
import { GlobalProduccionResponse, IndicadorPUResponse, ItemProduccionResponse, UsuarioInd, UsuarioIngResponse } from 'app/shared/models/response/indicador/indicadores-response.interface';
import { ItemAlmacen, ListAlmacenResponse } from 'app/shared/models/response/reporte/almacen.interface';
import { ItemLinea, ListLineaResponse } from 'app/shared/models/response/reporte/linea.interface';
import { ItemSublinea, ListSublineaResponse } from 'app/shared/models/response/reporte/sublinea.interface';
import { IndicadorService } from 'app/shared/services/indicador/indicador.service';
import { ReporteService } from 'app/shared/services/reporte/reporte.service';
import * as drilldown from 'highcharts/modules/drilldown.src';

@Component({
  selector: 'app-produccion-usuario',
  templateUrl: './produccion-usuario.component.html',
  styleUrls: ['./produccion-usuario.component.scss']
})
export class ProduccionUsuarioComponent implements OnInit {

  puForm: FormGroup;
  chart: Chart;
  almacen: ItemAlmacen[]=[];
  linea: ItemLinea[]=[];
  sublinea: ItemSublinea[]=[];
  anios: any[] = [];
  usuarios: UsuarioInd[] = [];

  isLoading: boolean = false;
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: FormBuilder,
    private _reporteService: ReporteService,
    private _indicadorService: IndicadorService
    ) { }

  ngOnInit(): void {
    
    this.puForm = this._formBuilder.group({
      Usuario: [null],
      Anio: [null],
      fechaDesde: new FormControl<Date | null>(null),
      fechaHasta: new FormControl<Date | null>(null),
      AlmacenSerie: [''],
      Linea: [''],
      SubLinea: ['']
    });

    this.getAnios();
    this.listarUsuariosInd();
    this.getAlmacen();
    this.getLinea();

  }
  
  refresh() {
    this.getDataGraphic();
  }

  getAnios() {
    let init = 2000;
    let anio = (new Date()).getFullYear();
    let diff = anio - init;
    for(let d = 0; d < diff; d++){
        this.anios.push(init + (d + 1));
    }
    this.puForm.get('Anio').setValue(anio);
  }

  getLinea(): void{
    this._reporteService.obtenerLinea()
        .subscribe(
            (response: ListLineaResponse) => {
                this.linea = response.result.linea;
                this._changeDetectorRef.markForCheck();
                console.log('Lineas kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
  }

  selectLinea(data: MatSelectChange){
      this.puForm.get('SubLinea').setValue('');
      this.getDataGraphic();
      this.getSublinea(String(data.value));
      
  }

  getSublinea(codLinea: string): void{
      console.log('Sublineas kardex',codLinea);
      this._reporteService.obtenerSublinea(codLinea)
          .subscribe(
              (response: ListSublineaResponse) => {
                  this.sublinea = response.result.sublinea;
                  this._changeDetectorRef.markForCheck();
              },
              (error: HttpErrorResponse) => {
                  console.log(error);
              }
          );
  }

  getAlmacen(): void{
    this._reporteService.obtenerAlmacen()
        .subscribe(
            (response: ListAlmacenResponse) => {
                this.almacen = response.result.almacen;
                this._changeDetectorRef.markForCheck();
                console.log('almacenes kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
  }

  cleanFilter(): void{
      this.puForm.get('AlmacenSerie').setValue(null);
      this.puForm.get('Linea').setValue('');
      this.puForm.get('SubLinea').setValue('');
  }

  loadChart(data: Array<GlobalProduccionResponse>){

    

    let chart = new Chart({
        chart: {
            // plotBackgroundColor: null,
            // plotBorderWidth: null,
            // plotShadow: false,
            type: 'column'
        },
        title: {
            text: 'Producción por Usuario',
            align: 'center'
        },
        tooltip: {
            headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
            pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}</b>'
        },
        accessibility: {
            announceNewData: {
                enabled: true
            }
        },
        xAxis: {
            type: 'category'
        },
        yAxis: {
            title: {
                text: 'Total de producción'
            }
    
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                dataLabels: {
                    enabled: true,
                    format: '{point.y}'
                }
            }
        },
        
        series: [{
            type: 'column',
            name: 'Meses',
            colorByPoint: true,
            data: [{
                        name: 'Enero',
                        y: data.find(d => d.id == 1).cantidad,
                        drilldown: 'Enero',
                        color: '#eb4242'
                    }, {
                        name: 'Febrero',
                        y: data.find(d => d.id == 2).cantidad,
                        drilldown: 'Febrero',
                        color: '#eb9442'
                    }, {
                        name: 'Marzo',
                        y: data.find(d => d.id == 3).cantidad,
                        drilldown: 'Marzo',
                        color: '#ebeb42'
                    }, {
                        name: 'Abril',
                        y: data.find(d => d.id == 4).cantidad,
                        drilldown: 'Abril',
                        color: '#77d63c'
                    }, {
                        name: 'Mayo',
                        y: data.find(d => d.id == 5).cantidad,
                        drilldown: 'Mayo',
                        color: '#3cd6ba'
                    }, {
                        name: 'Junio',
                        y: data.find(d => d.id == 6).cantidad,
                        drilldown: 'Junio',
                        color: '#3c6fd6'
                    }, {
                        name: 'Julio',
                        y: data.find(d => d.id == 7).cantidad,
                        drilldown: 'Julio',
                        color: '#7c3cd6'
                    }, {
                        name: 'Agosto',
                        y: data.find(d => d.id == 8).cantidad,
                        drilldown: 'Agosto',
                        color: '#d63ccc'
                    }, {
                        name: 'Setiembre',
                        y: data.find(d => d.id == 9).cantidad,
                        drilldown: 'Setiembre',
                        color: '#67b585'
                    }, {
                        name: 'Octubre',
                        y: data.find(d => d.id == 10).cantidad,
                        drilldown: 'Octubre',
                        color: '#2e8c89'
                    }, {
                        name: 'Noviembre',
                        y: data.find(d => d.id == 11).cantidad,
                        drilldown: 'Noviembre',
                        color: '#876e8f'
                    }, {
                        name: 'Diciembre',
                        y: data.find(d => d.id == 12).cantidad,
                        drilldown: 'Diciembre',
                        color: '#fa7e3c'
                    }]
        }],
        drilldown: {
            breadcrumbs: {
                position: {
                    align: 'right'
                }
            },
            series: [
                {
                    type: 'column',
                    name: 'Enero',
                    id: 'Enero',
                    // data: [
                    //     //['Día 23', 89]
                    // ],
                    data: this.obtenerValuesDrill(data.find(d => d.id == 1).items)
                },
                {
                    type: 'column',
                    name: 'Febrero',
                    id: 'Febrero',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 2).items)
                },
                {
                    type: 'column',
                    name: 'Marzo',
                    id: 'Marzo',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 3).items)
                },
                {
                    type: 'column',
                    name: 'Abril',
                    id: 'Abril',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 4).items)
                },
                {
                    type: 'column',
                    name: 'Mayo',
                    id: 'Mayo',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 5).items)
                },
                {
                    type: 'column',
                    name: 'Junio',
                    id: 'Junio',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 6).items)
                },
                {
                    type: 'column',
                    name: 'Julio',
                    id: 'Julio',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 7).items)
                },
                {
                    type: 'column',
                    name: 'Agosto',
                    id: 'Agosto',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 8).items)
                },
                {
                    type: 'column',
                    name: 'Setiembre',
                    id: 'Setiembre',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 9).items)
                },
                {
                    type: 'column',
                    name: 'Octubre',
                    id: 'Octubre',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 10).items)
                },
                {
                    type: 'column',
                    name: 'Noviembre',
                    id: 'Noviembre',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 11).items)
                },
                {
                    type: 'column',
                    name: 'Diciembre',
                    id: 'Diciembre',
                    data: this.obtenerValuesDrill(data.find(d => d.id == 12).items)
                }
            ]
        }
    });
    this.chart = chart;
  }

  obtenerValuesDrill(data: Array<ItemProduccionResponse>): any {
    
    let values = [];

    for(let d of data){
        values.push([`Día ${d.fecha.split('-')[2]}`, d.cantidad]);
    }

    return values;
  }

  clearDateRange(){
    this.puForm.get('fechaDesde').setValue(null);
    this.puForm.get('fechaHasta').setValue(null);
  }

  getDataGraphic() {
   
    if(this.puForm.get('Usuario').value == null || this.puForm.get('Usuario').value == ''){
        return false;
    }

    this.isLoading = true;
    let request = new IndicadorPURequest();
    request.almacen = this.puForm.get('AlmacenSerie').value != null ? this.puForm.get('AlmacenSerie').value : '';
    request.linea = this.puForm.get('Linea').value != null ? this.puForm.get('Linea').value : '';
    request.subLinea = this.puForm.get('SubLinea').value != null ? this.puForm.get('SubLinea').value : '';
    request.usuario = this.puForm.get('Usuario').value != null ? this.puForm.get('Usuario').value : ''; //'EDOLORES'; //'DALVA';
    request.anio = this.puForm.get('Anio').value != null ? this.puForm.get('Anio').value : ''; //'2022';

    this._indicadorService.ObtenerDatosPU(request)
    .subscribe(
      (response: IndicadorPUResponse) => {
       this.isLoading = false;
       console.log('RESP INDICADOR PRODUCCION', response);
       this.loadChart(response.result.itemsProduccion);

      },
      (error: HttpErrorResponse) => {
        console.log(error);
        this.isLoading = false;
      }
    );

  }

  listarUsuariosInd(){
    this._indicadorService.ListarUsuariosInd()
    .subscribe(
      (response: UsuarioIngResponse) => {
        if(response.status){
            this.usuarios = response.result != null ? response.result : [];
            this.puForm.get('Usuario').setValue(this.usuarios[this.usuarios.length - 1].codigo);
            this.getDataGraphic();
        }
      },
      (error: HttpErrorResponse) => {
        console.log(error);
        this.isLoading = false;
      }
    );
  }

}
