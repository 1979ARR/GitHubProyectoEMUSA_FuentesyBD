import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Chart } from 'angular-highcharts';
import { IndicadorCARequest } from 'app/shared/models/request/indicador/indicador-ca-request.interface';
import { IndicadorCAResponse } from 'app/shared/models/response/indicador/indicadores-response.interface';
import { ItemAlmacen, ListAlmacenResponse } from 'app/shared/models/response/reporte/almacen.interface';
import { ItemLinea, ListLineaResponse } from 'app/shared/models/response/reporte/linea.interface';
import { ItemSublinea, ListSublineaResponse } from 'app/shared/models/response/reporte/sublinea.interface';
import { IndicadorService } from 'app/shared/services/indicador/indicador.service';
import { ReporteService } from 'app/shared/services/reporte/reporte.service';
import Highcharts from 'highcharts';

@Component({
  selector: 'app-capacidad-almacenamiento',
  templateUrl: './capacidad-almacenamiento.component.html',
  styleUrls: ['./capacidad-almacenamiento.component.scss']
})
export class CapacidadAlmacenamientoComponent implements OnInit {

  caForm: FormGroup;
  chart: Chart;
  chart2: Chart;
  chart3: Chart;
  almacen: ItemAlmacen[]=[];
  linea: ItemLinea[]=[];
  sublinea: ItemSublinea[]=[];
  dynamicTitle: string = '';

  isLoading: boolean = false;
  isLoading2: boolean = false;
  isLoading3: boolean = false;

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: FormBuilder,
    private _snackBar: MatSnackBar,
    private _reporteService: ReporteService,
    private _indicadorService: IndicadorService) { }

  ngOnInit(): void {

    this.caForm = this._formBuilder.group({
        Ubicacion: [null],
        AlmacenSerie: [''],
        Linea: [''],
        SubLinea: ['']
      });

    this.getAlmacen();
    this.getLinea();
  }
  
  refresh(){
    this.getDataGraphic1();
    this.getDataGraphic2();
    this.getDataGraphic3();
  }

  getLinea(): void{
    this._reporteService.obtenerLinea()
        .subscribe(
            (response: ListLineaResponse) => {
                this.linea = response.result.linea;
                this._changeDetectorRef.markForCheck();
                console.log('Lineas kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
  }
  
  selectLinea(data: MatSelectChange){
    this.caForm.get('SubLinea').setValue('');
    this.getDataGraphic1();
    this.getDataGraphic2();
    this.getDataGraphic3();
    this.getSublinea(String(data.value));
  }

  getSublinea(codLinea: string): void{
      console.log('Sublineas kardex',codLinea);
      this._reporteService.obtenerSublinea(codLinea)
          .subscribe(
              (response: ListSublineaResponse) => {
                  this.sublinea = response.result.sublinea;
                  this._changeDetectorRef.markForCheck();
                  console.log('Sublineas kardex',codLinea);
                  console.log('Sublineas kardex',response);
              },
              (error: HttpErrorResponse) => {
                  console.log(error);
              }
          );
  }

  getAlmacen(): void{
    this._reporteService.obtenerAlmacen()
        .subscribe(
            (response: ListAlmacenResponse) => {
                this.almacen = response.result.almacen;
                this._changeDetectorRef.markForCheck();
                this.caForm.get('AlmacenSerie').setValue('020');
                this.getDataGraphic1();
                this.getDataGraphic2();
                this.getDataGraphic3();
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
  }

  cleanFilter(): void{
      this.caForm.get('AlmacenSerie').setValue(null);
      this.caForm.get('Linea').setValue('');
      this.caForm.get('SubLinea').setValue('');
  }

  getDataGraphic1() {
   
    this.isLoading = true;

    this.dynamicTitle = this.almacen.find(a => a.almacenSerie == this.caForm.get('AlmacenSerie').value).almacenNombre;

    let request = new IndicadorCARequest();
    request.almacen = this.caForm.get('AlmacenSerie').value != null ? this.caForm.get('AlmacenSerie').value : '';
    request.linea = this.caForm.get('Linea').value != null ? this.caForm.get('Linea').value : '';
    request.subLinea = this.caForm.get('SubLinea').value != null ? this.caForm.get('SubLinea').value : '';
    request.ubicacion = this.caForm.get('Ubicacion').value != null ? this.caForm.get('Ubicacion').value : '';
    request.tipo = 'MP';

    this._indicadorService.ObtenerDatosCA(request)
    .subscribe(
      (response: IndicadorCAResponse) => {
        this.isLoading = false;
       console.log('RESP PUNTA', response);
       let result = response.result.materiaPrima;
       this.loadChart(result.limiteVerde, result.limiteAmarillo, result.limiteRojo, result.valor);
      },
      (error: HttpErrorResponse) => {
        console.log(error);
        this.isLoading = false;
      }
    );

  }

  getDataGraphic2() {
   
    this.isLoading2 = true;

    let request = new IndicadorCARequest();
    request.almacen = this.caForm.get('AlmacenSerie').value != null ? this.caForm.get('AlmacenSerie').value : '';
    request.linea = this.caForm.get('Linea').value != null ? this.caForm.get('Linea').value : '';
    request.subLinea = this.caForm.get('SubLinea').value != null ? this.caForm.get('SubLinea').value : '';
    request.ubicacion = this.caForm.get('Ubicacion').value != null ? this.caForm.get('Ubicacion').value : '';
    request.tipo = 'PP';

    this._indicadorService.ObtenerDatosCA(request)
    .subscribe(
      (response: IndicadorCAResponse) => {
        this.isLoading2 = false;
       console.log('RESP PUNTA', response);
       let result = response.result.productosProceso;
       this.loadChart2(result.limiteVerde, result.limiteAmarillo, result.limiteRojo, result.valor);
      },
      (error: HttpErrorResponse) => {
        console.log(error);
        this.isLoading2 = false;
      }
    );

  }

  getDataGraphic3() {
   
    this.isLoading3 = true;
    let request = new IndicadorCARequest();
    request.almacen = this.caForm.get('AlmacenSerie').value != null ? this.caForm.get('AlmacenSerie').value : '';
    request.linea = this.caForm.get('Linea').value != null ? this.caForm.get('Linea').value : '';
    request.subLinea = this.caForm.get('SubLinea').value != null ? this.caForm.get('SubLinea').value : '';
    request.ubicacion = this.caForm.get('Ubicacion').value != null ? this.caForm.get('Ubicacion').value : '';
    request.tipo = 'PT';

    this._indicadorService.ObtenerDatosCA(request)
    .subscribe(
      (response: IndicadorCAResponse) => {
        this.isLoading3 = false;
       console.log('RESP PUNTA 3', response);
       let result = response.result.productosTerminados;
       this.loadChart3(result.limiteVerde, result.limiteAmarillo, result.limiteRojo, result.valor);
      },
      (error: HttpErrorResponse) => {
        console.log(error);
        this.isLoading3 = false;
      }
    );

  }

  loadChart(limitGreen: number, limitYellow: number, limitRed: number, value: number){
    
    let pLimitGreen = (limitGreen * 100) / limitRed;
    let pLimitYellow = (limitYellow * 100) / limitRed;
    let pValue = (value * 100) / limitRed;
    let pLimitRed = 100;
    
    let chart = new Chart({

        chart: {
            type: 'gauge',
            plotBackgroundColor: null,
            plotBackgroundImage: null,
            plotBorderWidth: 0,
            plotShadow: false,
            height: '80%'
        },
    
        title: {
            text: '% Capacidad de Almacenamiento'
        },
    
        pane: {
            startAngle: -90,
            endAngle: 89.9,
            background: null,
            center: ['50%', '75%'],
            size: '110%'
        },
    
        // the value axis
        yAxis: {
            min: 0.00,
            max: pLimitRed, //limitRed, // 1.00,
            tickPixelInterval: 72,
            tickPosition: 'inside',
            tickColor: Highcharts.defaultOptions.chart.backgroundColor || '#FFFFFF',
            tickLength: 20,
            tickWidth: 2,
            minorTickInterval: null,
            labels: {
                distance: 20,
                style: {
                    fontSize: '14px'
                }
            },
            plotBands: [{
                from: 0,
                to: pLimitGreen, //limitGreen, //0.5,
                color: '#55BF3B', // green
                thickness: 20
            }, {
                from: pLimitGreen, //0.5,
                to: pLimitYellow, // limitYellow, //0.75,
                color: '#DDDF0D', // yellow
                thickness: 20
            }, {
                from: pLimitYellow, //0.75,
                to: pLimitRed, //limitRed, // 1.00,
                color: '#DF5353', // red
                thickness: 20
            }]
        },
    
        series: [{
            type: 'gauge',
            name: `${this.dynamicTitle}: Valor:<b>${value.toFixed(3)}</b> Ref`,
            data: [Number(pValue.toFixed(3))],
            tooltip: {
                valueSuffix:'%',
            },
            dataLabels: {
                //format: '{y}', // km/h',
                format: `${this.transformThousands(pValue.toFixed(3))} % TN`,
                borderWidth: 0,
                color: (
                    Highcharts.defaultOptions.title &&
                    Highcharts.defaultOptions.title.style &&
                    Highcharts.defaultOptions.title.style.color
                ) || '#333333',
                style: {
                    fontSize: '16px'
                }
            },
            dial: {   
                radius: '80%',
                backgroundColor: 'gray',
                baseWidth: 12,
                baseLength: '0%',
                rearLength: '0%'
            },
            pivot: {
                backgroundColor: 'gray',
                radius: 6
            }
        }]
    
    });
  
    this.chart = chart;
  }

  loadChart2(limitGreen: number, limitYellow: number, limitRed: number, value: number){
    
    let pLimitGreen = (limitGreen * 100) / limitRed;
    let pLimitYellow = (limitYellow * 100) / limitRed;
    let pValue = (value * 100) / limitRed;
    let pLimitRed = 100;

    let chart = new Chart({

        chart: {
            type: 'gauge',
            plotBackgroundColor: null,
            plotBackgroundImage: null,
            plotBorderWidth: 0,
            plotShadow: false,
            height: '80%'
        },
    
        title: {
            text: '% Capacidad de Almacenamiento'
        },
    
        pane: {
            startAngle: -90,
            endAngle: 89.9,
            background: null,
            center: ['50%', '75%'],
            size: '110%'
        },
    
        // the value axis
        yAxis: {
            min: 0.00,
            max: pLimitRed, //limitRed, // 1.00,
            tickPixelInterval: 72,
            tickPosition: 'inside',
            tickColor: Highcharts.defaultOptions.chart.backgroundColor || '#FFFFFF',
            tickLength: 20,
            tickWidth: 2,
            minorTickInterval: null,
            labels: {
                distance: 20,
                style: {
                    fontSize: '14px'
                }
            },
            plotBands: [{
                from: 0,
                to: pLimitGreen, //limitGreen, //0.5,
                color: '#55BF3B', // green
                thickness: 20
            }, {
                from: pLimitGreen, //0.5,
                to: pLimitYellow, // limitYellow, //0.75,
                color: '#DDDF0D', // yellow
                thickness: 20
            }, {
                from: pLimitYellow, //0.75,
                to: pLimitRed, //limitRed, // 1.00,
                color: '#DF5353', // red
                thickness: 20
            }]
        },
    
        series: [{
            type: 'gauge',
            name: `${this.dynamicTitle}: Valor:<b>${value.toFixed(3)}</b> Ref`,
            data: [Number(pValue.toFixed(3))],
            tooltip: {
                valueSuffix:'%',
            },
            dataLabels: {
                //format: '{y}', // km/h',
                format: `${this.transformThousands(pValue.toFixed(3))} % TN`,
                borderWidth: 0,
                color: (
                    Highcharts.defaultOptions.title &&
                    Highcharts.defaultOptions.title.style &&
                    Highcharts.defaultOptions.title.style.color
                ) || '#333333',
                style: {
                    fontSize: '16px'
                }
            },
            dial: {   
                radius: '80%',
                backgroundColor: 'gray',
                baseWidth: 12,
                baseLength: '0%',
                rearLength: '0%'
            },
            pivot: {
                backgroundColor: 'gray',
                radius: 6
            }
        }]
    
    });
  
    this.chart2 = chart;
  }

  loadChart3(limitGreen: number, limitYellow: number, limitRed: number, value: number){
    
    let pLimitGreen = (limitGreen * 100) / limitRed;
    let pLimitYellow = (limitYellow * 100) / limitRed;
    let pValue = (value * 100) / limitRed;
    let pLimitRed = 100;

    let chart = new Chart({

        chart: {
            type: 'gauge',
            plotBackgroundColor: null,
            plotBackgroundImage: null,
            plotBorderWidth: 0,
            plotShadow: false,
            height: '80%'
        },
    
        title: {
            text: '% Capacidad de Almacenamiento'
        },
    
        pane: {
            startAngle: -90,
            endAngle: 89.9,
            background: null,
            center: ['50%', '75%'],
            size: '110%'
        },
    
        // the value axis
        yAxis: {
            min: 0.00,
            max: pLimitRed, //limitRed, // 1.00,
            tickPixelInterval: 72,
            tickPosition: 'inside',
            tickColor: Highcharts.defaultOptions.chart.backgroundColor || '#FFFFFF',
            tickLength: 20,
            tickWidth: 2,
            minorTickInterval: null,
            labels: {
                distance: 20,
                style: {
                    fontSize: '14px'
                }
            },
            plotBands: [{
                from: 0,
                to: pLimitGreen, //limitGreen, //0.5,
                color: '#55BF3B', // green
                thickness: 20
            }, {
                from: pLimitGreen, //0.5,
                to: pLimitYellow, // limitYellow, //0.75,
                color: '#DDDF0D', // yellow
                thickness: 20
            }, {
                from: pLimitYellow, //0.75,
                to: pLimitRed, //limitRed, // 1.00,
                color: '#DF5353', // red
                thickness: 20
            }]
        },
    
        series: [{
            type: 'gauge',
            name: `${this.dynamicTitle}: Valor:<b>${value.toFixed(3)}</b> Ref`,
            data: [Number(pValue.toFixed(3))],
            tooltip: {
                valueSuffix:'%',
            },
            dataLabels: {
                //format: '{y}', // km/h',
                format: `${this.transformThousands(pValue.toFixed(3))} % TN`,
                borderWidth: 0,
                color: (
                    Highcharts.defaultOptions.title &&
                    Highcharts.defaultOptions.title.style &&
                    Highcharts.defaultOptions.title.style.color
                ) || '#333333',
                style: {
                    fontSize: '16px'
                }
            },
            dial: {   
                radius: '80%',
                backgroundColor: 'gray',
                baseWidth: 12,
                baseLength: '0%',
                rearLength: '0%'
            },
            pivot: {
                backgroundColor: 'gray',
                radius: 6
            }
        }]
    
    });
  
    this.chart3 = chart;
  }

  public transformThousands(value: any) {
    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }
  
}
