import { Component, OnInit, ViewChild } from '@angular/core';
import { MateriaPrimaComponent } from './materia-prima/materia-prima.component';
import { ProductosProcesoComponent } from './productos-proceso/productos-proceso.component';
import { ProductosTerminadosComponent } from './productos-terminados/productos-terminados.component';

@Component({
  selector: 'app-desarrollo-inventario',
  templateUrl: './desarrollo-inventario.component.html',
  styleUrls: ['./desarrollo-inventario.component.scss']
})
export class DesarrolloInventarioComponent implements OnInit {

  typeViewD: string = 'MP';
  emitCollapsed = false;
  
  @ViewChild(MateriaPrimaComponent) materiaPrima: MateriaPrimaComponent;
  @ViewChild(ProductosProcesoComponent) productosProceso: ProductosProcesoComponent;
  @ViewChild(ProductosTerminadosComponent) productosTerminados: ProductosTerminadosComponent;
  constructor() { }

  ngOnInit(): void {
  }

  cleanFilter = () => {
    switch (this.typeViewD) {
      case 'MP':
        this.materiaPrima.cleanFilter();
        break;
      case 'PP':
        this.productosProceso.cleanFilter();
        break;
      case 'PT':
        this.productosTerminados.cleanFilter();
        break;
    }
  }
}
