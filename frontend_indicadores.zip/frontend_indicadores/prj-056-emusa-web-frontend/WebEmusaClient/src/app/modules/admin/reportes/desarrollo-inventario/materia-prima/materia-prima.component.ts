import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse, HttpEventType, HttpResponse } from '@angular/common/http';
import { PageEvent } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { GeneralPagination } from 'app/shared/models/response/common/general-response.interface';
import * as moment from 'moment';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { GeneralService } from 'app/shared/services/common/general.service';
import { DatePipe } from '@angular/common';
import { ReporteService } from 'app/shared/services/reporte/reporte.service';
import { MateriaPrimaPPURequest } from 'app/shared/models/request/reporte/pendientes-ubicar-request.interface';
import { ItemMateriaPrimaPPU, MateriaPrimaPPUResponse } from 'app/shared/models/response/reporte/pendientes-ubicar.interface';
import { Sort } from '@angular/material/sort';
import { animate,AUTO_STYLE, state, style, transition, trigger } from '@angular/animations';
import { ItemAlmacen, ListAlmacenResponse } from 'app/shared/models/response/reporte/almacen.interface';
import { Mes, MesResponse } from 'app/shared/models/response/reporte/common.interface';
import { ExportarReporteRequest } from 'app/shared/models/request/reporte/exportar-request.interface';
import { ExportarService } from 'app/shared/services/reporte/exportar.service';
import { LoadingSnackbarComponent } from 'app/modules/admin/common/loading-snackbar/loading-snackbar.component';
import { ItemLinea, ListLineaResponse } from 'app/shared/models/response/reporte/linea.interface';
import { ItemSublinea, ListSublineaResponse } from 'app/shared/models/response/reporte/sublinea.interface';

const DEFAULT_DURATION = 300;
@Component({
  selector: 'app-materia-prima',
  templateUrl: './materia-prima.component.html',
  styleUrls: ['./materia-prima.component.scss'],
  styles: [
    `
        .content-grid {
            grid-template-columns: 70px 70px 80px 100px 90px 90px 70px 70px 70px 210px 70px 120px 120px 120px 60px 60px 70px 200px 120px 60px 60px 60px 60px 100px 100px 60px 60px 100px;

            @screen sm {
                grid-template-columns: 70px 70px 80px 100px 90px 90px 70px 70px 70px 210px 70px 120px 120px 120px 80px 60px 70px 200px 120px 60px 60px 60px 60px 100px 80px 60px 60px 100px;
            }

            @screen md {
                grid-template-columns: 70px 70px 80px 100px 90px 90px 70px 70px 70px 210px 70px 120px 120px 120px 100px 60px 70px 200px 120px 60px 60px 60px 60px 100px 100px 60px 60px 100px;
            }

            @screen lg {
                grid-template-columns: 70px 70px 80px 100px 90px 90px 70px 70px 70px 210px 70px 120px 120px 120px 120px 60px 70px 200px 120px 60px 60px 60px 60px 100px 130px 60px 60px 100px;
            }
        }
    `
  ],
  animations: [
    trigger('collapse', [
      state('false', style({ height: AUTO_STYLE, visibility: AUTO_STYLE })),
      state('true', style({ height: '0', visibility: 'hidden' })),
      transition('false => true', animate(DEFAULT_DURATION + 'ms ease-in')),
      transition('true => false', animate(DEFAULT_DURATION + 'ms ease-out'))
    ])
  ],
  providers: [DatePipe]
})

export class MateriaPrimaComponent implements OnInit {
  @Input()
  collapsed = false;
  title = "Materia Prima";
  almacen: ItemAlmacen[]=[];
  listado: ItemMateriaPrimaPPU[] = [];
  anios: number[]=[];
  meses: Mes[]=[];
  mes: string[]=[];
  mesActual: string;
  anioActual: string;
  linea: ItemLinea[]=[];
  sublinea: ItemSublinea[]=[];
  codigoBobinaSelect: string = '';
  pagination: GeneralPagination = new GeneralPagination();
  materiaPForm: FormGroup;
  isLoading: boolean = false;
  
  sortTable: Sort = {
    active: '1',
    direction: 'asc'
  }

  public progress: number;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: FormBuilder,
    private _snackBar: MatSnackBar,
    private _reporteService: ReporteService,
    private _exportarService: ExportarService,
    private _generalService: GeneralService,
    private datePipe: DatePipe,
    private _router: Router
  ) { }

  ngOnInit(): void
  {
    this.materiaPForm = this._formBuilder.group({
        FechaDesde: new FormControl<Date | null>(null),
        FechaHasta: new FormControl<Date | null>(null),
        AlmacenSerie: [''],
        MitemCodigo: [''],
        BobiCodigo: [''],
        Linea: [''],
        SubLinea: [''],
        PeriodoMes: [''],
        PeriodoAnio: [''],
        BuscarTabla:['']
      });
    this.codigoBobinaSelect= '-';
    this.getAlmacen();
    this.getLinea();
    this.getMes();
    //this.resetClaimForm(true);
  }
  getLinea(): void{
    this._reporteService.obtenerLinea()
        .subscribe(
            (response: ListLineaResponse) => {
                this.linea = response.result.linea;
                this._changeDetectorRef.markForCheck();
                console.log('Lineas kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
    }
    selectLinea(data: MatSelectChange){
      console.log("data", data);
      this.getSublinea(String(data.value));
    }
    getSublinea(codLinea: string): void{
      console.log('Sublineas kardex',codLinea);
      this._reporteService.obtenerSublinea(codLinea)
          .subscribe(
              (response: ListSublineaResponse) => {
                  this.sublinea = response.result.sublinea;
                  this._changeDetectorRef.markForCheck();
                  console.log('Sublineas kardex',codLinea);
                  console.log('Sublineas kardex',response);
              },
              (error: HttpErrorResponse) => {
                  console.log(error);
              }
          );
      }
  cleanFilter(): void{
    this.resetMateriaForm(true);
    this.clearDateRange();
    this.listado=[];
    this.codigoBobinaSelect= '-';
  }

  listarReporte(page: number = 0, size: number = 10, columnSort = 1, directionSort = 'asc'){
    
    this.isLoading = true;

    let request = new MateriaPrimaPPURequest();
    request.fechaDesde = this.materiaPForm.get('FechaDesde').value == null ? '' : moment(new Date(this.materiaPForm.get('FechaDesde').value)).format('DDMMYYYY');
    request.fechaHasta = this.materiaPForm.get('FechaHasta').value == null ? '' : moment(new Date(this.materiaPForm.get('FechaHasta').value)).add(1,'d').format('DDMMYYYY');
    request.almacenSerie = this.materiaPForm.get('AlmacenSerie').value == null ? '' : this.materiaPForm.get('AlmacenSerie').value;
    request.mitemCodigo = this.materiaPForm.get('MitemCodigo').value == null ? ''  : this.materiaPForm.get('MitemCodigo').value;
    request.bobiCodigo = this.materiaPForm.get('BobiCodigo').value == null ? ''  : this.materiaPForm.get('BobiCodigo').value;
    request.linea = this.materiaPForm.get('Linea').value == null ? '' : this.materiaPForm.get('Linea').value; 
    request.subLinea = this.materiaPForm.get('SubLinea').value == null ? '' : this.materiaPForm.get('SubLinea').value;
    request.periodoMes = this.materiaPForm.get('PeriodoMes').value == null ? '' : this.materiaPForm.get('PeriodoMes').value;
    request.periodoAnio = this.materiaPForm.get('PeriodoAnio').value == null ? '' : this.materiaPForm.get('PeriodoAnio').value; 
    request.numeroPagina = page + 1;
    request.cantidadPagina = size;
    request.columnaOrdenamiento = columnSort;
    request.direccionOrdenamiento = directionSort;

    console.log('request', request);

    this._reporteService.obtenerMateriaPrimaPPUD(request)
            .subscribe(
                (response: MateriaPrimaPPUResponse) => {

                  console.log('response', response);
                    this.isLoading = false;
                    if(response.status){

                      
                        this.listado = response.result?.materiaPrima == null ? [] : response.result.materiaPrima;

                        let pagination = {};
                        const dataLength =  response.result.totalRegistros;
                        const begin = page * size;
                        const end = Math.min((size * (page + 1)), dataLength);
                        const lastPage = Math.max(Math.ceil(dataLength / size), 1);

                            pagination = {
                                    length    : dataLength,
                                    size      : size,
                                    page      : page,
                                    lastPage  : lastPage,
                                    startIndex: begin,
                                    endIndex  : end - 1
                                };
                        this.pagination = pagination as GeneralPagination;
                        this._changeDetectorRef.markForCheck();
                    }
                },
                (error: HttpErrorResponse) => {
                    console.log(error);
                    this.isLoading = false;
                }
            );
  }
    
  searchData(){
    this.listarReporte(0, 10, 1, 'asc');
    this.codigoBobinaSelect= '-';
  }
  
  

  resetMateriaForm(option: boolean){

    if(option){
      this.materiaPForm.get('AlmacenSerie').setValue(null);
      this.materiaPForm.get('MitemCodigo').setValue('');
      this.materiaPForm.get('BobiCodigo').setValue('');
      this.materiaPForm.get('Linea').setValue('');
      this.materiaPForm.get('SubLinea').setValue('');
      this.materiaPForm.get('PeriodoMes').setValue('');
      this.materiaPForm.get('PeriodoAnio').setValue('');
      this.materiaPForm.get('BuscarTabla').setValue('');
    }
    
    
  }
  
  handlePage(e: PageEvent): PageEvent {
    this.listarReporte(e.pageIndex, e.pageSize, Number(this.sortTable.active), this.sortTable.direction);
    return e;
  }

  clearDateRange(){
    this.materiaPForm.get('FechaDesde').setValue(null);
    this.materiaPForm.get('FechaHasta').setValue(null);
  }

  eventSortTable(sort: Sort){
    console.log(sort);
    this.sortTable = {
      active : sort.active,
      direction : sort.direction
    }
    this.listarReporte(this.pagination.page, this.pagination.size, Number(sort.active), sort.direction);
  }
  getAlmacen(): void{
    this._reporteService.obtenerAlmacen()
        .subscribe(
            (response: ListAlmacenResponse) => {
                this.almacen = response.result.almacen;
                this._changeDetectorRef.markForCheck();
                console.log('almacenes MP DI',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
    }

    getMes(): void {
    
      this._reporteService.obtenerMes('DIMP')
        .subscribe(
            (response: MesResponse) => {
                this.mes = response.result;
                console.log('MESSSSSS',this.mes);
                this.materiaPForm.get('PeriodoMes').setValue(''+this.mes);
                this._changeDetectorRef.markForCheck();
                this.getAnios();
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
      this.meses = [
        {
          nombre: 'Enero',
          codigo: '01'
        },
        {
          nombre: 'Febrero',
          codigo: '02'
        },
        {
          nombre: 'Marzo',
          codigo: '03'
        },
        {
          nombre: 'Abril',
          codigo: '04'
        },
        {
          nombre: 'Mayo',
          codigo: '05'
        },
        {
          nombre: 'Junio',
          codigo: '06'
        },
        {
          nombre: 'Julio',
          codigo: '07'
        },
        {
          nombre: 'Agosto',
          codigo: '08'
        },
        {
          nombre: 'Septiembre',
          codigo: '09'
        },
        {
          nombre: 'Octubre',
          codigo: '10'
        },
        {
          nombre: 'Noviembre',
          codigo: '11'
        },
        {
          nombre: 'Diciembre',
          codigo: '12'
        }
      ];
      this.materiaPForm.get('PeriodoMes').setValue(this.mesActual);
    }
  
    getAnios() {
      let init = 2000;
      let anio = (new Date()).getFullYear();
      let diff = anio - init;
      for(let d = 0; d < diff; d++){
          this.anios.push(init + (d + 1));
      }
      this.materiaPForm.get('PeriodoAnio').setValue(anio);
    }

      touchRow(item: ItemMateriaPrimaPPU): void {

        this.codigoBobinaSelect = item.bobi_codigo.toString();
    
        this.listado.forEach((r) => {
            if(r.id == item.id){
                r.seleccionado = true;
            }else{
              r.seleccionado = false;
            }
        });
    
      }

      exportExcel(){
   
        let request = new ExportarReporteRequest();
        request.TipoReporte = 'DI-MP';
        request.FechaDesde = this.materiaPForm.get('FechaDesde').value == null ? '' : moment(new Date(this.materiaPForm.get('FechaDesde').value)).format('DDMMYYYY');
        request.FechaHasta = this.materiaPForm.get('FechaHasta').value == null ? '' : moment(new Date(this.materiaPForm.get('FechaHasta').value)).format('DDMMYYYY');
        request.AlmacenSerie = this.materiaPForm.get('AlmacenSerie').value == null ? '' : this.materiaPForm.get('AlmacenSerie').value;
        request.MitemCodigo = this.materiaPForm.get('MitemCodigo').value == '' ? 0 : this.materiaPForm.get('MitemCodigo').value;
        request.BobiCodigo = this.materiaPForm.get('BobiCodigo').value == '' ? 0 : this.materiaPForm.get('BobiCodigo').value;
        request.Linea = this.materiaPForm.get('Linea').value;
        request.SubLinea = this.materiaPForm.get('SubLinea').value;
        request.PeriodoMes = this.materiaPForm.get('PeriodoMes').value == null ? '' : this.materiaPForm.get('PeriodoMes').value;
        request.PeriodoAnio = this.materiaPForm.get('PeriodoAnio').value == null ? '' : this.materiaPForm.get('PeriodoAnio').value; 
    
        this._snackBar.openFromComponent(LoadingSnackbarComponent,{
          horizontalPosition: this.horizontalPosition,
          verticalPosition: this.verticalPosition,
        });
        this._generalService.dispProgress.emit({ message: 'Generando reporte ...', percentage: 0 });
          this._exportarService.downloadReportGeneric(request).subscribe((event) => {
            if (event.type === HttpEventType.DownloadProgress){
                this.progress = Math.round((100 * event.loaded) / event.total);
                this._generalService.dispProgress.emit({ message: 'Generando reporte ...', percentage: this.progress });
            }else if (event.type === HttpEventType.Response) {
                this._generalService.dispProgress.emit({ message: 'Reporte generado.', percentage: this.progress });
                this.getBlob(event, `Reporte_DI_MateriaPrima_${this.datePipe.transform( new Date(), 'ddMMyyyy')}.xls`);
                setTimeout(() =>
                      {
                        this._snackBar.dismiss();
                      }, 2000);
            }
        });
      }
    
      getBlob(data: HttpResponse<Blob>, fileName: string) {
        const downloadedFile = new Blob([data.body], { type: data.body.type });
        const a = document.createElement('a');
        a.setAttribute('style', 'display:none;');
        document.body.appendChild(a);
        a.download = fileName;
        a.href = URL.createObjectURL(downloadedFile);
        a.target = '_blank';
        a.click();
        document.body.removeChild(a);
      }

      public transformThousands(value: any) {
        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
      }
}
