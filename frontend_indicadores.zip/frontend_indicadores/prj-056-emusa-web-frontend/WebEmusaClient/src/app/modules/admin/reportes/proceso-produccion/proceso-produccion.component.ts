import { animate, AUTO_STYLE, state, style, transition, trigger } from '@angular/animations';
import { DatePipe } from '@angular/common';
import { HttpErrorResponse, HttpEventType, HttpResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { Sort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { ExportarReporteRequest } from 'app/shared/models/request/reporte/exportar-request.interface';
import { KardexBobinaRequest } from 'app/shared/models/request/reporte/kardex-bobina-request.interface';
import { GeneralPagination } from 'app/shared/models/response/common/general-response.interface';
import { AlmacenResponse, ItemAlmacen, ListAlmacenResponse } from 'app/shared/models/response/reporte/almacen.interface';
import { AniosResponse, Mes, MesResponse } from 'app/shared/models/response/reporte/common.interface';
import { GeneralService } from 'app/shared/services/common/general.service';
import { ExportarService } from 'app/shared/services/reporte/exportar.service';
import { ReporteService } from 'app/shared/services/reporte/reporte.service';
import moment from 'moment';
import { LoadingSnackbarComponent } from '../../common/loading-snackbar/loading-snackbar.component';
const DEFAULT_DURATION = 300;
import { ItemProcesoProduccion, ProcesoProduccionResponse } from 'app/shared/models/response/reporte/proceso-de-produccion.interface';
import { ProcesoProduccionRequest } from 'app/shared/models/request/reporte/proceso-de-produccion-request.interface';
import { ItemLinea, ListLineaResponse } from 'app/shared/models/response/reporte/linea.interface';
import { MatSelectChange } from '@angular/material/select';
import { ItemSublinea, ListSublineaResponse } from 'app/shared/models/response/reporte/sublinea.interface';

@Component({
  selector: 'app-proceso-produccion',
  templateUrl: './proceso-produccion.component.html',
  styleUrls: ['./proceso-produccion.component.scss'],
  styles: [
    `
        .content-grid {
            grid-template-columns: 80px 80px 100px 200px 100px 200px 100px 100px 100px 80px ;

            @screen sm {
                grid-template-columns: 80px 90px 100px 200px 100px 200px 100px 100px 100px 80px;
            }

            @screen md {
                grid-template-columns: 80px 110px 100px 200px 100px 200px 100px 100px 100px 80px;
            }

            @screen lg {
                grid-template-columns: 80px 120px 100px 200px 100px 200px 100px 100px 100px 80px;
            }
        }
    `
  ],
  animations: [
    trigger('collapse', [
      state('false', style({ height: AUTO_STYLE, visibility: AUTO_STYLE })),
      state('true', style({ height: '0', visibility: 'hidden' })),
      transition('false => true', animate(DEFAULT_DURATION + 'ms ease-in')),
      transition('true => false', animate(DEFAULT_DURATION + 'ms ease-out'))
    ])
  ],
  providers: [DatePipe]
})
export class ProcesoProduccionComponent implements OnInit {
  collapsed = false;
  title = "Proceso de Produccion";
  almacen: ItemAlmacen[]=[];
  listado: ItemProcesoProduccion[] = [];
  anios: number[]=[];
  meses: Mes[]=[];
  mesActual: string;
  mes: string[]=[];
  anioActual: string;
  linea: ItemLinea[]=[];
  sublinea: ItemSublinea[]=[];
  codigoBobinaSelect: string = '-';
  pagination: GeneralPagination = new GeneralPagination();
  procesoPForm: FormGroup;
  isLoading: boolean = false;
  sortTable: Sort = {
    active: '1',
    direction: 'asc'
  }
  public progress: number;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: FormBuilder,
    private _snackBar: MatSnackBar,
    private _reporteService: ReporteService,
    private _exportarService: ExportarService,
    private _generalService: GeneralService,
    private datePipe: DatePipe,
    private _router: Router
  ) { }

  ngOnInit(): void {
    
    this.procesoPForm = this._formBuilder.group({
      FechaDesde: new FormControl<Date | null>(null),
      FechaHasta: new FormControl<Date | null>(null),
      AlmacenSerie: [''],
      MitemCodigo: [''],
      BobiCodigo: [''],
      OrdenTrabajo: [''],
      PeriodoMes: [''],
      PeriodoAnio: [''],
      BuscarTabla: ['']
    });
    this.getAlmacen();
    this.getMes();
  }
  
  getAlmacen(): void{
    this._reporteService.obtenerAlmacen()
        .subscribe(
            (response: ListAlmacenResponse) => {
                this.almacen = response.result.almacen;
                this._changeDetectorRef.markForCheck();
                console.log('almacenes kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
    }

  cleanFilter(): void{
    this.resetprocesoPForm(true);
    this.clearDateRange();
    this.listado=[];
    this.codigoBobinaSelect= '-';
  }
  listarReporte(page: number = 0, size: number = 10, columnSort = 1, directionSort = 'asc') {

    this.isLoading = true;

    let request = new ProcesoProduccionRequest();
    request.fechaDesde = this.procesoPForm.get('FechaDesde').value == null ? '' : moment(new Date(this.procesoPForm.get('FechaDesde').value)).format('DDMMYYYY');
    request.fechaHasta = this.procesoPForm.get('FechaHasta').value == null ? '' : moment(new Date(this.procesoPForm.get('FechaHasta').value)).add(1,'d').format('DDMMYYYY');
    request.almacenSerie = this.procesoPForm.get('AlmacenSerie').value == null ? '' : this.procesoPForm.get('AlmacenSerie').value;
    request.mitemCodigo = this.procesoPForm.get('MitemCodigo').value == '' ? 0 : this.procesoPForm.get('MitemCodigo').value;
    request.bobiCodigo = this.procesoPForm.get('BobiCodigo').value == '' ? 0 : this.procesoPForm.get('BobiCodigo').value;
    request.ordenTrabajo = this.procesoPForm.get('OrdenTrabajo').value == null ? '' : this.procesoPForm.get('OrdenTrabajo').value;
    request.periodoMes = this.procesoPForm.get('PeriodoMes').value == null ? '' : this.procesoPForm.get('PeriodoMes').value;
    request.periodoAnio = this.procesoPForm.get('PeriodoAnio').value == null ? '' : this.procesoPForm.get('PeriodoAnio').value; 
    request.numeroPagina = page + 1;
    request.cantidadPagina = size;
    request.columnaOrdenamiento = columnSort;
    request.direccionOrdenamiento = directionSort;

    console.log('requestProceso', request);

    this._reporteService.obtenerProcesoProduccion(request)
      .subscribe(
        (response: ProcesoProduccionResponse) => {

          console.log('responseProceso', response);
          this.isLoading = false;
          if (response.status) {
            this.listado = response.result?.procesoProduccion == null ? [] : response.result.procesoProduccion;

            let pagination = {};
            const dataLength = response.result.totalRegistros;
            const begin = page * size;
            const end = Math.min((size * (page + 1)), dataLength);
            const lastPage = Math.max(Math.ceil(dataLength / size), 1);

            pagination = {
              length: dataLength,
              size: size,
              page: page,
              lastPage: lastPage,
              startIndex: begin,
              endIndex: end - 1
            };
            this.pagination = pagination as GeneralPagination;
            this._changeDetectorRef.markForCheck();

            console.log('listado', this.listado);
          }
        },
        (error: HttpErrorResponse) => {
          console.log(error);
          this.isLoading = false;
        }
      );
  }

  searchData() {
    this.listarReporte(0, 10, 1, 'asc');
    this.codigoBobinaSelect= '-';
  }

  resetprocesoPForm(option: boolean) {

    if (option) {
      this.procesoPForm.get('AlmacenSerie').setValue(null);
      this.procesoPForm.get('MitemCodigo').setValue('');
      this.procesoPForm.get('BobiCodigo').setValue('');
      this.procesoPForm.get('OrdenTrabajo').setValue('');
      this.procesoPForm.get('PeriodoMes').setValue('');
      this.procesoPForm.get('PeriodoAnio').setValue('');
      this.procesoPForm.get('BuscarTabla').setValue('');
    }


  }

  handlePage(e: PageEvent): PageEvent {
    this.listarReporte(e.pageIndex, e.pageSize, Number(this.sortTable.active), this.sortTable.direction);
    return e;
  }

  clearDateRange() {
    this.procesoPForm.get('FechaDesde').setValue(null);
    this.procesoPForm.get('FechaHasta').setValue(null);
  }

  eventSortTable(sort: Sort) {
    console.log(sort);
    this.sortTable = {
      active: sort.active,
      direction: sort.direction
    }
    this.listarReporte(this.pagination.page, this.pagination.size, Number(sort.active), sort.direction);
  }

  touchRow(item: ItemProcesoProduccion): void {

    this.codigoBobinaSelect = item.maquina_codigo.toString();

    this.listado.forEach((r) => {
        if(r.id == item.id){
            r.seleccionado = true;
        }else{
          r.seleccionado = false;
        }
    });

  }

  getMes(): void {
    
    this._reporteService.obtenerMes('PPR')
        .subscribe(
            (response: MesResponse) => {
                this.mes = response.result;
                this.procesoPForm.get('PeriodoMes').setValue(''+this.mes);
                this._changeDetectorRef.markForCheck();
                this.getAnios();
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
    this.meses = [
      {
        nombre: 'Enero',
        codigo: '01'
      },
      {
        nombre: 'Febrero',
        codigo: '02'
      },
      {
        nombre: 'Marzo',
        codigo: '03'
      },
      {
        nombre: 'Abril',
        codigo: '04'
      },
      {
        nombre: 'Mayo',
        codigo: '05'
      },
      {
        nombre: 'Junio',
        codigo: '06'
      },
      {
        nombre: 'Julio',
        codigo: '07'
      },
      {
        nombre: 'Agosto',
        codigo: '08'
      },
      {
        nombre: 'Septiembre',
        codigo: '09'
      },
      {
        nombre: 'Octubre',
        codigo: '10'
      },
      {
        nombre: 'Noviembre',
        codigo: '11'
      },
      {
        nombre: 'Diciembre',
        codigo: '12'
      }
    ];
    
  }

  getAnios() {
    let init = 2000;
    let anio = (new Date()).getFullYear();
    let diff = anio - init;
    for(let d = 0; d < diff; d++){
        this.anios.push(init + (d + 1));
    }
    this.procesoPForm.get('PeriodoAnio').setValue(anio);
  }

    exportExcel(){
   
      let request = new ExportarReporteRequest();
      request.TipoReporte = 'PP-R';

      request.FechaDesde = this.procesoPForm.get('fechaDesde').value == null ? '' : moment(new Date(this.procesoPForm.get('fechaDesde').value)).format('DDMMYYYY');
      request.FechaHasta = this.procesoPForm.get('fechaHasta').value == null ? '' : moment(new Date(this.procesoPForm.get('fechaHasta').value)).format('DDMMYYYY');
      request.AlmacenSerie = this.procesoPForm.get('almacenSerie').value == null ? '':this.procesoPForm.get('almacenSerie').value;
      request.MitemCodigo = this.procesoPForm.get('mitemCodigo').value == '' ? 0 :this.procesoPForm.get('mitemCodigo').value;
      request.BobiCodigo = this.procesoPForm.get('bobiCodigo').value == '' ? 0 :this.procesoPForm.get('bobiCodigo').value;
      request.OrdenTrabajo = this.procesoPForm.get('ordenTrabajo').value;
      request.PeriodoMes = this.procesoPForm.get('periodoMes').value == null ? '' : this.procesoPForm.get('periodoMes').value;
      request.PeriodoAnio = this.procesoPForm.get('periodoAnio').value == null ? '' : this.procesoPForm.get('periodoAnio').value;
  
      this._snackBar.openFromComponent(LoadingSnackbarComponent,{
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
      });
      this._generalService.dispProgress.emit({ message: 'Generando reporte ...', percentage: 0 });
        this._exportarService.downloadReportGeneric(request).subscribe((event) => {
          if (event.type === HttpEventType.DownloadProgress){
              this.progress = Math.round((100 * event.loaded) / event.total);
              this._generalService.dispProgress.emit({ message: 'Generando reporte ...', percentage: this.progress });
          }else if (event.type === HttpEventType.Response) {
              this._generalService.dispProgress.emit({ message: 'Reporte generado.', percentage: this.progress });
              this.getBlob(event, `Reporte_ProcesoProduccion_${this.datePipe.transform( new Date(), 'ddMMyyyy')}.xls`);
              setTimeout(() =>
                    {
                      this._snackBar.dismiss();
                    }, 2000);
          }
      });
    }
  
    getBlob(data: HttpResponse<Blob>, fileName: string) {
      const downloadedFile = new Blob([data.body], { type: data.body.type });
      const a = document.createElement('a');
      a.setAttribute('style', 'display:none;');
      document.body.appendChild(a);
      a.download = fileName;
      a.href = URL.createObjectURL(downloadedFile);
      a.target = '_blank';
      a.click();
      
}

public transformThousands(value: any) {
  return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

}
