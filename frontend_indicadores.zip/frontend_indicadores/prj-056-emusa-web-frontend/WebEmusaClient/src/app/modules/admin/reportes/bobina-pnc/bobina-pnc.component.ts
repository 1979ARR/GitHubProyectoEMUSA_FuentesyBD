import { animate, AUTO_STYLE, state, style, transition, trigger } from '@angular/animations';
import { DatePipe } from '@angular/common';
import { HttpErrorResponse, HttpEventType, HttpResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { Sort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { BobinaPncRequest } from 'app/shared/models/request/reporte/bobina-con-pnc-request.interface';
import { ExportarReporteRequest } from 'app/shared/models/request/reporte/exportar-request.interface';
import { KardexBobinaRequest } from 'app/shared/models/request/reporte/kardex-bobina-request.interface';
import { GeneralPagination } from 'app/shared/models/response/common/general-response.interface';
import { AlmacenResponse, ItemAlmacen, ListAlmacenResponse } from 'app/shared/models/response/reporte/almacen.interface';
import { BobinaPncResponse, ItemBobinaPnc } from 'app/shared/models/response/reporte/bobina-con-pnc.interface';
import { AniosResponse, Mes, MesResponse } from 'app/shared/models/response/reporte/common.interface';
import { ItemKardexBobina, KardexBobinaResponse } from 'app/shared/models/response/reporte/kardex-bobina.interface';
import { ItemLinea, ListLineaResponse } from 'app/shared/models/response/reporte/linea.interface';
import { ItemSublinea, ListSublineaResponse } from 'app/shared/models/response/reporte/sublinea.interface';
import { GeneralService } from 'app/shared/services/common/general.service';
import { ExportarService } from 'app/shared/services/reporte/exportar.service';
import { ReporteService } from 'app/shared/services/reporte/reporte.service';
import moment from 'moment';
import { LoadingSnackbarComponent } from '../../common/loading-snackbar/loading-snackbar.component';
const DEFAULT_DURATION = 300;

@Component({
  selector: 'app-bobina-pnc',
  templateUrl: './bobina-pnc.component.html',
  styleUrls: ['./bobina-pnc.component.scss'],
  styles: [
    `
        .content-grid {
            grid-template-columns: 80px 80px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px;

            @screen sm {
                grid-template-columns: 80px 90px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px;
            }

            @screen md {
                grid-template-columns: 80px 110px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px;
            }

            @screen lg {
                grid-template-columns: 80px 120px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px 100px;
            }
        }
    `
  ],
  animations: [
    trigger('collapse', [
      state('false', style({ height: AUTO_STYLE, visibility: AUTO_STYLE })),
      state('true', style({ height: '0', visibility: 'hidden' })),
      transition('false => true', animate(DEFAULT_DURATION + 'ms ease-in')),
      transition('true => false', animate(DEFAULT_DURATION + 'ms ease-out'))
    ])
  ],
  providers: [DatePipe]
})
export class BobinaPncComponent implements OnInit {

  collapsed = false;
  title = "Bobina PNC";
  almacen: ItemAlmacen[]=[];
  listado: ItemBobinaPnc[] = [];
  anios: number[]=[];
  mes: string[]=[];
  meses: Mes[]=[];
  mesActual: string;
  anioActual: string;
  linea: ItemLinea[]=[];
  sublinea: ItemSublinea[]=[];
  codigoBobinaSelect: string = '-';
  pagination: GeneralPagination = new GeneralPagination();
  bobinaPNCForm: FormGroup;
  isLoading: boolean = false;
  sortTable: Sort = {
    active: '1',
    direction: 'asc'
  }
  public progress: number;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: FormBuilder,
    private _snackBar: MatSnackBar,
    private _reporteService: ReporteService,
    private _exportarService: ExportarService,
    private _generalService: GeneralService,
    private datePipe: DatePipe,
    private _router: Router
  ) { }

  ngOnInit(): void {
    
    this.bobinaPNCForm = this._formBuilder.group({
      FechaDesde: new FormControl<Date | null>(null),
      FechaHasta: new FormControl<Date | null>(null),
      AlmacenSerie: [''],
      MitemCodigo: [''],
      BobiCodigo: [''],
      Linea: [''],
      SubLinea: [''],
      PeriodoMes: [''],
      PeriodoAnio: [''],
      Estado: [''],
      BuscarTabla: ['']
    });
    console.log('ANIOACTUAL',this.anioActual);
    this.getAlmacen();
    this.getLinea();
    this.getMes();
    
  }
  getLinea(): void{
    this._reporteService.obtenerLinea()
        .subscribe(
            (response: ListLineaResponse) => {
                this.linea = response.result.linea;
                this._changeDetectorRef.markForCheck();
                console.log('Lineas kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
    }
    selectLinea(data: MatSelectChange){
      console.log("data", data);
      this.getSublinea(String(data.value));
    }
    getSublinea(codLinea: string): void{
      console.log('Sublineas kardex',codLinea);
      this._reporteService.obtenerSublinea(codLinea)
          .subscribe(
              (response: ListSublineaResponse) => {
                  this.sublinea = response.result.sublinea;
                  this._changeDetectorRef.markForCheck();
                  console.log('Sublineas kardex',codLinea);
                  console.log('Sublineas kardex',response);
              },
              (error: HttpErrorResponse) => {
                  console.log(error);
              }
          );
      }
  getAlmacen(): void{
    this._reporteService.obtenerAlmacen()
        .subscribe(
            (response: ListAlmacenResponse) => {
                this.almacen = response.result.almacen;
                this._changeDetectorRef.markForCheck();
                console.log('almacenes kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
    }

  cleanFilter(): void{
    this.resetbobinaPNCForm(true);
    this.clearDateRange();
    this.listado=[];
    this.codigoBobinaSelect= '-';
  }
  listarReporte(page: number = 0, size: number = 10, columnSort = 1, directionSort = 'asc') {

    this.isLoading = true;

    let request = new BobinaPncRequest();
    let lineaCodigo =this.bobinaPNCForm.get('Linea').value;
    let sublineaCodigo =this.bobinaPNCForm.get('SubLinea').value;
    request.fechaDesde = this.bobinaPNCForm.get('FechaDesde').value == null ? '' : moment(new Date(this.bobinaPNCForm.get('FechaDesde').value)).format('DDMMYYYY');
    request.fechaHasta = this.bobinaPNCForm.get('FechaHasta').value == null ? '' : moment(new Date(this.bobinaPNCForm.get('FechaHasta').value)).add(1,'d').format('DDMMYYYY');
    request.almacenSerie = this.bobinaPNCForm.get('AlmacenSerie').value == null ? '' : this.bobinaPNCForm.get('AlmacenSerie').value;
    request.mitemCodigo = this.bobinaPNCForm.get('MitemCodigo').value == null ? ''  : this.bobinaPNCForm.get('MitemCodigo').value;
    request.bobiCodigo = this.bobinaPNCForm.get('BobiCodigo').value == null ? ''  : this.bobinaPNCForm.get('BobiCodigo').value;
    if(lineaCodigo=='' || lineaCodigo== null){request.linea = '';}
    else{
    request.linea = this.linea.find(l => l.lineaCodigo == lineaCodigo).lineaDescripcion;
      console.log('LINEA REQUEST',request.linea);}
      if(sublineaCodigo=='' || sublineaCodigo == null){request.subLinea = '';}
    else{
    request.subLinea = this.sublinea.find(s => s.sublineaCodigo == sublineaCodigo).sublineaDescripcion;
      console.log('LINEA REQUEST',request.subLinea);}
    request.periodoMes = this.bobinaPNCForm.get('PeriodoMes').value == null ? '' : this.bobinaPNCForm.get('PeriodoMes').value;
    request.periodoAnio = this.bobinaPNCForm.get('PeriodoAnio').value == null ? '' : this.bobinaPNCForm.get('PeriodoAnio').value; 
    request.numeroPagina = page + 1;
    request.cantidadPagina = size;
    request.columnaOrdenamiento = columnSort;
    request.direccionOrdenamiento = directionSort;

    console.log('request', request);

    this._reporteService.obtenerBobinaPnc(request)
      .subscribe(
        (response: BobinaPncResponse) => {
          
          console.log('responseeeee', response);
          this.isLoading = false;
          if (response.status) {
            this.listado = response.result?.bobinaConPNC == null ? [] : response.result.bobinaConPNC;
            let pagination = {};
            const dataLength = response.result.totalRegistros;
            const begin = page * size;
            const end = Math.min((size * (page + 1)), dataLength);
            const lastPage = Math.max(Math.ceil(dataLength / size), 1);

            pagination = {
              length: dataLength,
              size: size,
              page: page,
              lastPage: lastPage,
              startIndex: begin,
              endIndex: end - 1
            };
            console.log('LISTADO',this.listado);
            this.pagination = pagination as GeneralPagination;
            this._changeDetectorRef.markForCheck();
          }
        },
        (error: HttpErrorResponse) => {
          console.log(error);
          this.isLoading = false;
        }
      );
  }

  searchData() {
    this.listarReporte(0, 10, 1, 'asc');
    this.codigoBobinaSelect= '-';
  }

  resetbobinaPNCForm(option: boolean) {

    if (option) {
      this.bobinaPNCForm.get('AlmacenSerie').setValue(null);
      this.bobinaPNCForm.get('MitemCodigo').setValue('');
      this.bobinaPNCForm.get('BobiCodigo').setValue('');
      this.bobinaPNCForm.get('Linea').setValue('');
      this.bobinaPNCForm.get('SubLinea').setValue('');
      this.bobinaPNCForm.get('PeriodoMes').setValue('');
      this.bobinaPNCForm.get('PeriodoAnio').setValue('');
      this.bobinaPNCForm.get('BuscarTabla').setValue('');
    }


  }

  handlePage(e: PageEvent): PageEvent {
    this.listarReporte(e.pageIndex, e.pageSize, Number(this.sortTable.active), this.sortTable.direction);
    return e;
  }

  clearDateRange() {
    this.bobinaPNCForm.get('FechaDesde').setValue(null);
    this.bobinaPNCForm.get('FechaHasta').setValue(null);
  }

  eventSortTable(sort: Sort) {
    console.log(sort);
    this.sortTable = {
      active: sort.active,
      direction: sort.direction
    }
    this.listarReporte(this.pagination.page, this.pagination.size, Number(sort.active), sort.direction);
  }

  touchRow(item: ItemBobinaPnc): void {

    this.codigoBobinaSelect = item.bobi_codigo.toString();

    this.listado.forEach((r) => {
        if(r.id == item.id){
            r.seleccionado = true;
        }else{
          r.seleccionado = false;
        }
    });

  }

  getMes(): void {
    
    /*var dateDay = new Date();
    if(dateDay.getMonth()+1<10){this.mesActual="0"+(dateDay.getMonth()+1);}
    else{this.mesActual=""+(dateDay.getMonth()+1);}
    */
    
    this._reporteService.obtenerMes('BPNC')
        .subscribe(
            (response: MesResponse) => {
                this.mes = response.result;
                console.log('MESSSSSSbobina',this.mes);
                this.bobinaPNCForm.get('PeriodoMes').setValue(''+this.mes);
                this._changeDetectorRef.markForCheck();
                this.getAnios();
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
    this.meses = [
      {
        nombre: 'Enero',
        codigo: '01'
      },
      {
        nombre: 'Febrero',
        codigo: '02'
      },
      {
        nombre: 'Marzo',
        codigo: '03'
      },
      {
        nombre: 'Abril',
        codigo: '04'
      },
      {
        nombre: 'Mayo',
        codigo: '05'
      },
      {
        nombre: 'Junio',
        codigo: '06'
      },
      {
        nombre: 'Julio',
        codigo: '07'
      },
      {
        nombre: 'Agosto',
        codigo: '08'
      },
      {
        nombre: 'Septiembre',
        codigo: '09'
      },
      {
        nombre: 'Octubre',
        codigo: '10'
      },
      {
        nombre: 'Noviembre',
        codigo: '11'
      },
      {
        nombre: 'Diciembre',
        codigo: '12'
      }
    ];
    
  }

  getAnios() {
    let init = 2000;
    let anio = (new Date()).getFullYear();
    let diff = anio - init;
    for(let d = 0; d < diff; d++){
        this.anios.push(init + (d + 1));
    }
    this.bobinaPNCForm.get('PeriodoAnio').setValue(anio);
  }

    exportExcel(){
   
      let request = new ExportarReporteRequest();
      request.TipoReporte = 'BPNC-R';
      request.FechaDesde = this.bobinaPNCForm.get('fechaDesde').value == null ? '' : moment(new Date(this.bobinaPNCForm.get('fechaDesde').value)).format('DDMMYYYY');
      request.FechaHasta = this.bobinaPNCForm.get('fechaHasta').value == null ? '' : moment(new Date(this.bobinaPNCForm.get('fechaHasta').value)).format('DDMMYYYY');
      request.AlmacenSerie = this.bobinaPNCForm.get('almacenSerie').value == null ? '':this.bobinaPNCForm.get('almacenSerie').value;
      request.MitemCodigo = this.bobinaPNCForm.get('mitemCodigo').value == '' ? 0 :this.bobinaPNCForm.get('mitemCodigo').value;
      request.BobiCodigo = this.bobinaPNCForm.get('bobiCodigo').value == '' ? 0 :this.bobinaPNCForm.get('bobiCodigo').value;
      request.Linea = this.bobinaPNCForm.get('linea').value;
      request.SubLinea = this.bobinaPNCForm.get('sublinea').value;
      request.PeriodoMes = this.bobinaPNCForm.get('periodoMes').value == null ? '' : this.bobinaPNCForm.get('periodoMes').value;
      request.PeriodoAnio = this.bobinaPNCForm.get('periodoAnio').value == null ? '' : this.bobinaPNCForm.get('periodoAnio').value;
  
      this._snackBar.openFromComponent(LoadingSnackbarComponent,{
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
      });
      this._generalService.dispProgress.emit({ message: 'Generando reporte ...', percentage: 0 });
        this._exportarService.downloadReportGeneric(request).subscribe((event) => {
          if (event.type === HttpEventType.DownloadProgress){
              this.progress = Math.round((100 * event.loaded) / event.total);
              this._generalService.dispProgress.emit({ message: 'Generando reporte ...', percentage: this.progress });
          }else if (event.type === HttpEventType.Response) {
              this._generalService.dispProgress.emit({ message: 'Reporte generado.', percentage: this.progress });
              this.getBlob(event, `Reporte_BobinaPNC_${this.datePipe.transform( new Date(), 'ddMMyyyy')}.xls`);
              setTimeout(() =>
                    {
                      this._snackBar.dismiss();
                    }, 2000);
          }
      });
    }
  
    getBlob(data: HttpResponse<Blob>, fileName: string) {
      const downloadedFile = new Blob([data.body], { type: data.body.type });
      const a = document.createElement('a');
      a.setAttribute('style', 'display:none;');
      document.body.appendChild(a);
      a.download = fileName;
      a.href = URL.createObjectURL(downloadedFile);
      a.target = '_blank';
      a.click();
      document.body.removeChild(a);
    }

    public transformThousands(value: any) {
        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    
}
