import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BasicSnackbarComponent } from './basic-snackbar.component';
import { MatIconModule } from '@angular/material/icon';



@NgModule({
  declarations: [
    BasicSnackbarComponent
  ],
  imports: [
    CommonModule,
    MatIconModule
  ]
})
export class BasicSnackbarModule { }
