import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSelectChange } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Chart } from 'angular-highcharts';
import { IndicadorFIFORequest } from 'app/shared/models/request/indicador/indicador-fifo-request.interface';
import { IndicadorFIFO, IndicadorFIFOResponse } from 'app/shared/models/response/indicador/indicadores-response.interface';
import { ItemAlmacen, ListAlmacenResponse } from 'app/shared/models/response/reporte/almacen.interface';
import { ItemLinea, ListLineaResponse } from 'app/shared/models/response/reporte/linea.interface';
import { ItemSublinea, ListSublineaResponse } from 'app/shared/models/response/reporte/sublinea.interface';
import { IndicadorService } from 'app/shared/services/indicador/indicador.service';
import { ReporteService } from 'app/shared/services/reporte/reporte.service';

@Component({
  selector: 'app-fifo',
  templateUrl: './fifo.component.html',
  styleUrls: ['./fifo.component.scss']
})
export class FifoComponent implements OnInit {

  fifoForm: FormGroup;
  chart: Chart;
  almacen: ItemAlmacen[]=[];
  linea: ItemLinea[]=[];
  sublinea: ItemSublinea[]=[];
  dataTempRefTable: IndicadorFIFO;

  isLoading: boolean = false;

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: FormBuilder,
    private _reporteService: ReporteService,
    private _indicadorService: IndicadorService) { }

  ngOnInit(): void {
    
    this.fifoForm = this._formBuilder.group({
      AlmacenSerie: [''],
      SubAlmacen: [''],
      Linea: [''],
      SubLinea: [''],
    });

    this.fifoForm.get('SubAlmacen').setValue('MP');
    this.getDataGraphic();
    this.getAlmacen();
    this.getLinea();
  }
  
  getLinea(): void{
    this._reporteService.obtenerLinea()
        .subscribe(
            (response: ListLineaResponse) => {
                this.linea = response.result.linea;
                this._changeDetectorRef.markForCheck();
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
  }

  selectLinea(data: MatSelectChange){
      this.fifoForm.get('SubLinea').setValue('');
      this.getDataGraphic();
      this.getSublinea(String(data.value));
  }

  getSublinea(codLinea: string): void{
      console.log('Sublineas kardex',codLinea);
      this._reporteService.obtenerSublinea(codLinea)
          .subscribe(
              (response: ListSublineaResponse) => {
                  this.sublinea = response.result.sublinea;
                  this._changeDetectorRef.markForCheck();
                  console.log('Sublineas kardex',codLinea);
                  console.log('Sublineas kardex',response);
              },
              (error: HttpErrorResponse) => {
                  console.log(error);
              }
          );
  }

  getAlmacen(): void{
    this._reporteService.obtenerAlmacen()
        .subscribe(
            (response: ListAlmacenResponse) => {
                this.almacen = response.result.almacen;
                this._changeDetectorRef.markForCheck();
                console.log('almacenes kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
  }

  cleanFilter(): void{
      this.fifoForm.get('AlmacenSerie').setValue(null);
      this.fifoForm.get('Linea').setValue('');
      this.fifoForm.get('SubLinea').setValue('');
  }

  loadChart(data: IndicadorFIFO){
    
    this.dataTempRefTable = data;

    let total = data.valor1 + data.valor2 + data.valor3 + data.valor4 + data.valor5 + data.valor6;
    let perValue1 = (data.valor1 * 100) / total;
    let perValue2 = (data.valor2 * 100) / total;
    let perValue3 = (data.valor3 * 100) / total;
    let perValue4 = (data.valor4 * 100) / total;
    let perValue5 = (data.valor5 * 100) / total;
    let perValue6 = (data.valor6 * 100) / total;

    let series = [];

    if(data.valor1 > 0){
      series.push({
          name: '- 30 días',
          y: perValue1,
          value: this.transformThousands(data.valor1.toFixed(3)),
          color: '#45d87d'
      });
    }

    if(data.valor2 > 0){
      series.push({
          name: '30 a 60 días',
          y: perValue2,
          value: this.transformThousands(data.valor2.toFixed(3)),
          color: '#ffb45d'
      });
    }
    
    if(data.valor3 > 0){
      series.push({
          name: '60 a 90 días',
          y: perValue3,
          value: this.transformThousands(data.valor3.toFixed(3)),
          color: '#29b3c5'
      });
    }
    
    if(data.valor4 > 0){
      series.push({
          name: '90 a 180 días',
          y: perValue4,
          value: this.transformThousands(data.valor4.toFixed(3)),
          color: '#203dbe'
      });
    }
    
    if(data.valor5 > 0){
      series.push({
          name: '180 a 365 días',
          y: perValue5,
          value: this.transformThousands(data.valor5.toFixed(3)),
          color: '#ad57a6'
      });
    }
    
    if(data.valor6 > 0){
      series.push({
          name: '+ 365 días',
          y: perValue6,
          value: this.transformThousands(data.valor6.toFixed(3)),
          color: '#eb2f2f'
      });
    }
   
    let chart = new Chart({
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: null,
            align: 'center'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.value}</b>'
        },
        accessibility: {
            announceNewData: {
              enabled: true
          },
          point: {
              valueSuffix: '%'
          }
        },
        plotOptions: {
                series: {
                dataLabels: {
                    enabled: true,
                    format: '{point.name}: {point.y:.1f}%'
                }
            }
        },
        series: [{
            type: 'pie',
            name: 'Valor',
            colorByPoint: true,
            data: series
            // data: [ {
            //             name: '- 30 días',
            //             y: perValue1,
            //             value: this.transformThousands(data.valor1.toFixed(3)),
            //             color: '#45d87d'
            //         }, {
            //             name: '30 a 60 días',
            //             y: perValue2,
            //             value: this.transformThousands(data.valor2.toFixed(3)),
            //             color: '#ffb45d'
            //         }, {
            //             name: '60 a 90 días',
            //             y: perValue3,
            //             value: this.transformThousands(data.valor3.toFixed(3)),
            //             color: '#29b3c5'
            //         }, {
            //             name: '90 a 180 días',
            //             y: perValue4,
            //             value: this.transformThousands(data.valor4.toFixed(3)),
            //             color: '#203dbe'
            //         }, {
            //             name: '180 a 365 días',
            //             y: perValue5,
            //             value: this.transformThousands(data.valor5.toFixed(3)),
            //             color: '#ad57a6'
            //         }, {
            //             name: '+ 365 días',
            //             y: perValue6,
            //             value: this.transformThousands(data.valor6.toFixed(3)),
            //             color: '#eb2f2f'
            //       }]
        }]
    });
    this.chart = chart;
  }

  clearDateRange(){
    this.fifoForm.get('fechaDesde').setValue(null);
    this.fifoForm.get('fechaHasta').setValue(null);
  }

  getDataGraphic() {
   
    this.isLoading = true;
    let request = new IndicadorFIFORequest();
    request.almacen = this.fifoForm.get('AlmacenSerie').value != null ? this.fifoForm.get('AlmacenSerie').value : '';
    request.subAlmacen = this.fifoForm.get('SubAlmacen').value != null ? this.fifoForm.get('SubAlmacen').value : '';
    request.linea = this.fifoForm.get('Linea').value != null ? this.fifoForm.get('Linea').value : '';
    request.subLinea = this.fifoForm.get('SubLinea').value != null ? this.fifoForm.get('SubLinea').value : '';

    this._indicadorService.ObtenerDatosFIFO(request)
    .subscribe(
      (response: IndicadorFIFOResponse) => {
       
       this.isLoading = false;
        this.loadChart(response.result);
      },
      (error: HttpErrorResponse) => {
        console.log(error);
        this.isLoading = false;
      }
    );

  }

  refresh(){
    this.getDataGraphic();
  }

  public transformThousands(value: any) {
    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

}
