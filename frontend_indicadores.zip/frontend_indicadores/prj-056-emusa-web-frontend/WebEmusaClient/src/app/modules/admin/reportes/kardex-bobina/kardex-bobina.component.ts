import { animate, AUTO_STYLE, state, style, transition, trigger } from '@angular/animations';
import { DatePipe } from '@angular/common';
import { HttpErrorResponse, HttpEventType, HttpResponse } from '@angular/common/http';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { Sort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { ExportarReporteRequest } from 'app/shared/models/request/reporte/exportar-request.interface';
import { KardexBobinaRequest } from 'app/shared/models/request/reporte/kardex-bobina-request.interface';
import { GeneralPagination } from 'app/shared/models/response/common/general-response.interface';
import { AlmacenResponse, ItemAlmacen, ListAlmacenResponse } from 'app/shared/models/response/reporte/almacen.interface';
import { AniosResponse, Mes, MesResponse } from 'app/shared/models/response/reporte/common.interface';
import { ItemKardexBobina, KardexBobinaResponse } from 'app/shared/models/response/reporte/kardex-bobina.interface';
import { ItemLinea, ListLineaResponse } from 'app/shared/models/response/reporte/linea.interface';
import { ItemSublinea, ListSublineaResponse } from 'app/shared/models/response/reporte/sublinea.interface';
import { GeneralService } from 'app/shared/services/common/general.service';
import { ExportarService } from 'app/shared/services/reporte/exportar.service';
import { ReporteService } from 'app/shared/services/reporte/reporte.service';
import { toInteger, toNumber } from 'lodash';
import moment from 'moment';
import { LoadingSnackbarComponent } from '../../common/loading-snackbar/loading-snackbar.component';
const DEFAULT_DURATION = 300;
@Component({
  selector: 'app-kardex-bobina',
  templateUrl: './kardex-bobina.component.html',
  styleUrls: ['./kardex-bobina.component.scss'],
  styles: [
    `
        .content-grid {
            grid-template-columns: 80px 80px 100px 100px 100px 100px 100px 100px 100px 100px 250px 100px 100px 100px 100px;

            @screen sm {
                grid-template-columns: 80px 90px 100px 100px 100px 100px 100px 100px 100px 100px 250px 100px 100px 100px 100px;
            }

            @screen md {
                grid-template-columns: 80px 110px 100px 100px 100px 100px 100px 100px 100px 100px 250px 100px 100px 100px 100px;
            }

            @screen lg {
                grid-template-columns: 80px 120px 100px 100px 100px 100px 100px 100px 100px 100px 250px 100px 100px 100px 100px;
            }
        }
    `
  ],
  animations: [
    trigger('collapse', [
      state('false', style({ height: AUTO_STYLE, visibility: AUTO_STYLE })),
      state('true', style({ height: '0', visibility: 'hidden' })),
      transition('false => true', animate(DEFAULT_DURATION + 'ms ease-in')),
      transition('true => false', animate(DEFAULT_DURATION + 'ms ease-out'))
    ])
  ],
  providers: [DatePipe]
})
export class KardexBobinaComponent implements OnInit {

  collapsed = false;
  title = "Kardex Bobina";
  almacen: ItemAlmacen[]=[];
  linea: ItemLinea[]=[];
  sublinea: ItemSublinea[]=[];
  listado: ItemKardexBobina[] = [];
  anios: number[]=[];
  anio: AniosResponse[]=[];
  meses: Mes[]=[];
  mes: string[]=[];
  mesActual: string;
  anioActual: string;
  codigoBobinaSelect: string = '-';
  pagination: GeneralPagination = new GeneralPagination();
  kardexBForm: FormGroup;
  isLoading: boolean = false;
  sortTable: Sort = {
    active: '1',
    direction: 'asc'
  }
  public progress: number;
  horizontalPosition: MatSnackBarHorizontalPosition = 'end';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _formBuilder: FormBuilder,
    private _snackBar: MatSnackBar,
    private _reporteService: ReporteService,
    private _exportarService: ExportarService,
    private _generalService: GeneralService,
    private datePipe: DatePipe,
    private _router: Router
  ) { }

  ngOnInit(): void {
    
    
    this.kardexBForm = this._formBuilder.group({
      FechaDesde: new FormControl<Date | null>(null),
      FechaHasta: new FormControl<Date | null>(null),
      AlmacenSerie: [''],
      MitemCodigo: [''],
      BobiCodigo: [''],
      Linea: [''],
      SubLinea: [''],
      PeriodoMes: [''],
      PeriodoAnio: [''],
      Estado: [''],
      BuscarTabla: ['']
    });
    
    console.log('ANIOACTUAL',this.anioActual);
    this.getAlmacen();
    this.getLinea();
    this.getMes();
    
  }

    getLinea(): void{
    this._reporteService.obtenerLinea()
        .subscribe(
            (response: ListLineaResponse) => {
                this.linea = response.result.linea;
                this._changeDetectorRef.markForCheck();
                console.log('Lineas kardex boin',this.linea);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
    }

    selectLinea(data: MatSelectChange){
      console.log("data", data);
      this.getSublinea(String(data.value));
    }

    getSublinea(codLinea: string): void{
      console.log('Sublineas kardex',codLinea);
      this._reporteService.obtenerSublinea(codLinea)
          .subscribe(
              (response: ListSublineaResponse) => {
                  this.sublinea = response.result.sublinea;
                  this._changeDetectorRef.markForCheck();
                  console.log('Sublineas kardex',codLinea);
                  console.log('Sublineas kardex',response);
              },
              (error: HttpErrorResponse) => {
                  console.log(error);
              }
          );
    }

  getAlmacen(): void{
    this._reporteService.obtenerAlmacen()
        .subscribe(
            (response: ListAlmacenResponse) => {
                this.almacen = response.result.almacen;
                this._changeDetectorRef.markForCheck();
                console.log('almacenes kardex',response);
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
    }

  cleanFilter(): void{
    this.resetKardexBForm(true);
    this.clearDateRange();
    this.listado=[];
    this.codigoBobinaSelect= '-';
  }

  listarReporte(page: number = 0, size: number = 10, columnSort = 1, directionSort = 'desc') {

    this.isLoading = true;

    let request = new KardexBobinaRequest();
    let lineaCodigo =this.kardexBForm.get('Linea').value;
    let sublineaCodigo =this.kardexBForm.get('SubLinea').value;
    request.fechaDesde = this.kardexBForm.get('FechaDesde').value == null ? '' : moment(new Date(this.kardexBForm.get('FechaDesde').value)).format('DDMMYYYY');
    request.fechaHasta = this.kardexBForm.get('FechaHasta').value == null ? '' : moment(new Date(this.kardexBForm.get('FechaHasta').value)).add(1,'d').format('DDMMYYYY');
    request.almacenSerie = this.kardexBForm.get('AlmacenSerie').value == null ? '' : this.kardexBForm.get('AlmacenSerie').value;
    request.mitemCodigo = this.kardexBForm.get('MitemCodigo').value == null ? ''  : this.kardexBForm.get('MitemCodigo').value;
    request.bobiCodigo = this.kardexBForm.get('BobiCodigo').value == null ? ''  : this.kardexBForm.get('BobiCodigo').value;

    if(lineaCodigo=='' || lineaCodigo== null){request.linea = '';}
    else{
    request.linea = this.linea.find(l => l.lineaCodigo == lineaCodigo).lineaDescripcion;
      console.log('LINEA REQUEST',request.linea);}
      if(sublineaCodigo=='' || sublineaCodigo == null){request.subLinea = '';}
    else{
    request.subLinea = this.sublinea.find(s => s.sublineaCodigo == sublineaCodigo).sublineaDescripcion;
      console.log('LINEA REQUEST',request.subLinea);}
    
    request.periodoMes = this.kardexBForm.get('PeriodoMes').value == null ? '' : this.kardexBForm.get('PeriodoMes').value ;
    request.periodoAnio = this.kardexBForm.get('PeriodoAnio').value == null ? '' : this.kardexBForm.get('PeriodoAnio').value ; 
    request.estado = this.kardexBForm.get('Estado').value == null ? '' : this.kardexBForm.get('Estado').value; 
    request.numeroPagina = page + 1;
    request.cantidadPagina = size;
    request.columnaOrdenamiento = columnSort;
    request.direccionOrdenamiento = directionSort;

    console.log('request', request);

    this._reporteService.obtenerKardexBobina(request)
      .subscribe(
        (response: KardexBobinaResponse) => {
          console.log('LISTADO', this.listado);
          console.log('responseeeee', response);
          this.isLoading = false;
          if (response.status) {
            this.listado = response.result?.kardexBobina == null ? [] : response.result.kardexBobina;
            
            let pagination = {};
            const dataLength = response.result.totalRegistros;
            const begin = page * size;
            const end = Math.min((size * (page + 1)), dataLength);
            const lastPage = Math.max(Math.ceil(dataLength / size), 1);

            pagination = {
              length: dataLength,
              size: size,
              page: page,
              lastPage: lastPage,
              startIndex: begin,
              endIndex: end - 1
            };
            console.log('LISTADO',this.listado);
            this.pagination = pagination as GeneralPagination;
            this._changeDetectorRef.markForCheck();
          }
        },
        (error: HttpErrorResponse) => {
          console.log(error);
          this.isLoading = false;
        }
      );
  }

  searchData() {
    this.listarReporte(0, 10, 1, 'asc');
    this.codigoBobinaSelect= '-';
  }

  resetKardexBForm(option: boolean) {

    if (option) {
      this.kardexBForm.get('AlmacenSerie').setValue(null);
      this.kardexBForm.get('MitemCodigo').setValue('');
      this.kardexBForm.get('BobiCodigo').setValue('');
      this.kardexBForm.get('Linea').setValue('');
      this.kardexBForm.get('SubLinea').setValue('');
      this.kardexBForm.get('PeriodoMes').setValue('');
      this.kardexBForm.get('PeriodoAnio').setValue('');
      this.kardexBForm.get('BuscarTabla').setValue('');
      this.kardexBForm.get('Estado').setValue('');
    }


  }

  handlePage(e: PageEvent): PageEvent {
    this.listarReporte(e.pageIndex, e.pageSize, Number(this.sortTable.active), this.sortTable.direction);
    return e;
  }

  clearDateRange() {
    this.kardexBForm.get('FechaDesde').setValue(null);
    this.kardexBForm.get('FechaHasta').setValue(null);
  }

  eventSortTable(sort: Sort) {
    console.log(sort);
    this.sortTable = {
      active: sort.active,
      direction: sort.direction
    }
    this.listarReporte(this.pagination.page, this.pagination.size, Number(sort.active), sort.direction);
  }

  touchRow(item: ItemKardexBobina): void {

    this.codigoBobinaSelect = item.bobiCodigo.toString();

    this.listado.forEach((r) => {
        if(r.id == item.id){
            r.seleccionado = true;
        }else{
          r.seleccionado = false;
        }
    });

  }

  getMes(): void {
    
    this._reporteService.obtenerMes('KB')
        .subscribe(
            (response: MesResponse) => {
                this.mes = response.result;
                console.log('MESSSSSSKardex',this.mes);
                this.kardexBForm.get('PeriodoMes').setValue(''+this.mes);
                this._changeDetectorRef.markForCheck();
                this.getAnios();
            },
            (error: HttpErrorResponse) => {
                console.log(error);
            }
        );
    
    
        
    this.meses = [
      {
        nombre: 'Enero',
        codigo: '01'
      },
      {
        nombre: 'Febrero',
        codigo: '02'
      },
      {
        nombre: 'Marzo',
        codigo: '03'
      },
      {
        nombre: 'Abril',
        codigo: '04'
      },
      {
        nombre: 'Mayo',
        codigo: '05'
      },
      {
        nombre: 'Junio',
        codigo: '06'
      },
      {
        nombre: 'Julio',
        codigo: '07'
      },
      {
        nombre: 'Agosto',
        codigo: '08'
      },
      {
        nombre: 'Septiembre',
        codigo: '09'
      },
      {
        nombre: 'Octubre',
        codigo: '10'
      },
      {
        nombre: 'Noviembre',
        codigo: '11'
      },
      {
        nombre: 'Diciembre',
        codigo: '12'
      }
    ];
    
  }

  getAnios() {
    let init = 2000;
    let anio = (new Date()).getFullYear();
    let diff = anio - init;
    for(let d = 0; d < diff; d++){
        this.anios.push(init + (d + 1));
    }
    this.kardexBForm.get('PeriodoAnio').setValue(anio);
  }

  // getAnios(): void {
    
  //   this._reporteService.obtenerAnios('KB')
  //       .subscribe(
  //           (response: AniosResponse) => {
              
  //               this.anios = response.result;
  //               var dateDay = new Date();
  //               //this.anios.sort();
  //               var anioMax = this.anios[0];
                
  //               if(anioMax == dateDay.getFullYear()){
  //                 this.anioActual = dateDay.getFullYear().toString();
  //                 this.kardexBForm.get('PeriodoAnio').setValue(Number(this.anioActual));
  //               }
  //               else{
  //                 this.anioActual= anioMax.toString();
  //                 this.kardexBForm.get('PeriodoAnio').setValue(Number(this.anioActual));
  //               }
  //               this.kardexBForm.get('PeriodoAnio').setValue(Number(this.anioActual));
  //               //this.listarReporte();
  //               this._changeDetectorRef.markForCheck();
  //           },
  //           (error: HttpErrorResponse) => {
  //               console.log(error);
  //           }
            
  //       );
        
       
  //   }

    exportExcel(){
   
      let request = new ExportarReporteRequest();
      request.TipoReporte = 'KB-K';
      request.FechaDesde = this.kardexBForm.get('FechaDesde').value == null ? '' : moment(new Date(this.kardexBForm.get('FechaDesde').value)).format('DDMMYYYY');
      request.FechaHasta = this.kardexBForm.get('FechaHasta').value == null ? '' : moment(new Date(this.kardexBForm.get('FechaHasta').value)).format('DDMMYYYY');
      request.AlmacenSerie = this.kardexBForm.get('AlmacenSerie').value == null ? '':this.kardexBForm.get('AlmacenSerie').value;
      request.MitemCodigo = this.kardexBForm.get('MitemCodigo').value == '' ? 0 :this.kardexBForm.get('MitemCodigo').value;
      request.BobiCodigo = this.kardexBForm.get('BobiCodigo').value == '' ? 0 :this.kardexBForm.get('BobiCodigo').value;
      request.Linea = this.kardexBForm.get('Linea').value;
      request.SubLinea = this.kardexBForm.get('SubLinea').value;
      request.PeriodoMes = this.kardexBForm.get('PeriodoMes').value == null ? '' : this.kardexBForm.get('PeriodoMes').value;
      request.PeriodoAnio = this.kardexBForm.get('PeriodoAnio').value == null ? '' : this.kardexBForm.get('PeriodoAnio').value;
  
      this._snackBar.openFromComponent(LoadingSnackbarComponent,{
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
      });
      this._generalService.dispProgress.emit({ message: 'Generando reporte ...', percentage: 0 });
        this._exportarService.downloadReportGeneric(request).subscribe((event) => {
          if (event.type === HttpEventType.DownloadProgress){
              this.progress = Math.round((100 * event.loaded) / event.total);
              this._generalService.dispProgress.emit({ message: 'Generando reporte ...', percentage: this.progress });
          }else if (event.type === HttpEventType.Response) {
              this._generalService.dispProgress.emit({ message: 'Reporte generado.', percentage: this.progress });
              this.getBlob(event, `Reporte_KardexBobina_${this.datePipe.transform( new Date(), 'ddMMyyyy')}.xls`);
              setTimeout(() =>
                    {
                      this._snackBar.dismiss();
                    }, 2000);
          }
      });
    }
  
    getBlob(data: HttpResponse<Blob>, fileName: string) {
      const downloadedFile = new Blob([data.body], { type: data.body.type });
      const a = document.createElement('a');
      a.setAttribute('style', 'display:none;');
      document.body.appendChild(a);
      a.download = fileName;
      a.href = URL.createObjectURL(downloadedFile);
      a.target = '_blank';
      a.click();
      document.body.removeChild(a);
    }

    public transformThousands(value: any) {
        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
}
