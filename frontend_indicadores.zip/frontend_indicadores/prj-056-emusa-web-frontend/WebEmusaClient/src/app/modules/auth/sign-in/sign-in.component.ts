import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { fuseAnimations } from '@fuse/animations';
import { FuseAlertType } from '@fuse/components/alert';
import { AuthResponse } from 'app/shared/models/response/authentication/auth-response.interface';
import { AuthService } from 'app/shared/services/authentication/auth.service';
import { LocalService } from 'app/shared/services/common/local.service';
import { UserService } from 'app/shared/services/user/user.service';
import { environment } from 'environments/environment';

@Component({
    selector     : 'auth-sign-in',
    templateUrl  : './sign-in.component.html',
    encapsulation: ViewEncapsulation.None,
    animations   : fuseAnimations
})
export class AuthSignInComponent implements OnInit
{
    @ViewChild('signInNgForm') signInNgForm: NgForm;

    alert: { type: FuseAlertType; message: string } = {
        type   : 'success',
        message: ''
    };
    signInForm: FormGroup;
    showAlert: boolean = false;

    constructor(
        private _activatedRoute: ActivatedRoute,
        private _authService: AuthService,
        private _userService: UserService,
        private _formBuilder: FormBuilder,
        private _router: Router,
        private _localStorage: LocalService
    )
    {
    }

    ngOnInit(): void
    {
        this.signInForm = this._formBuilder.group({
            userName  : ['', [Validators.required]],
            password  : ['', [Validators.required]],
            rememberMe: ['']
        });
    }

    signIn(): void
    {
        if ( this.signInForm.invalid )
        {
            return;
        }

        this.signInForm.disable();
        this.showAlert = false;

        this._authService.logIn(this.signInForm.value)
            .subscribe(
                (response: AuthResponse) => {
                    if(response.status == true){
                        // if(response.value.access){
                            this._userService.user = response.result.usuario;
                            this._authService.authToken = response.result;
                            //const redirectURL = this._activatedRoute.snapshot.queryParamMap.get('redirectURL') || '/signed-in-redirect';
                            
                            this._router.navigate(['/home']);
                            //this._router.navigateByUrl(redirectURL);
                        // }
                    }
                },
                (error: HttpErrorResponse) => {
                    if (error.status === 400) {
                        this.signInForm.enable();
                        this.signInNgForm.resetForm();
                        this.alert = {
                             type   : 'error',
                             message: 'Nombre de usuario o contraseña incorrectos'
                        };
                        this.showAlert = true;
                      } else {
                        console.log(error);
                      }
                }
            );
    }

}
