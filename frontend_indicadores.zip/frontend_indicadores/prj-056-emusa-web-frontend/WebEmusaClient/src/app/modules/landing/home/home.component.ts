import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { User } from 'app/shared/models/response/user/user-response.interface';
import { UserService } from 'app/shared/services/user/user.service';

@Component({
    selector     : 'landing-home',
    templateUrl  : './home.component.html',
    encapsulation: ViewEncapsulation.None
})
export class LandingHomeComponent implements OnInit
{
    user: User;
    
    constructor(private _userService: UserService)
    {
    }

    ngOnInit(): void
    {
        this.user = this._userService.user;
    }

}
