import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthUtils } from 'app/core/auth/auth.utils';
import { AuthService } from 'app/shared/services/authentication/auth.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor
{
    /**
     * Constructor
     */
    constructor(private _authService: AuthService)
    {
    }

    /**
     * Intercept
     *
     * @param req
     * @param next
     */
     intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>>
     {
         let newReq = req.clone();
 
         if ( this._authService.authToken.token && !AuthUtils.isTokenExpired(this._authService.authToken.token) )
         {
             newReq = req.clone({
                 headers: req.headers.set('Authorization', 'Bearer ' + this._authService.authToken.token)
             });
         }
 
         // Response
         return next.handle(newReq).pipe(
             catchError((error) => {
                 if ( error instanceof HttpErrorResponse && error.status === 401 )
                 {
                     this._authService.signOff();
                     location.reload();
                 }
                 
                 return throwError(error);
             })
         );
     }
}
