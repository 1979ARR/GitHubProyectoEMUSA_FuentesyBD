import { Component, EventEmitter, OnDestroy, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FuseMediaWatcherService } from '@fuse/services/media-watcher';
import { FuseNavigationItem, FuseNavigationService, FuseVerticalNavigationComponent } from '@fuse/components/navigation';
import { Navigation } from 'app/core/navigation/navigation.types';
import { User } from 'app/shared/models/response/user/user-response.interface';
import { UserService } from 'app/shared/services/user/user.service';
import { HttpErrorResponse, HttpEventType } from '@angular/common/http';
import { GeneralService } from 'app/shared/services/common/general.service';
import { GeneralResponse, NavigationResponse } from 'app/shared/models/response/common/common-response.interface';
import { AuthService } from 'app/shared/services/authentication/auth.service';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from 'app/modules/admin/common/confirm-dialog/confirm-dialog.component';
import { LoadingSnackbarComponent } from 'app/modules/admin/common/loading-snackbar/loading-snackbar.component';

@Component({
    selector     : 'classy-layout',
    templateUrl  : './classy.component.html',
    styleUrls  : ['./classy.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class ClassyLayoutComponent implements OnInit, OnDestroy
{
    isScreenSmall: boolean;
    navigationAnt: Navigation;
    navigation: FuseNavigationItem[] = new Array<FuseNavigationItem>();
    user: User;
    private _unsubscribeAll: Subject<any> = new Subject<any>();
    
    public progress: number;
    @Output() public onUploadFinished = new EventEmitter();
    horizontalPosition: MatSnackBarHorizontalPosition = 'end';
    verticalPosition: MatSnackBarVerticalPosition = 'bottom';
    
    constructor(
        private _router: Router,
        private _userService: UserService,
        private _generalService: GeneralService,
        private _fuseMediaWatcherService: FuseMediaWatcherService,
        private _fuseNavigationService: FuseNavigationService,
        private _authService: AuthService,
        private _snackBar: MatSnackBar,
        public dialog: MatDialog
    )
    {
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Accessors
    // -----------------------------------------------------------------------------------------------------

    /**
     * Getter for current year
     */
    get currentYear(): number
    {
        return new Date().getFullYear();
    }

    ngOnInit(): void
    {
        // Subscribe to navigation data
        this.getNavigation();
        
        // Subscribe to the user service
        this.user = this._userService.user;
        
        // Subscribe to media changes
        this._fuseMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({matchingAliases}) => {

                // Check if the screen is small
                this.isScreenSmall = !matchingAliases.includes('md');
            });
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next(null);
        this._unsubscribeAll.complete();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------

    /**
     * Toggle navigation
     *
     * @param name
     */
    toggleNavigation(name: string): void
    {
        // Get the navigation
        const navigation = this._fuseNavigationService.getComponent<FuseVerticalNavigationComponent>(name);

        if ( navigation )
        {
            // Toggle the opened status
            navigation.toggle();
        }
    }

    getNavigation(){

      this.navigation = [
        {
          type: 'group',
          title: 'Dashboard y Reportes',
          children: [
            {
              type: 'basic',
              title: 'Reportes',
              link: '/reportes'
            },
            {
              type: 'basic',
              title: 'Indicadores',
              link: '/indicadores'
            }
          ]
        },
        // {
        //     type: 'basic',
        //     icon: 'mat_outline:list_alt',
        //     title: 'Búsqueda de Reclamos',
        //     link: '/consultas/listado'
        // }
      ];

        // this._generalService.GetNavigation()
        //     .subscribe(
        //         (response: NavigationResponse) => {
        //             if(response.status){
        //                 this.navigation = response.value;
        //             }else{
        //                 this.navigation = null;
        //             }
                    
        //         },
        //         (error: HttpErrorResponse) => {
        //             console.log(error);
        //         }
        //     );
    }

    signOff(): void
    {
        this._authService.signOff();
        this._router.navigate(['/sign-out']);
    }

}
