export const Routes = {
    Authentication: 'Authentication/',
    User: 'User/',
    General: 'General/',
    Reporte: 'Reporte/',
    Indicador: 'Indicador/'
};

export const Authentication = {
    Login: 'login'
}

export const General = {
  ListarPorTexto: 'listarPorTexto',
  DownloadFile: 'DownloadFile'
}

export const UserAccount = {
    GetUserById: 'GetUserById',
}

export const Reporte = {

  //Lista Lineas
  Linea:'Linea',
  //Lista Sublineas
  Sublinea:'Sublinea',
  //Listado Mes Actual
  MesActual:'MesActual',
  //Listado Anios
  AniosxReporte:'AniosxReporte',
  //Listado Almacen
  Almacen:'Almacen',
  //Pendientes por Ubicar
  MateriaPrima: 'MateriaPrima',
  ProductosEnProceso: 'ProductosEnProceso',
  ProductosTerminados: 'ProductosTerminados',

  //Kardex Bobina
  KardexBobina: 'KardexBobina',

  //Bobina con PNC
  BobinaConPNC: 'BobinaConPNC',

  //Desarrollo de Inventario
  MateriaPrimaD: 'MateriaPrimaD',
  ProductosEnProcesoD: 'ProductosEnProcesoD',
  ProductosTerminadosD: 'ProductosTerminadosD',

  //Proceso de Produccion
  ProcesoDeProduccion: 'ProcesoDeProduccion',

  //Exportar
  ExportarReporteGenerico: 'ExportarReporteGenerico'
}

export const Indicador = {
  ObtenerDatosERI: 'ObtenerDatosERI',
  ObtenerDatosFIFO: 'ObtenerDatosFIFO',
  ObtenerDatosPU: 'ObtenerDatosPU',
  ObtenerDatosCA: 'ObtenerDatosCA',
  ObtenerDatosRO: 'ObtenerDatosRO',
  ObtenerDatosTablaERI: 'ObtenerDatosTablaERI',
  ListarUsuariosInd: 'ListarUsuariosInd'
}
