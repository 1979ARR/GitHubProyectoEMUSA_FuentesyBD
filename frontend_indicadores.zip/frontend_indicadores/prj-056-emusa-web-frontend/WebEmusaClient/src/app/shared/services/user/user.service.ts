import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Routes, UserAccount } from 'app/shared/constant/incomeWebApi';
import { User, UserResponse } from 'app/shared/models/response/user/user-response.interface';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { AuthorizationService } from '../authentication/authorization.service';
import { LocalService } from '../common/local.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  urlWebApi: string;
  constructor(
    private _http: HttpClient,
    private _localStorage: LocalService,
    private _authorizationService: AuthorizationService
  ) {
    this.urlWebApi = environment.serverUriApi;
  }

    set user(model: User)
    {
      this._localStorage.setJsonValue('user_ge_VIM', model);
    }

    get user(): User
    {
        return this._localStorage.getJsonValue('user_ge_VIM') ?? null;
    }

    getUserById(id: number): Observable<UserResponse> {

      const params = new HttpParams()
      .set('idUser', id.toString());

      return this._http
        .get<UserResponse>(
          this.urlWebApi + Routes.User + UserAccount.GetUserById, { params }
        )
        .pipe(retry(0), catchError(this._authorizationService.errorHandler));
    }

}
