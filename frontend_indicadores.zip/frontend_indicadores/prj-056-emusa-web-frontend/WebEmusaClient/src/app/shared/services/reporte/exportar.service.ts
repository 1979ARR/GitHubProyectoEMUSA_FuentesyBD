import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthorizationService } from '../authentication/authorization.service';
import { LocalService } from '../common/local.service';
import { environment } from 'environments/environment';
import { catchError, retry } from 'rxjs/operators';
import { Routes, Reporte } from 'app/shared/constant/incomeWebApi';
import { ExportarReporteRequest } from 'app/shared/models/request/reporte/exportar-request.interface';

@Injectable({
    providedIn: 'root'
  })
  export class ExportarService {
  
    urlWebApi: string;
    constructor(
      private _http: HttpClient,
      private _localStorage: LocalService,
      private _authorizationService: AuthorizationService
    ) {
      this.urlWebApi = environment.serverUriApi;
    }

    downloadReportGeneric(request: ExportarReporteRequest) {
        const params = new HttpParams()
        .set('TipoReporte', request.TipoReporte)
        .set('FechaDesde', request.FechaDesde)
        .set('FechaHasta', request.FechaHasta)
        .set('AlmacenSerie', request.AlmacenSerie)
        .set('MitemCodigo', request.MitemCodigo)
        .set('BobiCodigo', request.BobiCodigo)
        .set('Linea', request.Linea)
        .set('SubLinea', request.SubLinea)
        .set('PeriodoMes', request.PeriodoMes)
        .set('PeriodoAnio', request.PeriodoAnio);
    
        return this._http
          .get(this.urlWebApi + Routes.Reporte + Reporte.ExportarReporteGenerico, {
              params,
              reportProgress: true,
              responseType: 'blob',
              observe: 'events'
            })
          .pipe(retry(0), catchError(this._authorizationService.errorHandler));
      }

  }


