import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthorizationService } from '../authentication/authorization.service';
import { LocalService } from '../common/local.service';
import { environment } from 'environments/environment';
import { catchError, retry } from 'rxjs/operators';
import { Routes, Reporte } from 'app/shared/constant/incomeWebApi';
import { Observable } from 'rxjs';
import { ProductosEnProcesoPPURequest, ProductosTerminadosPPURequest } from 'app/shared/models/request/reporte/pendientes-ubicar-request.interface';
import { ProductosEnProcesoPPUResponse, ProductosTerminadosPPUResponse } from 'app/shared/models/response/reporte/pendientes-ubicar.interface';
import { MateriaPrimaPPUResponse } from 'app/shared/models/response/reporte/pendientes-ubicar.interface';
import { MateriaPrimaPPURequest } from 'app/shared/models/request/reporte/pendientes-ubicar-request.interface';
import { KardexBobinaRequest } from 'app/shared/models/request/reporte/kardex-bobina-request.interface';
import { KardexBobinaResponse } from 'app/shared/models/response/reporte/kardex-bobina.interface';
import { ListAlmacenResponse } from 'app/shared/models/response/reporte/almacen.interface';
import { AniosResponse, MesResponse } from 'app/shared/models/response/reporte/common.interface';
import { BobinaPncResponse} from 'app/shared/models/response/reporte/bobina-con-pnc.interface';
import { BobinaPncRequest} from 'app/shared/models/request/reporte/bobina-con-pnc-request.interface';
import { ProcesoProduccionResponse} from 'app/shared/models/response/reporte/proceso-de-produccion.interface';
import { ProcesoProduccionRequest} from 'app/shared/models/request/reporte/proceso-de-produccion-request.interface';
import { ListLineaResponse } from 'app/shared/models/response/reporte/linea.interface';
import { ListSublineaResponse } from 'app/shared/models/response/reporte/sublinea.interface';

@Injectable({
    providedIn: 'root'
  })
  export class ReporteService {
  
    urlWebApi: string;
    constructor(
      private _http: HttpClient,
      private _localStorage: LocalService,
      private _authorizationService: AuthorizationService
    ) {
      this.urlWebApi = environment.serverUriApi;
    }

//#region Linea
obtenerLinea(): Observable<ListLineaResponse> {
  return this._http
   .get<ListLineaResponse>(
       this.urlWebApi + Routes.Reporte + Reporte.Linea
   )
   .pipe(retry(0), catchError(this._authorizationService.errorHandler));
 }
 //#endregion
 //#region Sublinea
obtenerSublinea(codLinea: string): Observable<ListSublineaResponse> {
  const params = new HttpParams()
      .set('codLinea', codLinea);
  return this._http
   .get<ListSublineaResponse>(
       this.urlWebApi + Routes.Reporte + Reporte.Sublinea, { params }
   )
   .pipe(retry(0), catchError(this._authorizationService.errorHandler));
 }
 //#endregion
//#region Anios
obtenerMes(tipo: string): Observable<MesResponse>{
  const params = new HttpParams()
      .set('tipo', tipo);
  return this._http
  .get<MesResponse>(
      this.urlWebApi + Routes.Reporte + Reporte.MesActual, { params }
  )
  .pipe(retry(0), catchError(this._authorizationService.errorHandler));
}
//#endregion

//#region Anios
obtenerAnios(tipo: string): Observable<AniosResponse>{
  const params = new HttpParams()
      .set('tipo', tipo);
  return this._http
  .get<AniosResponse>(
      this.urlWebApi + Routes.Reporte + Reporte.AniosxReporte, { params }
  )
  .pipe(retry(0), catchError(this._authorizationService.errorHandler));
}
//#endregion

//#region Almacen
obtenerAlmacen(): Observable<ListAlmacenResponse> {
 return this._http
  .get<ListAlmacenResponse>(
      this.urlWebApi + Routes.Reporte + Reporte.Almacen
  )
  .pipe(retry(0), catchError(this._authorizationService.errorHandler));
}
//#endregion

    //#region PENDIENTES POR UBICAR

    obtenerMateriaPrimaPPU(request: MateriaPrimaPPURequest): Observable<MateriaPrimaPPUResponse> {
    
      const params = new HttpParams()
      .set('FechaDesde', request.fechaDesde)
      .set('FechaHasta', request.fechaHasta)
      .set('AlmacenSerie', request.almacenSerie)
      .set('MitemCodigo', request.mitemCodigo)
      .set('BobiCodigo', request.bobiCodigo)
      .set('Linea', request.linea)
      .set('SubLinea', request.subLinea)
      .set('PeriodoMes', request.periodoMes)
      .set('PeriodoAnio', request.periodoAnio)
      .set('NumeroPagina', request.numeroPagina)
      .set('CantidadPagina', request.cantidadPagina)
      .set('ColumnaOrdenamiento', request.columnaOrdenamiento)
      .set('DireccionOrdenamiento', request.direccionOrdenamiento);

      return this._http
      .get<MateriaPrimaPPUResponse>(
          this.urlWebApi + Routes.Reporte + Reporte.MateriaPrima, { params }
      )
      .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }
        obtenerProductosEnProcesoPPU(request: ProductosEnProcesoPPURequest): Observable<ProductosEnProcesoPPUResponse> {
    
          const params = new HttpParams()
          .set('FechaDesde', request.fechaDesde)
          .set('FechaHasta', request.fechaHasta)
          .set('AlmacenSerie', request.almacenSerie)
          .set('MitemCodigo', request.mitemCodigo)
          .set('BobiCodigo', request.bobiCodigo)
          .set('Linea', request.linea)
          .set('SubLinea', request.subLinea)
          .set('PeriodoMes', request.periodoMes)
          .set('PeriodoAnio', request.periodoAnio)
          .set('NumeroPagina', request.numeroPagina)
          .set('CantidadPagina', request.cantidadPagina)
          .set('ColumnaOrdenamiento', request.columnaOrdenamiento)
          .set('DireccionOrdenamiento', request.direccionOrdenamiento);
  
          return this._http
          .get<ProductosEnProcesoPPUResponse>(
              this.urlWebApi + Routes.Reporte + Reporte.ProductosEnProceso, { params }
          )
          .pipe(retry(0), catchError(this._authorizationService.errorHandler));
      }

        obtenerProductosTerminadosPPU(request: ProductosTerminadosPPURequest): Observable<ProductosTerminadosPPUResponse> {
    
          const params = new HttpParams()
          .set('FechaDesde', request.fechaDesde)
          .set('FechaHasta', request.fechaHasta)
          .set('AlmacenSerie', request.almacenSerie)
          .set('MitemCodigo', request.mitemCodigo)
          .set('BobiCodigo', request.bobiCodigo)
          .set('Linea', request.linea)
          .set('SubLinea', request.subLinea)
          .set('PeriodoMes', request.periodoMes)
          .set('PeriodoAnio', request.periodoAnio)
          .set('NumeroPagina', request.numeroPagina)
          .set('CantidadPagina', request.cantidadPagina)
          .set('ColumnaOrdenamiento', request.columnaOrdenamiento)
          .set('DireccionOrdenamiento', request.direccionOrdenamiento);
  
          return this._http
          .get<ProductosTerminadosPPUResponse>(
              this.urlWebApi + Routes.Reporte + Reporte.ProductosTerminados, { params }
          )
          .pipe(retry(0), catchError(this._authorizationService.errorHandler));
      }

    //#endregion



    //#region KARDEX DE BOBINA
    obtenerKardexBobina(request: KardexBobinaRequest): Observable<KardexBobinaResponse> {
    
      const params = new HttpParams()
      .set('FechaDesde', request.fechaDesde)
      .set('FechaHasta', request.fechaHasta)
      .set('AlmacenSerie', request.almacenSerie)
      .set('MitemCodigo', request.mitemCodigo)
      .set('BobiCodigo', request.bobiCodigo)
      .set('Linea', request.linea)
      .set('SubLinea', request.subLinea)
      .set('PeriodoMes', request.periodoMes)
      .set('PeriodoAnio', request.periodoAnio)
      .set('Estado', request.estado)
      .set('NumeroPagina', request.numeroPagina)
      .set('CantidadPagina', request.cantidadPagina)
      .set('ColumnaOrdenamiento', request.columnaOrdenamiento)
      .set('DireccionOrdenamiento', request.direccionOrdenamiento);

      return this._http
      .get<KardexBobinaResponse>(
          this.urlWebApi + Routes.Reporte + Reporte.KardexBobina, { params }
      )
      .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }
    //#endregion

    //#region Bobina con PNC
    obtenerBobinaPnc(request: BobinaPncRequest): Observable<BobinaPncResponse> {
    
      const params = new HttpParams()
      .set('FechaDesde', request.fechaDesde)
      .set('FechaHasta', request.fechaHasta)
      .set('AlmacenSerie', request.almacenSerie)
      .set('MitemCodigo', request.mitemCodigo)
      .set('BobiCodigo', request.bobiCodigo)
      .set('Linea', request.linea)
      .set('SubLinea', request.subLinea)
      .set('PeriodoMes', request.periodoMes)
      .set('PeriodoAnio', request.periodoAnio)
      .set('NumeroPagina', request.numeroPagina)
      .set('CantidadPagina', request.cantidadPagina)
      .set('ColumnaOrdenamiento', request.columnaOrdenamiento)
      .set('DireccionOrdenamiento', request.direccionOrdenamiento);

      return this._http
      .get<BobinaPncResponse>(
          this.urlWebApi + Routes.Reporte + Reporte.BobinaConPNC, { params }
      )
      .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }
    //#endregion
    
    //#region DESARROLLO DE INVENTARIO
    obtenerMateriaPrimaPPUD(request: MateriaPrimaPPURequest): Observable<MateriaPrimaPPUResponse> {
    
      const params = new HttpParams()
      .set('FechaDesde', request.fechaDesde)
      .set('FechaHasta', request.fechaHasta)
      .set('AlmacenSerie', request.almacenSerie)
      .set('MitemCodigo', request.mitemCodigo)
      .set('BobiCodigo', request.bobiCodigo)
      .set('Linea', request.linea)
      .set('SubLinea', request.subLinea)
      .set('PeriodoMes', request.periodoMes)
      .set('PeriodoAnio', request.periodoAnio)
      .set('NumeroPagina', request.numeroPagina)
      .set('CantidadPagina', request.cantidadPagina)
      .set('ColumnaOrdenamiento', request.columnaOrdenamiento)
      .set('DireccionOrdenamiento', request.direccionOrdenamiento);

      return this._http
      .get<MateriaPrimaPPUResponse>(
          this.urlWebApi + Routes.Reporte + Reporte.MateriaPrimaD, { params }
      )
      .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }
  obtenerProductosEnProcesoPPUD(request: ProductosEnProcesoPPURequest): Observable<ProductosEnProcesoPPUResponse> {

    const params = new HttpParams()
    .set('FechaDesde', request.fechaDesde)
    .set('FechaHasta', request.fechaHasta)
    .set('AlmacenSerie', request.almacenSerie)
    .set('MitemCodigo', request.mitemCodigo)
    .set('BobiCodigo', request.bobiCodigo)
    .set('Linea', request.linea)
    .set('SubLinea', request.subLinea)
    .set('PeriodoMes', request.periodoMes)
    .set('PeriodoAnio', request.periodoAnio)
    .set('NumeroPagina', request.numeroPagina)
    .set('CantidadPagina', request.cantidadPagina)
    .set('ColumnaOrdenamiento', request.columnaOrdenamiento)
    .set('DireccionOrdenamiento', request.direccionOrdenamiento);

    return this._http
    .get<ProductosEnProcesoPPUResponse>(
        this.urlWebApi + Routes.Reporte + Reporte.ProductosEnProcesoD, { params }
    )
    .pipe(retry(0), catchError(this._authorizationService.errorHandler));
}

  obtenerProductosTerminadosPPUD(request: ProductosTerminadosPPURequest): Observable<ProductosTerminadosPPUResponse> {

    const params = new HttpParams()
    .set('FechaDesde', request.fechaDesde)
    .set('FechaHasta', request.fechaHasta)
    .set('AlmacenSerie', request.almacenSerie)
    .set('MitemCodigo', request.mitemCodigo)
    .set('BobiCodigo', request.bobiCodigo)
    .set('Linea', request.linea)
    .set('SubLinea', request.subLinea)
    .set('PeriodoMes', request.periodoMes)
    .set('PeriodoAnio', request.periodoAnio)
    .set('NumeroPagina', request.numeroPagina)
    .set('CantidadPagina', request.cantidadPagina)
    .set('ColumnaOrdenamiento', request.columnaOrdenamiento)
    .set('DireccionOrdenamiento', request.direccionOrdenamiento);

    return this._http
    .get<ProductosTerminadosPPUResponse>(
        this.urlWebApi + Routes.Reporte + Reporte.ProductosTerminadosD, { params }
    )
    .pipe(retry(0), catchError(this._authorizationService.errorHandler));
}
    //#endregion

    //#region Proceso de Produccion
    obtenerProcesoProduccion(request: ProcesoProduccionRequest): Observable<ProcesoProduccionResponse> {
    
      const params = new HttpParams()
      .set('FechaDesde', request.fechaDesde)
      .set('FechaHasta', request.fechaHasta)
      .set('AlmacenSerie', request.almacenSerie)
      .set('MitemCodigo', request.mitemCodigo)
      .set('BobiCodigo', request.bobiCodigo)
      .set('OrdenTrabajo', request.ordenTrabajo)
      .set('PeriodoMes', request.periodoMes)
      .set('PeriodoAnio', request.periodoAnio)
      .set('NumeroPagina', request.numeroPagina)
      .set('CantidadPagina', request.cantidadPagina)
      .set('ColumnaOrdenamiento', request.columnaOrdenamiento)
      .set('DireccionOrdenamiento', request.direccionOrdenamiento);

      return this._http
      .get<ProcesoProduccionResponse>(
          this.urlWebApi + Routes.Reporte + Reporte.ProcesoDeProduccion, { params }
      )
      .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }
    //#endregion
  
  }