import { HttpClient, HttpParams } from '@angular/common/http';
import { EventEmitter, Injectable, Output } from '@angular/core';
import { General, Routes } from 'app/shared/constant/incomeWebApi';
import { environment } from 'environments/environment';
import { catchError, retry } from 'rxjs/operators';
import { AuthorizationService } from '../authentication/authorization.service';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  @Output() dispProgress: EventEmitter<any> = new EventEmitter();
  
  urlWebApi: string;
  constructor(
    private _http: HttpClient,
    private _authorizationService: AuthorizationService,
  )
  {
    this.urlWebApi = environment.serverUriApi;
  }

  getDocument(fileName: string, type: string) {
    const params = new HttpParams()
        .set('fileName', fileName)
        .set('type', type);

    return this._http
      .get(this.urlWebApi + Routes.General + General.DownloadFile, {
          params,
          reportProgress: true,
          responseType: 'blob',
          observe: 'events'
        })
      .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }

}
