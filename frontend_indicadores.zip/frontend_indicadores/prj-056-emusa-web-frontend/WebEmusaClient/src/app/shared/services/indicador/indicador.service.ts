import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthorizationService } from '../authentication/authorization.service';
import { LocalService } from '../common/local.service';
import { environment } from 'environments/environment';
import { catchError, retry } from 'rxjs/operators';
import { Routes, Reporte, Indicador } from 'app/shared/constant/incomeWebApi';
import { Observable } from 'rxjs';
import { MateriaPrimaPPUResponse } from 'app/shared/models/response/reporte/pendientes-ubicar.interface';
import { MateriaPrimaPPURequest } from 'app/shared/models/request/reporte/pendientes-ubicar-request.interface';
import { IndicadorERIRequest } from 'app/shared/models/request/indicador/indicador-eri-request.interface';
import { IndicadorCAResponse, IndicadorERIResponse, IndicadorFIFOResponse, IndicadorPUResponse, IndicadorROResponse, TablaERIResponse, UsuarioIngResponse } from 'app/shared/models/response/indicador/indicadores-response.interface';
import { IndicadorPURequest } from 'app/shared/models/request/indicador/indicador-pu-request.interface';
import { IndicadorCARequest } from 'app/shared/models/request/indicador/indicador-ca-request.interface';
import { IndicadorFIFORequest } from 'app/shared/models/request/indicador/indicador-fifo-request.interface';
import { IndicadorRORequest } from 'app/shared/models/request/indicador/indicador-ro-request.interface';

@Injectable({
    providedIn: 'root'
  })
  export class IndicadorService {
  
    urlWebApi: string;
    constructor(
      private _http: HttpClient,
      private _localStorage: LocalService,
      private _authorizationService: AuthorizationService
    ) {
      this.urlWebApi = environment.serverUriApi;
    }
    
    ObtenerDatosERI(request: IndicadorERIRequest): Observable<IndicadorERIResponse> {
    
      const params = new HttpParams()
      .set('Almacen', request.almacen)
      .set('SubAlmacen', request.subAlmacen)
      .set('Linea', request.linea)
      .set('SubLinea', request.subLinea);

      return this._http
      .get<IndicadorERIResponse>(
          this.urlWebApi + Routes.Indicador + Indicador.ObtenerDatosERI, { params }
      )
      .pipe(retry(0), catchError(this._authorizationService.errorHandler));
    }

    ObtenerDatosTablaERI(request: IndicadorERIRequest): Observable<TablaERIResponse> {
    
      const params = new HttpParams()
      .set('Almacen', request.almacen)
      .set('SubAlmacen', request.subAlmacen);

      return this._http
      .get<any>(
          this.urlWebApi + Routes.Indicador + Indicador.ObtenerDatosTablaERI, { params }
      )
      .pipe(retry(0), catchError(this._authorizationService.errorHandler));
    }

    ObtenerDatosPU(request: IndicadorPURequest): Observable<IndicadorPUResponse> {
    
      const params = new HttpParams()
      .set('Almacen', request.almacen)
      .set('Linea', request.linea)
      .set('SubLinea', request.subLinea)
      .set('Anio', request.anio)
      .set('Usuario', request.usuario);

      return this._http
      .get<IndicadorPUResponse>(
          this.urlWebApi + Routes.Indicador + Indicador.ObtenerDatosPU, { params }
      )
      .pipe(retry(0), catchError(this._authorizationService.errorHandler));
    }
  

  ObtenerDatosCA(request: IndicadorCARequest): Observable<IndicadorCAResponse> {
    
    const params = new HttpParams()
    .set('Almacen', request.almacen)
    .set('Linea', request.linea)
    .set('SubLinea', request.subLinea)
    .set('Ubicacion', request.ubicacion)
    .set('Tipo', request.tipo);

    return this._http
    .get<IndicadorCAResponse>(
        this.urlWebApi + Routes.Indicador + Indicador.ObtenerDatosCA, { params }
    )
    .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }

  ListarUsuariosInd(): Observable<UsuarioIngResponse> {
    
    return this._http
    .get<UsuarioIngResponse>(
        this.urlWebApi + Routes.Indicador + Indicador.ListarUsuariosInd
    )
    .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }

  ObtenerDatosFIFO(request: IndicadorFIFORequest): Observable<IndicadorFIFOResponse> {
    
    const params = new HttpParams()
    .set('Almacen', request.almacen)
    .set('SubAlmacen', request.subAlmacen)
    .set('Linea', request.linea)
    .set('SubLinea', request.subLinea);

    return this._http
    .get<IndicadorFIFOResponse>(
        this.urlWebApi + Routes.Indicador + Indicador.ObtenerDatosFIFO, { params }
    )
    .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }

  ObtenerDatosRO(request: IndicadorRORequest): Observable<IndicadorROResponse> {
    
    const params = new HttpParams()
    .set('Almacen', request.almacen)
    .set('SubAlmacen', request.subAlmacen)
    .set('Linea', request.linea)
    .set('SubLinea', request.subLinea)
    .set('Anio', request.anio);

    return this._http
    .get<IndicadorROResponse>(
        this.urlWebApi + Routes.Indicador + Indicador.ObtenerDatosRO, { params }
    )
    .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }
  
}