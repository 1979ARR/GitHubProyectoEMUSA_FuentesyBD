import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthUtils } from 'app/core/auth/auth.utils';
import { Authentication, Routes } from 'app/shared/constant/incomeWebApi';
import { AuthRequest } from 'app/shared/models/request/authentication/auth-request.interface';
import { Auth, AuthResponse } from 'app/shared/models/response/authentication/auth-response.interface';
import { GeneralResponse } from 'app/shared/models/response/common/common-response.interface';
import { environment } from 'environments/environment';
import { Observable, of, throwError } from 'rxjs';
import { catchError, retry, switchMap } from 'rxjs/operators';
import { LocalService } from '../common/local.service';
import { StorageService } from '../common/storage.service';
import { AuthorizationService } from './authorization.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _authenticated: boolean = false;
  urlWebApi: string;
  constructor(
    private _http: HttpClient,
    private _authorizationService: AuthorizationService,
    private _localStorage: LocalService,
    private _storageService: StorageService) {
    this.urlWebApi = environment.serverUriApi;
  }

  set authToken(model: Auth)
    {
      this._localStorage.setJsonValue('authToken_ge', model);
    }

  get authToken(): Auth
    {
      return this._localStorage.getJsonValue('authToken_ge') ?? '';
    }

  logIn(request: AuthRequest): Observable<AuthResponse> {

    if ( this._authenticated ){
        return throwError('El usuario ya ha iniciado sesión.');
    }
        
    return this._http
      .post<AuthResponse>(
        this.urlWebApi + Routes.Authentication + Authentication.Login, request
      )
      .pipe(retry(0), catchError(this._authorizationService.errorHandler));
  }
  
  signOff(): Observable<any>
    {
      this._localStorage.clearKey('user_ge_VIM');
      this._localStorage.clearKey('authToken_ge');
        this._authenticated = false;
        return of(true);
    }

  checkAuth(): Observable<boolean>
    {
        if ( this._authenticated )
        {
            return of(true);
        }

        if ( !this.authToken )
        {
            return of(false);
        }

        if ( AuthUtils.isTokenExpired( this.authToken.token ) )
        {
            return of(false);
        } else {
            return of(true);
        }
    }

  signInUsingToken(): Observable<any>
    {
        return this._http.post('api/auth/refresh-access-token', {
            accessToken: this.authToken
        }).pipe(
            catchError(() =>
                of(false)
            ),
            switchMap((response: any) => {
                this.authToken = response.accessToken;
                this._authenticated = true;
                //this._userService.user = response.user;

                return of(true);
            })
        );
    }


    //TEMP
    temporalLogin(request: AuthRequest): Observable<GeneralResponse> { 
      return this._http
        .post<AuthResponse>(
          this.urlWebApi + Routes.Authentication + 'SecurityLogin', request
        )
        .pipe(retry(0), catchError(this._authorizationService.errorHandler));
    }
}
