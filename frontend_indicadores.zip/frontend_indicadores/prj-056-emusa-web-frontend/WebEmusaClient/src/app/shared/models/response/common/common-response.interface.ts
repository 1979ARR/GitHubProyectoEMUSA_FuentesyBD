import { FuseNavigationItem } from "@fuse/components/navigation/navigation.types";

export class GeneralResponse {
    status: boolean;
    state: number;
    message: string;
  }

  export class NavigationResponse extends GeneralResponse{
    value: FuseNavigationItem[];
    constructor(){
      super();
      this.value = new Array<FuseNavigationItem>();
    }
  }

  export class ContenMenuAsignedResponse extends GeneralResponse{
    value: ContenMenuAsigned;
  }

  export class ContenMenuAsigned{
    navigation: FuseNavigationItem[];
    assignedItems: number[];
    constructor(){
      this.navigation = Array<FuseNavigationItem>();
      this.assignedItems = Array<number>();
    }
  }

  export class ProgressBar{
    message: string;
    percentage: number;
  }

  export class MenuWorkspace {
    idMenu: number;
    name: string;
    idParent: number | null;
    route: string;
    isActive: number;
    icon: string
    order: number;
  }

  export class NavigationItem
  {
      id?: string;
      title?: string;
      subtitle?: string;
      type:
          | 'aside'
          | 'basic'
          | 'collapsable'
          | 'divider'
          | 'group'
          | 'spacer';
      hidden?: (item: FuseNavigationItem) => boolean;
      active?: boolean;
      disabled?: boolean;
      tooltip?: string;
      link?: string;
      icon?: string;
      children?: FuseNavigationItem[];
      status?: boolean;
  }
