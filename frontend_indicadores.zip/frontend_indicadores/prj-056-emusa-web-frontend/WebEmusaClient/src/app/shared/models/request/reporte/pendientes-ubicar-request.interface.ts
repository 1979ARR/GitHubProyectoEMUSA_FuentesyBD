import { FilterCommon } from "../common/common-request.interface";

export class MateriaPrimaPPURequest extends FilterCommon {
    fechaDesde: string;
    fechaHasta: string;
    almacenSerie: string;
    mitemCodigo: number;
    bobiCodigo: number;
    linea: string;
    subLinea: string;
    periodoMes: string;
    periodoAnio: string;
}

export class ProductosEnProcesoPPURequest extends FilterCommon {
    fechaDesde: string;
    fechaHasta: string;
    almacenSerie: string;
    mitemCodigo: number;
    bobiCodigo: number;
    linea: string;
    subLinea: string;
    periodoMes: string;
    periodoAnio: string;

}
export class ProductosTerminadosPPURequest extends FilterCommon {
    fechaDesde: string;
    fechaHasta: string;
    almacenSerie: string;
    mitemCodigo: number;
    bobiCodigo: number;
    linea: string;
    subLinea: string;
    periodoMes: string;
    periodoAnio: string;

}
