import { GeneralResponse } from "../common/common-response.interface";

//#region Sublinea

export class SublineaResponse extends GeneralResponse {
    result: ItemSublinea;
    constructor(){
      super();
      this.result = new ItemSublinea();
    }
  }

export class ListSublineaResponse extends GeneralResponse {
    result: SublineaResult;
}

export class SublineaResult {
  sublinea: ItemSublinea[];
  constructor(){
      this.sublinea = new Array<ItemSublinea>();
  }
}

export class ItemSublinea {
    lineaCodigo: string;
    sublineaCodigo: string;
    sublineaDescripcion: string;
}

//#endregion