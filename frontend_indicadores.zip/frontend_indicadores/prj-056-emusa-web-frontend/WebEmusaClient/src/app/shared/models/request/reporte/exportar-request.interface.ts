
export class ExportarReporteRequest {
    TipoReporte : string;
    FechaDesde : string;
    FechaHasta : string;
    AlmacenSerie : string;
    MitemCodigo : number;
    BobiCodigo : number;
    Linea : string;
    SubLinea : string;
    PeriodoMes : string;
    PeriodoAnio : string;
    OrdenTrabajo: number;
}