
export class IndicadorRORequest {
    almacen: string;
    subAlmacen: string;
    linea: string;
    subLinea: string;
    anio: string;
}
