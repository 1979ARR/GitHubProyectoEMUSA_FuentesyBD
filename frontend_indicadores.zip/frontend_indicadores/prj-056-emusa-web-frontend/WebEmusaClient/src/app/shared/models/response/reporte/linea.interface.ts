import { GeneralResponse } from "../common/common-response.interface";

//#region Linea

export class LineaResponse extends GeneralResponse {
    result: ItemLinea;
    constructor(){
      super();
      this.result = new ItemLinea();
    }
  }

export class ListLineaResponse extends GeneralResponse {
    result: LineaResult;
}

export class LineaResult {
  linea: ItemLinea[];
  constructor(){
      this.linea = new Array<ItemLinea>();
  }
}

export class ItemLinea {
    
    lineaCodigo: string;
    lineaDescripcion: string;
}

//#endregion