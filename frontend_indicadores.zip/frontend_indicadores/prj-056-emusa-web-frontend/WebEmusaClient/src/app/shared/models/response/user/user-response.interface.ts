import { GeneralResponse } from "../common/common-response.interface";

export class UserResponse extends GeneralResponse {
    value: User;
    constructor(){
      super();
      this.value = new User();
    }
  }

export class ListUserResponse extends GeneralResponse {
    value: User[];
    constructor(){
      super();
      this.value = new Array<User>();
    }
  }

export class UserPagination
  {
      length: number;
      size: number;
      page: number;
      lastPage: number;
      startIndex: number;
      endIndex: number;
  }

export class User{

    //Response Auth
    codUser: string;
    userName: string;
    nombreCompleto: string;

    idUser: string;
    names: string;
    surnames: string;
    password: string;
    cellPhone: string;
    email: string;
    creationTime: string;
    isActive: number;
    gender: string;
    idDocumentType: number;
    documentNumber: string;
    photoFront: string;
  }
