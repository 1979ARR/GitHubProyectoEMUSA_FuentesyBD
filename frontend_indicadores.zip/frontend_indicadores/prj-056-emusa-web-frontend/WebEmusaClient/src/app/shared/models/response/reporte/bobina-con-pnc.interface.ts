import { GeneralResponse } from "../common/common-response.interface";

//#region Bobina con PNC

export class BobinaPncResponse extends GeneralResponse {
    result: BobinaConPNC;
    constructor(){
      super();
      this.result = new BobinaConPNC();
    }
  }

export class BobinaConPNC {
    totalRegistros: number;
    bobinaConPNC: ItemBobinaPnc[];
    constructor(){
        this.bobinaConPNC = new Array<ItemBobinaPnc>();
    }
}

export class ItemBobinaPnc {
        id: string;
        almacen_serie: string;
        bobi_serie: string;
        bobi_codigo: number;
        bobi_peso: number;
        bobi_peso_stock: number;
        hoia_fecha_oia: string;
        hoia_secuencial: number;
        codigo_transaccion: string;
        porden_int_panasa: number;
        mitem_codigo: number;
        unidad_codigo: string;
        bobina_inventariada: string;
        desc_proveedor: string;
        num_compra: string;
        bobi_estado: string;
        cc_result: string;
        sec_pnc: number;
        sec_pnc_tiempo: number;
        ubi_almacen_serie: string;
        ubi_subalmnum: string;
        ubifisi_codigo: string;
        bp_lote: string;
        hcc_fecha_muestra: string;
        fecha_emusa: string;
        fecha_hoia_orden: string;
        fecha_emusa_orden: string;
        fecha_hcc_orden: string;
        seleccionado?: boolean;
}

//#endregion