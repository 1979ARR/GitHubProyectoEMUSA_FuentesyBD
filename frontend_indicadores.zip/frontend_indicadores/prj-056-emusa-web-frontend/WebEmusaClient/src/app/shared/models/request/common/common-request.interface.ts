
export class CommonParameterRequest {
    idParameter: number;
    text: string;
    value: string;
    groupKey: string;
    isParent: number;
    isActive: number;
  }

  export class FilterCommon {
    numeroPagina: number;
    cantidadPagina: number;
    columnaOrdenamiento: number;
    direccionOrdenamiento: string;
  }