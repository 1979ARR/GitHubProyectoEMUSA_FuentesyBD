import { GeneralResponse } from "../common/common-response.interface";

//#region Proceso de Produccion

export class ProcesoProduccionResponse extends GeneralResponse {
    result: ProcesoProduccion;
    constructor(){
      super();
      this.result = new ProcesoProduccion();
    }
  }

export class ProcesoProduccion {
    totalRegistros: number;
    procesoProduccion: ItemProcesoProduccion[];
    constructor(){
        this.procesoProduccion = new Array<ItemProcesoProduccion>();
    }
}

export class ItemProcesoProduccion {
        id: string;
        hproc_fecha_grab: string;
        proceso_codigo: string;
        maquina_codigo: string;
        unidad_equivalente: string;
        cantidad_equivalente: number;
        planta_serie: string;
        hord_trab_secuencial: string;
        maquina_descripcion: string;
        proceso_descripcion: string;
        eproc_bobi_peso: number;
        fecha_hproc_orden: string;
        seleccionado?: boolean;
}

//#endregion