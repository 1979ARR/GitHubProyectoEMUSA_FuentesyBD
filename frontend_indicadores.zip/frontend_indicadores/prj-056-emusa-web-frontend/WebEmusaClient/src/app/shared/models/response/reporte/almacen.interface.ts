import { GeneralResponse } from "../common/common-response.interface";

//#region Almacen

export class AlmacenResponse extends GeneralResponse {
    result: ItemAlmacen;
    constructor(){
      super();
      this.result = new ItemAlmacen();
    }
  }

export class ListAlmacenResponse extends GeneralResponse {
    result: AlmacenResult;
}

export class AlmacenResult {
  almacen: ItemAlmacen[];
  constructor(){
      this.almacen = new Array<ItemAlmacen>();
  }
}

export class ItemAlmacen {
    
    almacenSerie: string;
    almacenNombre: string;
}

//#endregion