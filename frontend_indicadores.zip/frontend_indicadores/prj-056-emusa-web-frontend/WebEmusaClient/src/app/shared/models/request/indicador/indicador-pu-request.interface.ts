
export class IndicadorPURequest {
    almacen: string;
    linea: string;
    subLinea: string;
    anio: string;
    usuario: string;
}
