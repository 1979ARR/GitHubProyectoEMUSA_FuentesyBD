import { GeneralResponse, MenuWorkspace } from "./common-response.interface";

export class ListGroupItemsResponse extends GeneralResponse {
  value: GroupItems[];
    constructor(){
      super();
      this.value = new Array<GroupItems>();
    }
}

export class GeneralPagination{
    length: number;
    size: number;
    page: number;
    lastPage: number;
    startIndex: number;
    endIndex: number;
    constructor(){
      this.length = 0;
      this.size = 0;
      this.page = 0;
    }
}

export class GroupItems{
  idParameter: number;
	text: string;
  value: string;
  groupKey: string;
}

export class ParameterPagination
  {
      length: number;
      size: number;
      page: number;
      lastPage: number;
      startIndex: number;
      endIndex: number;
  }