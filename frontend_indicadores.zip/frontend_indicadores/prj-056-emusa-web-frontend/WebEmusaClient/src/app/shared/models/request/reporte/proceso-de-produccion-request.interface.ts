import { FilterCommon } from "../common/common-request.interface";

export class ProcesoProduccionRequest extends FilterCommon {
    fechaDesde: string;
    fechaHasta: string;
    almacenSerie: string;
    mitemCodigo: number;
    bobiCodigo: number;
    ordenTrabajo: number;
    periodoMes: string;
    periodoAnio: string;

}