import { FilterCommon } from "../common/common-request.interface";

export class BobinaPncRequest extends FilterCommon {
    fechaDesde: string;
    fechaHasta: string;
    almacenSerie: string;
    mitemCodigo: number;
    bobiCodigo: number;
    linea: string;
    subLinea: string;
    periodoMes: string;
    periodoAnio: string;

}