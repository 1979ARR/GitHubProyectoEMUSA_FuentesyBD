import { GeneralResponse } from "../common/common-response.interface";

export class IndicadorERIResponse extends GeneralResponse {
    result: IndicadorERI;
}

export class IndicadorERI {
    insumoAvance: number;
    insumoFalta: number;
    materiaPrimaAvance: number;
    materiaPrimaFalta: number;
    suministroAvance: number;
    suministroFalta: number;

    productoTerminadoInventariado: number;
    productoTerminadoNoInventariado: number;
    muestraVentaInventariada: number;
    muestraVentaNoInventariada: number;

    cantidad: number;
    total: number;
}

export class IndicadorERICurrent {
    almacen: string;
    subAlmacen: string;
    linea: string;
    subLinea: string;
    cantidad: number;
    total: number;
    cantidadLinea: number;
    totalLinea: number;
}

export class IndicadorPUResponse extends GeneralResponse {
    result: ResultProduccionResponse;
}

export class ResultProduccionResponse {
    itemsProduccion: GlobalProduccionResponse[];
    constructor(){
        this.itemsProduccion = new Array<GlobalProduccionResponse>();
    }
}

export class GlobalProduccionResponse {
    id: number;
    cantidad: number;
    items: ItemProduccionResponse[];
    constructor(){
        this.items = new Array<ItemProduccionResponse>();
    }
}

export class ItemProduccionResponse {
    cantidad: number;
    fecha: string;
}

export class IndicadorCAResponse extends GeneralResponse {
    result: IndicadorCA;
}

export class IndicadorCA {
    materiaPrima: ItemCA;
    productosProceso: ItemCA;
    productosTerminados: ItemCA;
}

export class ItemCA {
    limiteVerde: number;
    limiteAmarillo: number;
    limiteRojo: number;
    valor: number;
}

export class UsuarioIngResponse extends GeneralResponse {
    result: UsuarioInd[];
    constructor(){
        super();
        this.result = new Array<UsuarioInd>();
    }
}

export class UsuarioInd {
    codigo: string;
    descripcion: string;
}

export class TablaERIResponse extends GeneralResponse {
    result: TablaERIInd[];
    constructor(){
        super();
        this.result = new Array<TablaERIInd>();
    }
}

export class TablaERIInd {
    origenDescripcion?: string;
    clienteCodigo?: string;
    sucursalDescripcion?: string;
    unidadCodigo?: string;
    lineaDescripcion?: string;
    cantidad?: number;
    peso?: number;
}

export class IndicadorFIFOResponse extends GeneralResponse {
    result: IndicadorFIFO;
}

export class IndicadorFIFO {
    valor1: number;
    valor2: number;
    valor3: number;
    valor4: number;
    valor5: number;
    valor6: number;
}

export class IndicadorROResponse extends GeneralResponse {
    result: ResultRotacionResponse;
}

export class ResultRotacionResponse {
    itemsRotacion: GlobalRotacionResponse[];
    constructor(){
        this.itemsRotacion = new Array<GlobalRotacionResponse>();
    }
}

export class GlobalRotacionResponse {
    id: number;
    cantidad: number;
    items: ItemRotacionResponse[];
    constructor(){
        this.items = new Array<ItemRotacionResponse>();
    }
}

export class ItemRotacionResponse {
    cantidad: number;
    fecha: string;
}