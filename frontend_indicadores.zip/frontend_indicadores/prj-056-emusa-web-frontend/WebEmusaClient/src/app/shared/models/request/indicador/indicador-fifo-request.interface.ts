
export class IndicadorFIFORequest {
    almacen: string;
    subAlmacen: string;
    linea: string;
    subLinea: string;
}
