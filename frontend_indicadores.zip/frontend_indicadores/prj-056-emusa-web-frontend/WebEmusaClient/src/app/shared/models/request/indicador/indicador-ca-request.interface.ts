
export class IndicadorCARequest {
    almacen: string;
    linea: string;
    subLinea: string;
    ubicacion: string;
    tipo: string;
}
