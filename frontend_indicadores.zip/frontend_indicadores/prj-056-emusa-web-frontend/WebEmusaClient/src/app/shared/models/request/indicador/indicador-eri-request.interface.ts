
export class IndicadorERIRequest {
    almacen: string;
    subAlmacen: string;
    linea: string;
    subLinea: string;
}
