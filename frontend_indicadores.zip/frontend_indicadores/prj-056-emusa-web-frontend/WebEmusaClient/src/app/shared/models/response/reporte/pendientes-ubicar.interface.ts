import { GeneralResponse } from "../common/common-response.interface";

//#region REPORTE MATERIA PRIMA

export class MateriaPrimaPPUResponse extends GeneralResponse {
    result: MateriaPrimaPPU;
    constructor(){
      super();
      this.result = new MateriaPrimaPPU();
    }
  }

export class MateriaPrimaPPU {
    totalRegistros: number;
    materiaPrima: ItemMateriaPrimaPPU[];
    constructor(){
        this.materiaPrima = new Array<ItemMateriaPrimaPPU>();
    }
}

export class ItemMateriaPrimaPPU {
  id: string;
  almacen_serie: string;
  bobi_serie: string;
  bobi_codigo: number;
  ubi_almacen_serie: string;
  ubi_subalmnum: string;
  ubifisi_codigo: string;
  bobi_peso: number;
  bobi_peso_stock: number;
  mitem_codigo: number;
  item_descripcio: string;
  unidad_codigo: string;
  origen_descripcion: string;
  linea_descripcion: string;
  sublinea_descripcion: string;
  bobi_fecha_ingreso: string;
  flag: string;
  hoia_secuencial: string;
  trans_descripcion: string;
  usu_ult_modif: string;
  bobi_fec_ult_modif: string;
  ubic_orig: string;
  bobina_inventariada: string;
  bobi_fec_leida: string;
  bca_codigo: number;
  bobi_observaciones: string;
  ancho: number;
  espesor: number;
  bobi_fecha_salida: string;
  fecha_ingreso_orden: string;
  fecha_ult_orden: string;
  fecha_leida_orden: string;
  fecha_salida_orden: string;
  seleccionado?: boolean;
}

//#endregion

//#region REPORTE PRODUCTOS PROCESO
export class ProductosEnProcesoPPUResponse extends GeneralResponse {
  result: ProductosEnProcesoPPU;
  constructor(){
    super();
    this.result = new ProductosEnProcesoPPU();
  }
}

export class ProductosEnProcesoPPU {
  totalRegistros: number;
  productosEnProceso: ItemProductosEnProcesoPPU[];
  constructor(){
      this.productosEnProceso = new Array<ItemProductosEnProcesoPPU>();
  }
}

export class ItemProductosEnProcesoPPU {
     id: string;
     almacen_serie: string;
     bobi_codigo: number;
     bobi_serie: string;
     mitem_codigo: number;
     bobi_peso: number;
     unidad_codigo: string;
     bobina_longitud: number;
     bobi_fecha_ingreso: string;
     bobina_peso_bruto: number;
     bobina_inventariada: string;
     hproc_secuencial: number;
     condicion_codigo: string;
     hord_trab_secuencial: number;
     proceso_codigo: number;
     maquina_codigo: number;
     alm_serie_transfer: string;
     dmot_codigo: string;
     MOTIVO2: string;
     mot_devolucion: string;
     item_descripcio: string;
     unidad_equivalente: string;
     cantidad_equivalente: number;
     planta_serie: string;
     codigo_transaccion: string;
     causa_descripcion: string;
     hped_numero: number;
     situacion: number;
     vendedor_nombre: string;
     hproc_fecha_grab: string;
     ubifisi_codigo: string;
     bobi_fec_prod: string;
     cod_naturaleza: string;
     bobi_fec_leida: string;
     fecha_ingreso_orden: string;
     fecha_hproc_orden: string;
     fecha_prod_orden: string;
     fecha_leida_orden: string;
     seleccionado?: boolean;
}

//#endregion
//#region REPORTE PRODUCTOS TERMINADOS
export class ProductosTerminadosPPUResponse extends GeneralResponse {
  result: ProductosTerminadosPPU;
  constructor(){
    super();
    this.result = new ProductosTerminadosPPU();
  }
}

export class ProductosTerminadosPPU {
  totalRegistros: number;
  productosTerminados: ItemProductosTerminadosPPU[];
  constructor(){
      this.productosTerminados = new Array<ItemProductosTerminadosPPU>();
  }
}

export class ItemProductosTerminadosPPU {
  id: string;
  tipo: string;
  desc_tipo: string;
  bobina_inventariada: string;
  bobi_serie: string; 
  bobi_codigo: number;
  bobi_peso: number;
  bobina_peso_bruto: number;
  bobina_unidad_codigo: string;
  bobina_longitud: number;
  mitem_codigo: number;
  unidad_codigo: string;
  almacen_serie: string;
  item_descripcio: string;
  planta_serie: string;
  hord_trab_secuencial: number;
  descripcion_tamano: string;
  mitem_gramaje: number;
  unidad_equivalente: string;
  cantidad_equivalente: string;
  pedido: string;
  cliente: string;
  sucursal_descripcion: string;
  hproc_secuencial: number;
  condicion_codigo: string;
  condicion_descripcion: string;
  hproc_fecha_grab: string;
  ubifisi_codigo: string;
  bobi_fec_prod: string;
  fecha_hproc_orden: string;
  fecha_prod_orden: string;
  seleccionado?:boolean;
}

//#endregion