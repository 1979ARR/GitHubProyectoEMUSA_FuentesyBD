import { GeneralResponse } from "../common/common-response.interface";

export class AniosResponse extends GeneralResponse {
    result: number[];
    constructor(){
        super();
        this.result = new Array<number>();
    }
}
export class MesResponse extends GeneralResponse {
    result: string[];
    constructor(){
        super();
        this.result = new Array<string>();
    }
}

export class Mes {
    nombre: string;
    codigo: string;
}