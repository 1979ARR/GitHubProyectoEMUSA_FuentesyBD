import { GeneralResponse } from "../common/common-response.interface";

//#region Kardex Bobina

export class KardexBobinaResponse extends GeneralResponse {
    result: KardexBobina;
    constructor(){
      super();
      this.result = new KardexBobina();
    }
  }

export class KardexBobina {
    totalRegistros: number;
    kardexBobina: ItemKardexBobina[];
    constructor(){
        this.kardexBobina = new Array<ItemKardexBobina>();
    }
}

export class ItemKardexBobina {
    id: string;
    fechaGrabacion: string;
    bobiCodigo: number;
    bobiSerie: string;
    ubifisiCodigo: string;
    ubiAlmacenSerie: string;
    unidadCodigo: string;
    usuUltModif: string;
    bobiPeso: number;
    bobiPesoStock: number;
    mitemCodigo: number;
    descripcion: string;
    almacenSerie: string;
    bobiEstado: string;
    fechaOrden: string;
    seleccionado?: boolean;
}

//#endregion