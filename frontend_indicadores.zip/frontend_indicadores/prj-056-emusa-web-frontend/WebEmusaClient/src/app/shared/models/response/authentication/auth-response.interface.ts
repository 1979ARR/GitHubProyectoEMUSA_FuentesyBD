import { GeneralResponse } from "../common/common-response.interface";
import { User } from "../user/user-response.interface";

export class AuthResponse extends GeneralResponse {
    result: Auth;
    constructor(){
      super();
      this.result = new Auth();
    }
  }

  export class Auth{
      token: string;
      expiracionToken: Date;
      access: boolean;
      usuario: User;
      perfil: ProfileAuth[];
      opciones: OptionsAuth[];
      constructor(){
        this.usuario = new User();
      }
  }

  export class ProfileAuth {
    codPerfil : string;
    descPerfil: string;
  }

  export class OptionsAuth {
    codOpcion: string;
    descOpcion: string;
  }
