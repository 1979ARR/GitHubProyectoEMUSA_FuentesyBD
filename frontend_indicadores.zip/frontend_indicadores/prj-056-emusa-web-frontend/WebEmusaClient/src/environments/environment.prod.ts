export const environment = {
    production: true,
    serverUriApi: 'http://181.177.242.42:5534/api/',//https://hdkp.mcode.pe/api/
    urlClient: 'http://92.205.19.29:5001/',//https://hdkp.mcode.pe/
    urlLogin: 'http://181.177.242.42:5560/sign-in', //https://hdkp.mcode.pe/sign-in
};