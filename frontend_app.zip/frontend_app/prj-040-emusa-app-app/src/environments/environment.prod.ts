export const environment = {
  production: true,
  appConfig: 'appconfig.production.json',
  location: 'PROD'
};
