import { mergeMap as _observableMergeMap, catchError as _observableCatch } from 'rxjs/operators';
import { Observable, throwError as _observableThrow, of as _observableOf } from 'rxjs';
import { Injectable, Inject, Optional, InjectionToken } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse, HttpResponseBase } from '@angular/common/http';

export const API_BASE_URL = new InjectionToken<string>('API_BASE_URL');

@Injectable()
export class EmusaServiceProxy {
    private http: HttpClient;
    private baseUrl: string;

    constructor(@Inject(HttpClient) http: HttpClient, @Optional() @Inject(API_BASE_URL) baseUrl?: string) {
        this.http = http;
        this.baseUrl = baseUrl ? baseUrl : "";
    }

    login(body: EmusaLogin): Observable<LoginResponse> {
        let url_ = this.baseUrl + "/api/Authentication/login";
        url_ = url_.replace(/[?&]$/, "");

        const content_ = JSON.stringify(body);

        let options_: any = {
            body: content_,
            observe: "response",
            responseType: "blob",
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processLogin(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processLogin(<any>response_);
                } catch (e) {
                    return <Observable<LoginResponse>><any>_observableThrow(e);
                }
            } else
                return <Observable<LoginResponse>><any>_observableThrow(response_);
        }));
    }

    protected processLogin(response: HttpResponseBase): Observable<LoginResponse> {
        const status = response.status;
        const responseBlob =
            response instanceof HttpResponse ? response.body :
                (<any>response).error instanceof Blob ? (<any>response).error : undefined;
        let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } };
        if (status === 200) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                let result200: any = null;
                let resultData200 = _responseText === "" ? null : JSON.parse(_responseText)?.result;
                result200 = LoginResponse.fromJS(resultData200);
                return _observableOf(result200);
            }));
        } else if (status !== 200 && status !== 204) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                return _observableThrow(_responseText);
            }));
        }
        return _observableOf<LoginResponse>(<any>null);
    }

    session(): Observable<SessionReponse> {
        let url_ = this.baseUrl + "/api/Authentication/validarsesion";
        url_ = url_.replace(/[?&]$/, "");

        let options_: any = {
            observe: "response",
            responseType: "blob",
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processSession(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processSession(<any>response_);
                } catch (e) {
                    return <Observable<SessionReponse>><any>_observableThrow(e);
                }
            } else
                return <Observable<SessionReponse>><any>_observableThrow(response_);
        }));
    }

    protected processSession(response: HttpResponseBase): Observable<SessionReponse> {
        const status = response.status;
        const responseBlob =
            response instanceof HttpResponse ? response.body :
                (<any>response).error instanceof Blob ? (<any>response).error : undefined;
        let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } };
        if (status === 200) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                let result200: any = null;
                let resultData200 = _responseText === "" ? null : JSON.parse(_responseText)?.result;
                result200 = SessionReponse.fromJS(resultData200);
                return _observableOf(result200);
            }));
        } else if (status !== 200 && status !== 204) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                return _observableThrow(_responseText);
            }));
        }
        return _observableOf<SessionReponse>(<any>null);
    }

    getWarehouses(): Observable<WarehouseDto[]> {
        let url_ = this.baseUrl + "/api/Almacen/consultar";
        url_ = url_.replace(/[?&]$/, "");

        let options_: any = {
            observe: "response",
            responseType: "blob",
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("get", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processGetWarehouses(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processGetWarehouses(<any>response_);
                } catch (e) {
                    return <Observable<WarehouseDto[]>><any>_observableThrow(e);
                }
            } else
                return <Observable<WarehouseDto[]>><any>_observableThrow(response_);
        }));
    }

    protected processGetWarehouses(response: HttpResponseBase): Observable<WarehouseDto[]> {
        const status = response.status;
        const responseBlob =
            response instanceof HttpResponse ? response.body :
                (<any>response).error instanceof Blob ? (<any>response).error : undefined;
        let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } };
        if (status === 200) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                let result200: WarehouseDto[] = [];
                let resultData200 = _responseText === "" ? null : JSON.parse(_responseText)?.result;
                if (Array.isArray(resultData200))
                    for (let item of resultData200)
                        result200.push(WarehouseDto.fromJS(item));
                return _observableOf(result200);
            }));
        } else if (status !== 200 && status !== 204) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                return _observableThrow(_responseText);
            }));
        }
        return _observableOf<WarehouseDto[]>(<any>null);
    }

    getPendingProducts(warehouse: string, type: 'M' | 'P' | 'T'): Observable<PagedResultListOfProductDto> {
        let url_ = this.baseUrl + "/api/Almacen/pendientesubicar";
        url_ = url_.replace(/[?&]$/, "");

        const _body: string = JSON.stringify({
            codAlmacen: warehouse,
            codTipoProducto: type
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processGetPendingProducts(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processGetPendingProducts(<any>response_);
                } catch (e) {
                    return <Observable<PagedResultListOfProductDto>><any>_observableThrow(e);
                }
            } else
                return <Observable<PagedResultListOfProductDto>><any>_observableThrow(response_);
        }));
    }

    protected processGetPendingProducts(response: HttpResponseBase): Observable<PagedResultListOfProductDto> {
        const status = response.status;
        const responseBlob =
            response instanceof HttpResponse ? response.body :
                (<any>response).error instanceof Blob ? (<any>response).error : undefined;
        let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } };
        if (status === 200) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                let result200: any = null;
                let resultData200 = _responseText === "" ? null : JSON.parse(_responseText)?.result;
                result200 = PagedResultListOfProductDto.fromJS(resultData200);
                return _observableOf(result200);
            }));
        } else if (status !== 200 && status !== 204) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                return _observableThrow(_responseText);
            }));
        }
        return _observableOf<PagedResultListOfProductDto>(<any>null);
    }

    getInventoryPending(codAlmacen: string, codTipoProducto: string): Observable<InventoryPendingDto> {
        let url_ = this.baseUrl + "/api/Almacen/pendientesInventariar";
        url_ = url_.replace(/[?&]$/, "");

        const _body: string = JSON.stringify({
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processGetInventoryPending(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processGetInventoryPending(<any>response_);
                } catch (e) {
                    return <Observable<InventoryPendingDto>><any>_observableThrow(e);
                }
            } else
                return <Observable<InventoryPendingDto>><any>_observableThrow(response_);
        }));
    }

    protected processGetInventoryPending(response: HttpResponseBase): Observable<InventoryPendingDto> {
        const status = response.status;
        const responseBlob =
            response instanceof HttpResponse ? response.body :
                (<any>response).error instanceof Blob ? (<any>response).error : undefined;
        let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } };
        if (status === 200) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                let result200: any = null;
                let resultData200 = _responseText === "" ? null : JSON.parse(_responseText)?.result;
                result200 = InventoryPendingDto.fromJS(resultData200);
                return _observableOf(result200);
            }));
        } else if (status !== 200 && status !== 204) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                return _observableThrow(_responseText);
            }));
        }
        return _observableOf<InventoryPendingDto>(<any>null);
    }

    getPickingOtApiladorPending(codAlmacen: string, codTipoProducto: string): Observable<PickingOtApiladorPendingDto> {
        let url_ = this.baseUrl + "/api/Almacen/pendientesPickupOTBobinaApilador";
        url_ = url_.replace(/[?&]$/, "");

        const _body = JSON.stringify({
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processGetPickingOtApiladorPending(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processGetPickingOtApiladorPending(<any>response_);
                } catch (e) {
                    return <Observable<PickingOtApiladorPendingDto>><any>_observableThrow(e);
                }
            } else
                return <Observable<PickingOtApiladorPendingDto>><any>_observableThrow(response_);
        }));
    }

    protected processGetPickingOtApiladorPending(response: HttpResponseBase): Observable<PickingOtApiladorPendingDto> {
        const status = response.status;
        const responseBlob =
            response instanceof HttpResponse ? response.body :
                (<any>response).error instanceof Blob ? (<any>response).error : undefined;
        let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } };
        if (status === 200) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                let result200: any = null;
                let resultData200 = _responseText === "" ? null : JSON.parse(_responseText)?.result;
                result200 = PickingOtApiladorPendingDto.fromJS(resultData200);
                return _observableOf(result200);
            }));
        } else if (status !== 200 && status !== 204) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                return _observableThrow(_responseText);
            }));
        }
        return _observableOf<PickingOtApiladorPendingDto>(<any>null);
    }

    getPickingOtStockPending(codAlmacen: string, codTipoProducto: string): Observable<PickingOtStockPendingDto> {
        let url_ = this.baseUrl + "/api/Almacen/pendientesPickupOTBobinaStockero";
        url_ = url_.replace(/[?&]$/, "");

        const _body = JSON.stringify({
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processGetPickingOtStockPending(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processGetPickingOtStockPending(<any>response_);
                } catch (e) {
                    return <Observable<PickingOtStockPendingDto>><any>_observableThrow(e);
                }
            } else
                return <Observable<PickingOtStockPendingDto>><any>_observableThrow(response_);
        }));
    }

    protected processGetPickingOtStockPending(response: HttpResponseBase): Observable<PickingOtStockPendingDto> {
        const status = response.status;
        const responseBlob =
            response instanceof HttpResponse ? response.body :
                (<any>response).error instanceof Blob ? (<any>response).error : undefined;
        let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } };
        if (status === 200) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                let result200: any = null;
                let resultData200 = _responseText === "" ? null : JSON.parse(_responseText)?.result;
                result200 = PickingOtStockPendingDto.fromJS(resultData200);
                return _observableOf(result200);
            }));
        } else if (status !== 200 && status !== 204) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                return _observableThrow(_responseText);
            }));
        }
        return _observableOf<PickingOtStockPendingDto>(<any>null);
    }

    getDispatchPending(codAlmacen: string, codTipoProducto: string, codSecuencial: string): Observable<DispatchPendingDto> {
        let url_ = this.baseUrl + "/api/Almacen/obtenerBobinasporSecuencialApp";
        url_ = url_.replace(/[?&]$/, "");

        const _body = JSON.stringify({
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto,
            codSecuencialApp: codSecuencial
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processGetDispatchPending(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processGetDispatchPending(<any>response_);
                } catch (e) {
                    return <Observable<DispatchPendingDto>><any>_observableThrow(e);
                }
            } else
                return <Observable<DispatchPendingDto>><any>_observableThrow(response_);
        }));
    }

    protected processGetDispatchPending(response: HttpResponseBase): Observable<DispatchPendingDto> {
        const status = response.status;
        const responseBlob =
            response instanceof HttpResponse ? response.body :
                (<any>response).error instanceof Blob ? (<any>response).error : undefined;
        let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } };
        if (status === 200) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                let result200: any = null;
                let resultData200 = _responseText === "" ? null : JSON.parse(_responseText)?.result;
                result200 = DispatchPendingDto.fromJS(resultData200);
                return _observableOf(result200);
            }));
        } else if (status !== 200 && status !== 204) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                return _observableThrow(_responseText);
            }));
        }
        return _observableOf<DispatchPendingDto>(<any>null);
    }

    getOperationDispatchPending(codAlmacen: string, codTipoProducto: string, codSecuencial: string): Observable<OperationDispatchPendingDto> {
        let url_ = this.baseUrl + "/api/Almacen/obtenerBobinasporSecuencialAppNI";
        url_ = url_.replace(/[?&]$/, "");

        const _body = JSON.stringify({
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto,
            codSecuencialApp: codSecuencial
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processGetOperationDispatchPending(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processGetOperationDispatchPending(<any>response_);
                } catch (e) {
                    return <Observable<OperationDispatchPendingDto>><any>_observableThrow(e);
                }
            } else
                return <Observable<OperationDispatchPendingDto>><any>_observableThrow(response_);
        }));
    }

    protected processGetOperationDispatchPending(response: HttpResponseBase): Observable<OperationDispatchPendingDto> {
        const status = response.status;
        const responseBlob =
            response instanceof HttpResponse ? response.body :
                (<any>response).error instanceof Blob ? (<any>response).error : undefined;
        let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } };
        if (status === 200) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                let result200: any = null;
                let resultData200 = _responseText === "" ? null : JSON.parse(_responseText)?.result;
                result200 = OperationDispatchPendingDto.fromJS(resultData200);
                return _observableOf(result200);
            }));
        } else if (status !== 200 && status !== 204) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                return _observableThrow(_responseText);
            }));
        }
        return _observableOf<OperationDispatchPendingDto>(<any>null);
    }

    updateLocation(codBobina: string, codUbicacion: string, codAlmacen: string, codTipoProducto: string): Observable<UpdateLocationResponse> {
        let url_ = this.baseUrl + "/api/Almacen/actualizarUbicacion";
        url_ = url_.replace(/[?&]$/, "");

        const _body = JSON.stringify({
            codBobina: codBobina,
            codUbicacion: codUbicacion,
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processUpdateLocation(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processUpdateLocation(<any>response_);
                } catch (e) {
                    return <Observable<UpdateLocationResponse>><any>_observableThrow(e);
                }
            } else
                return <Observable<UpdateLocationResponse>><any>_observableThrow(response_);
        }));
    }

    updateInventoryLocation(codBobina: string, codUbicacion: string, codAlmacen: string, codTipoProducto: string): Observable<UpdateLocationResponse> {
        let url_ = this.baseUrl + "/api/Almacen/actualizarUbicacionInventario";
        url_ = url_.replace(/[?&]$/, "");

        const _body = JSON.stringify({
            codBobina: codBobina,
            codUbicacion: codUbicacion,
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processUpdateLocation(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processUpdateLocation(<any>response_);
                } catch (e) {
                    return <Observable<UpdateLocationResponse>><any>_observableThrow(e);
                }
            } else
                return <Observable<UpdateLocationResponse>><any>_observableThrow(response_);
        }));
    }

    updatePickingOtApiladorLocation(codBobina: string, codUbicacion: string, codAlmacen: string, codTipoProducto: string): Observable<UpdateLocationResponse> {
        let url_ = this.baseUrl + "/api/Almacen/actualizarUbicacionPickingOTBobinaApilador";
        url_ = url_.replace(/[?&]$/, "");

        const _body = JSON.stringify({
            codBobina: codBobina,
            codUbicacion: codUbicacion,
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processUpdateLocation(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processUpdateLocation(<any>response_);
                } catch (e) {
                    return <Observable<UpdateLocationResponse>><any>_observableThrow(e);
                }
            } else
                return <Observable<UpdateLocationResponse>><any>_observableThrow(response_);
        }));
    }

    updatePickingStockLocation(codBobina: string, codUbicacion: string, codAlmacen: string, codTipoProducto: string): Observable<UpdateLocationResponse> {
        let url_ = this.baseUrl + "/api/Almacen/actualizarUbicacionPickingOTBobinaStokero";
        url_ = url_.replace(/[?&]$/, "");

        const _body = JSON.stringify({
            codBobina: codBobina,
            codUbicacion: codUbicacion,
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processUpdateLocation(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processUpdateLocation(<any>response_);
                } catch (e) {
                    return <Observable<UpdateLocationResponse>><any>_observableThrow(e);
                }
            } else
                return <Observable<UpdateLocationResponse>><any>_observableThrow(response_);
        }));
    }

    updateDispatchLocation(codSecuencial: string, codUbicacion: string, codAlmacen: string, codTipoProducto: string): Observable<UpdateLocationResponse> {
        let url_ = this.baseUrl + "/api/Almacen/actualizarUbicacionInventarioSecuencialApp";
        url_ = url_.replace(/[?&]$/, "");

        const _body = JSON.stringify({
            codSecuencialApp: codSecuencial,
            codUbicacion: codUbicacion,
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processUpdateLocation(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processUpdateLocation(<any>response_);
                } catch (e) {
                    return <Observable<UpdateLocationResponse>><any>_observableThrow(e);
                }
            } else
                return <Observable<UpdateLocationResponse>><any>_observableThrow(response_);
        }));
    }

    updateOperationDispatchLocation(codSecuencial: string, codUbicacion: string, codAlmacen: string, codTipoProducto: string): Observable<UpdateLocationResponse> {
        let url_ = this.baseUrl + "/api/Almacen/actualizarUbicacionSecuencialApp";
        url_ = url_.replace(/[?&]$/, "");

        const _body = JSON.stringify({
            codSecuencialApp: codSecuencial,
            codUbicacion: codUbicacion,
            codAlmacen: codAlmacen,
            codTipoProducto: codTipoProducto
        });

        let options_: any = {
            observe: "response",
            responseType: "blob",
            body: _body,
            headers: new HttpHeaders({
                "Content-Type": "application/json-patch+json",
                "Accept": "text/plain"
            })
        };

        return this.http.request("post", url_, options_).pipe(_observableMergeMap((response_: any) => {
            return this.processUpdateLocation(response_);
        })).pipe(_observableCatch((response_: any) => {
            if (response_ instanceof HttpResponseBase) {
                try {
                    return this.processUpdateLocation(<any>response_);
                } catch (e) {
                    return <Observable<UpdateLocationResponse>><any>_observableThrow(e);
                }
            } else
                return <Observable<UpdateLocationResponse>><any>_observableThrow(response_);
        }));
    }

    protected processUpdateLocation(response: HttpResponseBase): Observable<UpdateLocationResponse> {
        const status = response.status;
        const responseBlob =
            response instanceof HttpResponse ? response.body :
                (<any>response).error instanceof Blob ? (<any>response).error : undefined;
        let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } };
        if (status === 200) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                let result200: any = null;
                let resultData200 = _responseText === "" ? null : JSON.parse(_responseText);
                result200 = UpdateLocationResponse.fromJS(resultData200);
                return _observableOf(result200);
            }));
        } else if (status !== 200 && status !== 204) {
            return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
                return _observableThrow(_responseText);
            }));
        }
        return _observableOf<UpdateLocationResponse>(<any>null);
    }

}

export interface IEmusaLogin {
    userName: string;
    password: string;
}

export class EmusaLogin implements IEmusaLogin {
    userName: string;
    password: string;

    constructor(data?: IEmusaLogin) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.userName = _data["userName"];
            this.password = _data["password"];
        }
    }

    static fromJS(data: any): EmusaLogin {
        data = typeof data === 'object' ? data : {};
        let result = new EmusaLogin();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["userName"] = this.userName;
        data["password"] = this.password;

        return data;
    }
}


export interface ISessionReponse {
    usuario: UserDto;
    perfil: ProfileDto[];
    opciones: OptionDto[];
}

export class SessionReponse implements ISessionReponse {
    usuario: UserDto;
    perfil: ProfileDto[];
    opciones: OptionDto[];

    constructor(data?: ISessionReponse) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.usuario = _data["usuario"] ? UserDto.fromJS(_data["usuario"]) : <any>undefined;
            this.perfil = _data["perfil"] ? ProfileDto.fromJS(_data["perfil"]) : <any>undefined;
            if (Array.isArray(_data["opciones"])) {
                this.opciones = [] as any;
                for (let item of _data["opciones"])
                    this.opciones!.push(OptionDto.fromJS(item));
            }
            if (Array.isArray(_data["perfil"])) {
                this.perfil = [] as any;
                for (let item of _data["perfil"])
                    this.perfil!.push(ProfileDto.fromJS(item));
            }
        }
    }

    static fromJS(data: any): SessionReponse {
        data = typeof data === 'object' ? data : {};
        let result = new SessionReponse();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["usuario"] = this.usuario ? this.usuario.toJSON() : <any>undefined;
        if (Array.isArray(this.perfil)) {
            data["perfil"] = [];
            for (let item of this.perfil)
                data["perfil"].push(item.toJSON());
        }
        if (Array.isArray(this.opciones)) {
            data["opciones"] = [];
            for (let item of this.opciones)
                data["opciones"].push(item.toJSON());
        }
        return data;
    }
}

export interface ILoginReponse {
    token: string;
    usuario: UserDto;
    perfil: ProfileDto[];
    opciones: OptionDto[];
}

export class LoginResponse implements ILoginReponse {
    token: string;
    usuario: UserDto;
    perfil: ProfileDto[];
    opciones: OptionDto[];

    constructor(data?: ILoginReponse) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.token = _data["token"];
            this.usuario = _data["usuario"] ? UserDto.fromJS(_data["usuario"]) : <any>undefined;
            this.perfil = _data["perfil"] ? ProfileDto.fromJS(_data["perfil"]) : <any>undefined;
            if (Array.isArray(_data["opciones"])) {
                this.opciones = [] as any;
                for (let item of _data["opciones"])
                    this.opciones!.push(OptionDto.fromJS(item));
            }
            if (Array.isArray(_data["perfil"])) {
                this.perfil = [] as any;
                for (let item of _data["perfil"])
                    this.perfil!.push(ProfileDto.fromJS(item));
            }
        }
    }

    static fromJS(data: any): LoginResponse {
        data = typeof data === 'object' ? data : {};
        let result = new LoginResponse();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["token"] = this.token;
        data["usuario"] = this.usuario ? this.usuario.toJSON() : <any>undefined;
        if (Array.isArray(this.perfil)) {
            data["perfil"] = [];
            for (let item of this.perfil)
                data["perfil"].push(item.toJSON());
        }
        if (Array.isArray(this.opciones)) {
            data["opciones"] = [];
            for (let item of this.opciones)
                data["opciones"].push(item.toJSON());
        }
        return data;
    }
}

export interface IUserDto {
    codUser: number;
    userName: string;
    nombreCompleto: string;
}

export class UserDto implements IUserDto {
    codUser: number;
    userName: string;
    nombreCompleto: string;

    constructor(data?: IUserDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.codUser = _data["codUser"];
            this.userName = _data["userName"];
            this.nombreCompleto = _data["nombreCompleto"];
        }
    }

    static fromJS(data: any): UserDto {
        data = typeof data === 'object' ? data : {};
        let result = new UserDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["codUser"] = this.codUser;
        data["userName"] = this.userName;
        data["nombreCompleto"] = this.nombreCompleto;

        return data;
    }
}

export interface IProfileDto {
    codPerfil: number;
    descPerfil: string;
}

export class ProfileDto implements IProfileDto {
    codPerfil: number;
    descPerfil: string;

    constructor(data?: IProfileDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.codPerfil = _data["codPerfil"];
            this.descPerfil = _data["descPerfil"];
        }
    }

    static fromJS(data: any): ProfileDto {
        data = typeof data === 'object' ? data : {};
        let result = new ProfileDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["codPerfil"] = this.codPerfil;
        data["descPerfil"] = this.descPerfil;

        return data;
    }
}

export interface IOptionDto {
    codOpcion: string;
    descOpcion: string;
}

export class OptionDto implements IOptionDto {
    codOpcion: string;
    descOpcion: string;

    constructor(data?: IOptionDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.codOpcion = _data["codOpcion"];
            this.descOpcion = _data["descOpcion"];
        }
    }

    static fromJS(data: any): OptionDto {
        data = typeof data === 'object' ? data : {};
        let result = new OptionDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["codOpcion"] = this.codOpcion;
        data["descOpcion"] = this.descOpcion;

        return data;
    }
}

export interface IWarehouseDto {
    codAlmacen: string;
    descAlmacen: string;
}

export class WarehouseDto implements IWarehouseDto {
    codAlmacen: string;
    descAlmacen: string;

    constructor(data?: IWarehouseDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.codAlmacen = _data["codAlmacen"];
            this.descAlmacen = _data["descAlmacen"];
        }
    }

    static fromJS(data: any): WarehouseDto {
        data = typeof data === 'object' ? data : {};
        let result = new WarehouseDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["codAlmacen"] = this.codAlmacen;
        data["descAlmacen"] = this.descAlmacen;

        return data;
    }
}

export interface IPagedResultListOfProductDto {
    totalRegistros: number;
    pendientesUbicar: ProductDto[];
}

export class PagedResultListOfProductDto implements IPagedResultListOfProductDto {
    totalRegistros: number;
    pendientesUbicar: ProductDto[];

    constructor(data?: IPagedResultListOfProductDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.totalRegistros = _data["totalRegistros"];
            if (Array.isArray(_data["pendientesUbicar"])) {
                this.pendientesUbicar = [] as any;
                for (let item of _data["pendientesUbicar"])
                    this.pendientesUbicar!.push(ProductDto.fromJS(item));
            }
        }
    }

    static fromJS(data: any): PagedResultListOfProductDto {
        data = typeof data === 'object' ? data : {};
        let result = new PagedResultListOfProductDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["totalRegistros"] = this.totalRegistros;
        if (Array.isArray(this.pendientesUbicar)) {
            data["pendientesUbicar"] = [];
            for (let item of this.pendientesUbicar)
                data["pendientesUbicar"].push(item.toJSON());
        }

        return data;
    }
}

export interface IProductDto {
    codBobina: string;
    ubicacion: string;
    codItem: string;
    descBobina: string;
    ot: string;
    peso: string;
    unidadMedida: string;
    fecIngreso: string;
    cantidad: string;
    maquina: string;
}

export class ProductDto implements IProductDto {
    codBobina: string;
    ubicacion: string;
    codItem: string;
    descBobina: string;
    ot: string;
    peso: string;
    unidadMedida: string;
    fecIngreso: string;
    cantidad: string;
    maquina: string;

    constructor(data?: IProductDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.codBobina = _data["codBobina"];
            this.ubicacion = _data["ubicacion"];
            this.codItem = _data["codItem"];
            this.descBobina = _data["descBobina"];
            this.ot = _data["ot"];
            this.peso = _data["peso"];
            this.unidadMedida = _data["unidadMedida"];
            this.fecIngreso = _data["fecIngreso"];
            this.cantidad = _data["cantidad"];
            this.maquina = _data["maquina"];
        }
    }

    static fromJS(data: any): ProductDto {
        data = typeof data === 'object' ? data : {};
        let result = new ProductDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["codBobina"] = this.codBobina;
        data["ubicacion"] = this.ubicacion;
        data["codItem"] = this.codItem;
        data["descBobina"] = this.descBobina;
        data["ot"] = this.ot;
        data["peso"] = this.peso;
        data["unidadMedida"] = this.unidadMedida;
        data["fecIngreso"] = this.fecIngreso;
        data["cantidad"] = this.cantidad;
        data["maquina"] = this.maquina;

        return data;
    }
}

export interface IInventoryPendingDto {
    totalPendientesInventariar: number;
    totalInventariado: number;
}

export class InventoryPendingDto implements IInventoryPendingDto {
    totalPendientesInventariar: number;
    totalInventariado: number;

    constructor(data?: IInventoryPendingDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.totalPendientesInventariar = _data["totalPendientesInventariar"];
            this.totalInventariado = _data["totalInventariado"];
        }
    }

    static fromJS(data: any): InventoryPendingDto {
        data = typeof data === 'object' ? data : {};
        let result = new InventoryPendingDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["totalPendientesInventariar"] = this.totalPendientesInventariar;
        data["totalInventariado"] = this.totalInventariado;

        return data;
    }
}

export interface IPickingOtApiladorPendingDto {
    pendientesPickingOT: ProductDto[];
    totalRegistros: number;
}

export class PickingOtApiladorPendingDto implements IPickingOtApiladorPendingDto {
    pendientesPickingOT: ProductDto[];
    totalRegistros: number;

    constructor(data?: IPickingOtApiladorPendingDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.totalRegistros = _data["totalRegistros"];
            if (Array.isArray(_data["pendientesPickingOT"])) {
                this.pendientesPickingOT = [] as any;
                for (let item of _data["pendientesPickingOT"])
                    this.pendientesPickingOT!.push(ProductDto.fromJS(item));
            }
        }
    }

    static fromJS(data: any): PickingOtApiladorPendingDto {
        data = typeof data === 'object' ? data : {};
        let result = new PickingOtApiladorPendingDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["totalRegistros"] = this.totalRegistros;
        if (Array.isArray(this.pendientesPickingOT)) {
            data["pendientesPickingOT"] = [];
            for (let item of this.pendientesPickingOT)
                data["pendientesPickingOT"].push(item.toJSON());
        }

        return data;
    }
}

export interface IPickingOtStockPendingDto {
    pendientesPickingOT: ProductDto[];
    totalRegistros: number;
}

export class PickingOtStockPendingDto implements IPickingOtStockPendingDto {
    pendientesPickingOT: ProductDto[];
    totalRegistros: number;

    constructor(data?: PickingOtStockPendingDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.totalRegistros = _data["totalRegistros"];
            if (Array.isArray(_data["pendientesPickingOT"])) {
                this.pendientesPickingOT = [] as any;
                for (let item of _data["pendientesPickingOT"])
                    this.pendientesPickingOT!.push(ProductDto.fromJS(item));
            }
        }
    }

    static fromJS(data: any): PickingOtStockPendingDto {
        data = typeof data === 'object' ? data : {};
        let result = new PickingOtStockPendingDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["totalRegistros"] = this.totalRegistros;
        if (Array.isArray(this.pendientesPickingOT)) {
            data["pendientesPickingOT"] = [];
            for (let item of this.pendientesPickingOT)
                data["pendientesPickingOT"].push(item.toJSON());
        }

        return data;
    }
}

export interface IDispatchPendingDto {
    pendientesPickingOT: ProductDto[];
    totalRegistros: number;
}

export class DispatchPendingDto implements IDispatchPendingDto {
    pendientesPickingOT: ProductDto[];
    totalRegistros: number;

    constructor(data?: IDispatchPendingDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.totalRegistros = _data["totalRegistros"];
            if (Array.isArray(_data["pendientesPickingOT"])) {
                this.pendientesPickingOT = [] as any;
                for (let item of _data["pendientesPickingOT"])
                    this.pendientesPickingOT!.push(ProductDto.fromJS(item));
            }
        }
    }

    static fromJS(data: any): DispatchPendingDto {
        data = typeof data === 'object' ? data : {};
        let result = new DispatchPendingDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["totalRegistros"] = this.totalRegistros;
        if (Array.isArray(this.pendientesPickingOT)) {
            data["pendientesPickingOT"] = [];
            for (let item of this.pendientesPickingOT)
                data["pendientesPickingOT"].push(item.toJSON());
        }

        return data;
    }
}

export interface IOperationDispatchPendingDto {
    pendientesPickingOT: ProductDto[];
    totalRegistros: number;
}

export class OperationDispatchPendingDto implements IOperationDispatchPendingDto {
    pendientesPickingOT: ProductDto[];
    totalRegistros: number;

    constructor(data?: IOperationDispatchPendingDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.totalRegistros = _data["totalRegistros"];
            if (Array.isArray(_data["pendientesPickingOT"])) {
                this.pendientesPickingOT = [] as any;
                for (let item of _data["pendientesPickingOT"])
                    this.pendientesPickingOT!.push(ProductDto.fromJS(item));
            }
        }
    }

    static fromJS(data: any): OperationDispatchPendingDto {
        data = typeof data === 'object' ? data : {};
        let result = new OperationDispatchPendingDto();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["totalRegistros"] = this.totalRegistros;
        if (Array.isArray(this.pendientesPickingOT)) {
            data["pendientesPickingOT"] = [];
            for (let item of this.pendientesPickingOT)
                data["pendientesPickingOT"].push(item.toJSON());
        }

        return data;
    }
}

export interface IUpdateLocationResponse {
    status: boolean;
    state: number;
    message: string;
}

export class UpdateLocationResponse implements IUpdateLocationResponse {
    status: boolean;
    state: number;
    message: string;

    constructor(data?: IUpdateLocationResponse) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    init(_data?: any) {
        if (_data) {
            this.status = _data["status"];
            this.state = _data["state"];
            this.message = _data["message"];
        }
    }

    static fromJS(data: any): UpdateLocationResponse {
        data = typeof data === 'object' ? data : {};
        let result = new UpdateLocationResponse();
        result.init(data);
        return result;
    }

    toJSON(data?: any) {
        data = typeof data === 'object' ? data : {};
        data["status"] = this.status;
        data["state"] = this.state;
        data["message"] = this.message;

        return data;
    }
}

export interface IPermissionDto {
    //GESINVENT     Pendientes por Ubicar
    gesinvent: boolean;
    gesinventDes: string;
    //PENDINVEN	Pendientes por Inventariar
    pendinven: boolean;
    pendinvenDes: string;
    //PICKBOBAP	Picking OT por Bobina - Apilador
    pickbobap: boolean;
    pickbobapDes: string;
    //PICKBOBOT	Picking OT por Bobina - Op Traslado
    pickbobot: boolean;
    pickbobotDes: string;
    //PENDINVDE	Pendientes por Despacho
    pendinvde: boolean;
    pendinvdeDes: string;
}

export class PermissionDto implements IPermissionDto {
    gesinvent: boolean;
    gesinventDes: string;
    pendinven: boolean;
    pendinvenDes: string;
    pickbobap: boolean;
    pickbobapDes: string;
    pickbobot: boolean;
    pickbobotDes: string;
    pendinvde: boolean;
    pendinvdeDes: string;

    constructor(data?: IPermissionDto) {
        if (data) {
            for (var property in data) {
                if (data.hasOwnProperty(property))
                    (<any>this)[property] = (<any>data)[property];
            }
        }
    }

    clear(): void {
        this.gesinvent = false;
        this.gesinventDes = undefined;
        this.pendinven = false;
        this.pendinvenDes = undefined;
        this.pickbobap = false;
        this.pickbobapDes = undefined;
        this.pickbobot = false;
        this.pickbobotDes = undefined;
        this.pendinvde = false;
        this.pendinvdeDes = undefined;
    }
}

export interface IDefaultResponse {
    status: boolean;
    state: number;
    message: string;
    result: any;
}

export interface IItemDto {
    name: string;
    value: string;
}

export interface IDefaultModalResponse<T> {
    success: boolean;
    data: T;
}

export function blobToText(blob: any): Observable<string> {
    return new Observable<string>((observer: any) => {
        if (!blob) {
            observer.next("");
            observer.complete();
        } else {
            let reader = new FileReader();
            reader.onload = event => {
                observer.next((<any>event.target).result);
                observer.complete();
            };
            reader.readAsText(blob);
        }
    });
}

export function processComplete(response: HttpResponseBase): Observable<void> {
    const status = response.status;
    const responseBlob =
        response instanceof HttpResponse ? response.body :
            (<any>response).error instanceof Blob ? (<any>response).error : undefined;

    let _headers: any = {}; if (response.headers) { for (let key of response.headers.keys()) { _headers[key] = response.headers.get(key); } }
    if (status === 200) {
        return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
            return _observableOf<void>(<any>null);
        }));
    } else if (status !== 200 && status !== 204) {
        return blobToText(responseBlob).pipe(_observableMergeMap(_responseText => {
            return _observableThrow(_responseText);
        }));
    }
    return _observableOf<void>(<any>null);
}