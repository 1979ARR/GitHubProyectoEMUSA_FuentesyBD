import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { AppHttpInterceptor } from '@shared/utils/http.interceptor.service';
import { EmusaServiceProxy } from './service-proxies';

@NgModule({
    providers: [
        EmusaServiceProxy,
        { provide: HTTP_INTERCEPTORS, useClass: AppHttpInterceptor, multi: true }
    ]
})
export class ServiceProxyModule { }
