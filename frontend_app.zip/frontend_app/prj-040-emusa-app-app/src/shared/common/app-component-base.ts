import { Injector } from "@angular/core";
import { Params } from '@angular/router';
import { LoadingController, MenuController, NavController, Platform } from "@ionic/angular";
import { AppAudioService } from "@shared/utils/audio.service";
import { AppClipboardService } from "@shared/utils/clipboard.service";
import { AppDialogService } from "@shared/utils/dialog.service";
import { AppKeyboardService } from "@shared/utils/keyboard.service";
import { AppMessageService } from "@shared/utils/message.service";
import { AppNotifyService } from "@shared/utils/notify.service";
import { AppSessionService } from "@shared/utils/session.service";
import { AppTokenService } from "@shared/utils/token.service";
import { AppVersionService } from "@shared/utils/version.service";

export abstract class AppModalComponent {

    platform: Platform;
    clipboard: AppClipboardService;
    keyboard: AppKeyboardService;
    message: AppMessageService;
    notify: AppNotifyService;
    session: AppSessionService;
    token: AppTokenService;
    version: AppVersionService;
    audio: AppAudioService;
    dialog: AppDialogService;

    private navigationController: NavController;
    private menuController: MenuController;
    private loadingController: LoadingController;

    constructor(_injector: Injector) {
        this.platform = _injector.get(Platform);
        this.clipboard = _injector.get(AppClipboardService);
        this.message = _injector.get(AppMessageService);
        this.notify = _injector.get(AppNotifyService);
        this.version = _injector.get(AppVersionService);
        this.navigationController = _injector.get(NavController);
        this.menuController = _injector.get(MenuController);
        this.loadingController = _injector.get(LoadingController);
        this.token = _injector.get(AppTokenService);
        this.session = _injector.get(AppSessionService);
        this.keyboard = _injector.get(AppKeyboardService);
        this.audio = _injector.get(AppAudioService);
        this.dialog = _injector.get(AppDialogService);
    }

    async showLoading(message: string) {
        let loading = await this.loadingController.create({
            message: message,
        });

        await loading.present();

        return loading;
    }

    toggleMenu() {
        this.menuController.toggle('mainMenu');
    }

    navigateForward(route: string, params?: Params) {
        this.navigationController.navigateRoot(route, {
            animated: true,
            animationDirection: 'forward',
            queryParams: params,
        });
    }

    navigateBack(route: string, params?: Params) {
        this.navigationController.navigateRoot(route, {
            animated: true,
            animationDirection: 'back',
            queryParams: params,
        });
    }

}

export abstract class AppViewComponent extends AppModalComponent {

    constructor(injector: Injector) {
        super(injector);
        this.platform.backButton.subscribeWithPriority(10, () => {
            this.onBackButtonPressed();
        });
        this.platform.backButton.subscribeWithPriority(-1, () => {
            this.onBackButtonPressed();
        });
    }

    onBackButtonPressed() {

    }

}