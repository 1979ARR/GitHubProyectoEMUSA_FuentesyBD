import { Injectable, Injector } from "@angular/core";
import { ModalController, ModalOptions } from "@ionic/angular";

@Injectable()
export class AppDialogService {

    private modalController: ModalController;

    constructor(injector: Injector) {
        this.modalController = injector.get(ModalController);
    }

    async create(options: ModalOptions): Promise<HTMLIonModalElement> {
        return await this.modalController.create(options);
    }

    async show(options: ModalOptions): Promise<void> {
        let modal = await this.modalController.create(options);
        return await modal.present();
    }

    async showWithData<T>(options: ModalOptions): Promise<PopOverResult<T>> {
        let modal = await this.modalController.create(options);
        await modal.present();
        return <PopOverResult<T>>(await modal.onWillDismiss());
    }

    async dismiss(data?: any) {
        await this.modalController.dismiss({
            result: data
        });
    }
}

export class PopOverResult<T> {
    data: ResultItem<T>;
    role: any;
}

export class ResultItem<T> {
    result: T;
}