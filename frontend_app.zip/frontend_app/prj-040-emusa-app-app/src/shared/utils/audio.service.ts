import { Injectable, Injector } from "@angular/core";
import { NativeAudio } from '@awesome-cordova-plugins/native-audio/ngx';
import { Platform } from "@ionic/angular";

@Injectable({ providedIn: 'root' })
export class AppAudioService {

    private initialized: boolean;
    private nativeAudio: NativeAudio;
    private platform: Platform;

    get isCordova() {
        return this.platform.is('cordova');
    }

    constructor(_injector: Injector) {
        this.nativeAudio = _injector.get(NativeAudio);
        this.platform = _injector.get(Platform);
    }

    initialize() {
        if (this.initialized)
            return;

        if (this.isCordova) {
            this.nativeAudio.preloadSimple('notification_success', 'assets/sounds/success.mp3').then();
            this.nativeAudio.preloadSimple('notification_warning', 'assets/sounds/warning.mp3').then();
            this.nativeAudio.preloadSimple('notification_danger', 'assets/sounds/error.mp3').then();
        }
        
        this.initialized = true;
    }

    play(type: 'danger' | 'warning' | 'success') {
        if (this.isCordova) {
            switch (type) {
                case 'success': this.nativeAudio.play('notification_success').then(); break;
                case 'warning': this.nativeAudio.play('notification_warning').then(); break;
                case 'danger': this.nativeAudio.play('notification_danger').then(); break;
            }
        }
    }
}