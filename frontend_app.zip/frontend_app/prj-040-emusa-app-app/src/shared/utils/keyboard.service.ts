import { Injectable, Injector } from '@angular/core';
import { Keyboard } from '@awesome-cordova-plugins/keyboard/ngx';

@Injectable({providedIn: 'root'})
export class AppKeyboardService {

    private keyboard: Keyboard;

    constructor(_injector: Injector) {
        this.keyboard = _injector.get(Keyboard);
    }
    
}