import { Injectable, Injector } from "@angular/core";
import { AppVersion } from "@awesome-cordova-plugins/app-version/ngx";

@Injectable({ providedIn: 'root' })
export class AppVersionService {

    private appVersion: AppVersion;

    constructor(injector: Injector) {
        this.appVersion = injector.get(AppVersion);
    }

    appName(): Promise<string> {
        return this.appVersion.getAppName();
    }

    packageName(): Promise<string> {
        return this.appVersion.getPackageName();
    }

    versionCode(): Promise<string | number> {
        return this.appVersion.getVersionCode();
    }

    versionNumber(): Promise<string> {
        return this.appVersion.getVersionNumber();
    }

}