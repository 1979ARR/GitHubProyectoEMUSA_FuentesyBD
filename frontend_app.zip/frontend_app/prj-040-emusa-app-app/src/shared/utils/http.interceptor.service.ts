import { Injectable, Injector } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpEvent, HttpResponse, HttpHeaders } from '@angular/common/http';
import { switchMap, catchError, map } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { NavController } from '@ionic/angular';
import { blobToText, IDefaultResponse } from '@shared/service-proxies/service-proxies';
import { AppSessionService } from '@shared/utils/session.service';
import { AppTokenService } from '@shared/utils/token.service';
import { AppNotifyService } from './notify.service';
import { AppAudioService } from './audio.service';

@Injectable({ providedIn: 'root' })
export class AppHttpInterceptor implements HttpInterceptor {

  private navigationController: NavController;
  private notify: AppNotifyService;
  private session: AppSessionService;
  private token: AppTokenService;
  private audio: AppAudioService;
  
  constructor(_injector: Injector) {
    this.navigationController = _injector.get(NavController);
    this.notify = _injector.get(AppNotifyService);
    this.session = _injector.get(AppSessionService);
    this.token = _injector.get(AppTokenService);
    this.audio = _injector.get(AppAudioService);
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(this.normalizeRequestHeaders(request)).pipe(catchError(error => {
      return this.handleErrorResponse(error);
    }), switchMap((event) => {
      return this.handleSuccessResponse(event);
    }));
  }

  private normalizeRequestHeaders(request: HttpRequest<any>): HttpRequest<any> {
    let modifiedHeaders: HttpHeaders = new HttpHeaders();
    let sessionToken: string = this.token.getToken();

    if (sessionToken && !this.itemExists(request.headers.getAll('Authorization'), (item: string) => item.indexOf('Bearer ') == 0)) 
      modifiedHeaders = modifiedHeaders.set('Authorization', 'Bearer ' + sessionToken);
    if (request.headers.get('Content-Type') !== undefined)
      modifiedHeaders = modifiedHeaders.set('Content-Type', request.headers.get('Content-Type'));

    return request.clone({
      headers: modifiedHeaders
    });
  }

  private handleSuccessResponse(event: any): Observable<HttpEvent<any>> {

    if (event instanceof HttpResponse) {
      if (event.body instanceof Blob && event.body.type && event.body.type.indexOf("application/json") >= 0) {
        return blobToText(event.body).pipe(map(json => {
          const responseBody = json == "null" ? {} : JSON.parse(json);

          let modifiedResponse = this.handleResponse(event.clone({
            body: responseBody
          }));

          return modifiedResponse.clone({
            body: new Blob([JSON.stringify(modifiedResponse.body)], { type: 'application/json' })
          });
        })
        );
      }
    }

    return of(event);
  }

  private handleResponse(response: HttpResponse<any>): HttpResponse<any> {
    let ajaxResponse = this.getDefaultResponseOrNull(response);
    if (ajaxResponse == null) {
      return response;
    }

    return this.handleDefaultResponse(response, ajaxResponse);
  }

  private getDefaultResponseOrNull(response: HttpResponse<any>): IDefaultResponse | null {
    if (!response || !response.headers) {
      return null;
    }

    let contentType = response.headers.get('Content-Type');
    if (!contentType) {
      console.log('Content-Type is not sent!');
      return null;
    }

    if (contentType.indexOf("application/json") < 0) {
      console.log('Content-Type is not application/json: ' + contentType);
      return null;
    }

    let responseObj = JSON.parse(JSON.stringify(response.body));

    return responseObj as IDefaultResponse;
  }

  private handleDefaultResponse(response: HttpResponse<any>, ajaxResponse: IDefaultResponse): HttpResponse<any> {
    let newResponse: HttpResponse<any>;
    if (ajaxResponse.status) {

      newResponse = response.clone({
        body: ajaxResponse
      });

    } else {

      newResponse = response.clone({
        body: ajaxResponse
      });

      this.handleErrorMessage(response);

      //show error
      if (response.status === 401 && !(location.href.indexOf('login') == -1)) {
        this.session.logout();
        this.navigationController.navigateRoot('/account/login', {
          animated: true,
          animationDirection: 'forward',
          queryParams: {},
        });
      }

      throw new Error(response.body?.message ? response.body.message : 'Ha ocurrido un error inesperado');
    }

    return newResponse;
  }

  private handleErrorMessage(response: HttpResponse<any>) {
    let errorMessage: string = 'Ha ocurrido un error inesperado';

    if (response?.body?.message)
      errorMessage = response.body.message;

    this.notify.error(errorMessage, 3000, 'top');
    this.audio.play('danger');
  }

  private handleErrorResponse(error: any): Observable<never> {
    if (!(error.error instanceof Blob)) {
      return throwError(error);
    }

    return blobToText(error.error).pipe(switchMap((json) => {
      const errorBody = (json == "" || json == "null") ? {} : JSON.parse(json);
      const errorResponse = new HttpResponse({
        headers: error.headers,
        status: error.status,
        body: errorBody
      });

      let ajaxResponse = this.getDefaultResponseOrNull(errorResponse);

      if (ajaxResponse != null) {
        this.handleDefaultResponse(errorResponse, ajaxResponse);
      } else {
        this.notify.error('Ha ocurrido un error inesperado', 3000, 'top');
        this.audio.play('danger');
      }

      return throwError(error);
    }));
  }

  private itemExists<T>(items: T[], predicate: (item: T) => boolean): boolean {
    if (!items)
      return false;

    for (let i = 0; i < items.length; i++) {
      if (predicate(items[i])) {
        return true;
      }
    }

    return false;
  }
}

