import { Injectable, Injector } from '@angular/core';
import { AlertController } from '@ionic/angular';

@Injectable({ providedIn: 'root' })
export class AppMessageService {

  private alertController: AlertController;

  constructor(injector: Injector) {
    this.alertController = injector.get(AlertController);
  }

  async confirm(message: string, title: string, callback: (result: boolean) => void, confirmText?: string, cancelText?: string) {

    const alert = await this.alertController.create({
      header: title,
      message: message,
      cssClass: 'app-confirm-dialog',
      backdropDismiss: false,
      animated: true,
      buttons: [
        {
          text: cancelText || 'Cancelar',
          role: 'cancel',
          cssClass: 'cancel-button',
          handler: () => callback(false)
        },
        {
          text: confirmText || 'Aceptar',
          cssClass: 'confirm-button',
          handler: () => callback(true)
        }
      ]
    });

    await alert.present();
  }

  async info(message: string, title: string, confirmText?: string, callback?: () => void) {
    const alert = await this.alertController.create({
      header: title,
      message: message,
      backdropDismiss: false,
      buttons: [
        {
          text: confirmText || 'Aceptar',
          handler: () => callback && callback()
        }
      ]
    });

    await alert.present();
  }

  async error(message: string, title?: string, callback?: () => void) {
    const alert = await this.alertController.create({
      header: title || 'Aviso',
      message: message,
      backdropDismiss: false,
      buttons: [
        {
          text: 'Aceptar',
          handler: () => callback && callback()
        }
      ]
    });

    await alert.present();
  }
}
