import { Injectable, Injector } from "@angular/core";
import { Platform } from "@ionic/angular";
import { Subject } from "rxjs";
import { Clipboard } from '@awesome-cordova-plugins/clipboard/ngx';

@Injectable({ providedIn: 'root' })
export class AppClipboardService {

    private initialized: boolean;
    private platform: Platform;
    private clipboard: Clipboard;

    paste: Subject<string> = new Subject<string>();
    enter: Subject<void> = new Subject<void>();

    constructor(_injector: Injector) {
        this.initialized = false;
        this.platform = _injector.get(Platform);
        this.clipboard = _injector.get(Clipboard);
    }

    init(): void {
        if (this.initialized)
            return;
            
        document.addEventListener('keydown', (event: any) => {
            if (event.key == 'Enter')
                this.enter.next();
        });

        window.addEventListener('paste', (event) => {
            this.initialized = true;
            if (this.platform.is('cordova')) {
                this.clipboard.paste().then((text) => {
                    this.paste.next(text);
                });
            } else {
                navigator.clipboard.readText().then((text) => {
                    this.paste.next(text);
                });
            }
        });
    }
}