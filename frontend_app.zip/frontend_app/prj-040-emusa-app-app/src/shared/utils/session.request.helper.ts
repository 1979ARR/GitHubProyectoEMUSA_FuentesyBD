import { AppConsts } from "@shared/AppConsts";
import { IItemDto, SessionReponse } from "@shared/service-proxies/service-proxies";

export class SessionHttpRequestHelper {

    static ajax(customHeaders: IItemDto[], success: (result: SessionReponse) => void, error: () => void) {
        let xhr = new XMLHttpRequest();

        xhr.onreadystatechange = () => {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200 || xhr.status === 401) {
                    let response = xhr.responseText == '' ? undefined : JSON.parse(xhr.responseText == '' ? undefined : xhr.responseText);
                    let result = response?.status && response?.result ? SessionReponse.fromJS(response.result) : undefined;
                    success(result);
                } else if (xhr.status !== 0) {
                    error();
                }
            }
        };

        xhr.open('post', `${AppConsts.remoteServiceBaseUrl}/api/Authentication/validarsesion`, true);

        for (let property of customHeaders)
            xhr.setRequestHeader(property.name, property.value);

        xhr.send();
    }
}
