import { Injectable, Injector } from "@angular/core";
import { ToastController } from "@ionic/angular";

@Injectable({ providedIn: 'root' })
export class AppNotifyService {

    private toastController: ToastController;

    constructor(injector: Injector) {
        this.toastController = injector.get(ToastController);
    }

    async info(message: string, duration: number, position?: 'top' | 'bottom' | 'middle') {
        const toast = await this.toastController.create({
            message: message,
            duration: duration,
            position: position || 'bottom',
            icon: 'checkmark-circle',
            color: 'primary'
        });

        return await toast.present();
    }

    async success(message: string, duration: number, position?: 'top' | 'bottom' | 'middle') {
        const toast = await this.toastController.create({
            message: message,
            duration: duration,
            position: position || 'bottom',
            icon: 'checkmark-circle',
            color: 'success'
        });

        return await toast.present();
    }

    async warn(message: string, duration: number, position?: 'top' | 'bottom' | 'middle') {
        const toast = await this.toastController.create({
            message: message,
            duration: duration,
            position: position || 'bottom',
            icon: 'alert-circle',
            color: 'warning'
        });

        return await toast.present();
    }

    async error(message: string, duration: number, position?: 'top' | 'bottom' | 'middle') {

        const toast = await this.toastController.create({
            message: message,
            duration: duration,
            position: position || 'bottom',
            color: 'danger'
        });

        return await toast.present();
    }
}
