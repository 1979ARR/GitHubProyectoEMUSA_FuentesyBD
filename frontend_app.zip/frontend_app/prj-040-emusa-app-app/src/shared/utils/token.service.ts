import { Injectable } from '@angular/core';
import { IItemDto, WarehouseDto } from '@shared/service-proxies/service-proxies';

@Injectable({ providedIn: 'root' })
export class AppTokenService {

    constructor() { }

    setToken(token: string): void {
        localStorage.setItem('App.Auth.Token', token);
    }

    removeToken(): void {
        localStorage.removeItem('App.Auth.Token');
    }

    getToken(): string {
        return localStorage.getItem('App.Auth.Token');
    }

    setWarehouse(warehouse: WarehouseDto): void {
        localStorage.setItem('App.Auth.Warehouse', JSON.stringify(warehouse));
    }

    removeWarehouse(): void {
        localStorage.removeItem('App.Auth.Warehouse');
    }

    getWarehouse(): WarehouseDto {
        const warehouse: string = localStorage.getItem('App.Auth.Warehouse');

        if (!warehouse || warehouse == '')
            return undefined;

        return WarehouseDto.fromJS(JSON.parse(localStorage.getItem('App.Auth.Warehouse')));
    }

    setProduct(product: string): void {
        localStorage.setItem('App.Auth.Product', product);
    }

    removeProduct(): void {
        localStorage.removeItem('App.Auth.Product');
    }

    getProduct(): 'M' | 'P' | 'T' {
        const product: string = localStorage.getItem('App.Auth.Product');
        return product == 'M' ? 'M' : product == 'P' ? 'P' : product == 'T' ? 'T' : undefined;
    }

    getDefaultAuthorizationHeader(): IItemDto[] {
        const token: string = this.getToken();
        return token ? [{ name: 'Authorization', value: `Bearer ${token}` }] : [];
    }
}