import { Injectable, Injector } from '@angular/core';
import { LoginResponse, OptionDto, PermissionDto as PermissionsDto, ProfileDto, SessionReponse, UserDto as UserDto, WarehouseDto } from '@shared/service-proxies/service-proxies';
import { AppTokenService } from './token.service';

@Injectable({ providedIn: 'root' })
export class AppSessionService {

    private _user: UserDto;
    private _profiles: ProfileDto[];;
    private _options: OptionDto[];
    private _token: AppTokenService;
    private _warehouse: WarehouseDto;
    private _permissions: PermissionsDto;
    private _product: 'M' | 'P' | 'T';

    constructor(_injector: Injector) {
        this._token = _injector.get(AppTokenService);
    }

    get user(): UserDto {
        return this._user;
    }

    get userId(): number {
        return this._user?.codUser;
    }

    get profiles(): ProfileDto[] {
        return this._profiles;
    }

    get options(): OptionDto[] {
        return this._options;
    }

    get warehouse(): WarehouseDto {
        return this._warehouse;
    }

    get product(): 'M' | 'P' | 'T' {
        return this._product;
    }

    get permissions(): PermissionsDto {
        return this._permissions;
    }

    //GESINVENT     Pendientes por Ubicar
    //PENDINVEN	Pendientes por Inventariar
    //PICKBOBAP	Picking OT por Bobina - Apilador
    //PICKBOBOT	Picking OT por Bobina - Op Traslado
    //PENDINVDE	Pendientes por Despacho
    init(session: SessionReponse) {
        this._user = session?.usuario;
        this._profiles = session?.perfil;
        this._options = session?.opciones;
        this._permissions = new PermissionsDto();
        this.initOptions();
    }

    login(login: LoginResponse) {
        this._user = login.usuario;
        this._profiles = login.perfil;
        this._options = login.opciones;
        this._token.setToken(login.token);
        this.initOptions();
    }

    logout(): void {
        this._token.removeToken();
        this._token.removeWarehouse();
        this._token.removeProduct();
        this._user = undefined;
        this._profiles = undefined;
        this._options = undefined;
        this._warehouse = undefined;
        this._product = undefined;
        this.permissions.clear();
    }

    setWarehouse(warehouse: WarehouseDto) {
        this._warehouse = warehouse;
    }

    setProduct(product: 'M' | 'P' | 'T'): void {
        this._product = product;
    }

    removeWarehouse(): void {
        this._warehouse = undefined;
    }

    removeProduct(): void {
        this._product = undefined;
    }

    private initOptions(): void {
        this.permissions.clear();
        
        if (!this.options)
            return;

        for (var permission of this._options) {
            switch (permission.codOpcion) {
                case 'GESINVENT': {
                    this.permissions.gesinvent = true;
                    this.permissions.gesinventDes = permission.descOpcion;
                    break;
                };
                case 'PENDINVEN': {
                    this.permissions.pendinven = true;
                    this.permissions.pendinvenDes = permission.descOpcion;
                    break;
                };
                case 'PICKBOBAP': {
                    this.permissions.pickbobap = true;
                    this.permissions.pickbobapDes = permission.descOpcion;
                    break;
                };
                case 'PICKBOBOT': {
                    this.permissions.pickbobot = true;
                    this.permissions.pickbobotDes = permission.descOpcion;
                    break;
                };
                case 'PENDINVDE': {
                    this.permissions.pendinvde = true;
                    this.permissions.pendinvdeDes = permission.descOpcion;
                    break;
                };
            }
        }
    }
}