export class AppConsts {

    static remoteServiceBaseUrl: string;
    static appBaseHref: string;
    static appBaseUrl: string;
}
