import { ModuleWithProviders, NgModule } from '@angular/core';
import { AppClipboardService } from '@shared/utils/clipboard.service';
import { AppMessageService } from '@shared/utils/message.service';
import { AppNotifyService } from '@shared/utils/notify.service';
import { InputTextModule } from 'primeng/inputtext';
import { AppLogoComponent } from '@shared/component/app-logo/app-logo.component';
import { AppVersionComponent } from '@shared/component/app-version/app-version.component';
import { IonicModule } from '@ionic/angular';
import { AppVersionService } from '@shared/utils/version.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppSessionService } from '@shared/utils/session.service';
import { AppHttpInterceptor } from '@shared/utils/http.interceptor.service';
import { AppTokenService } from '@shared/utils/token.service';
import { AppAudioService } from './utils/audio.service';
import { AppDialogService as AppDialogService } from './utils/dialog.service';

@NgModule({
    imports: [
        IonicModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        InputTextModule
    ],
    declarations: [
        AppLogoComponent,
        AppVersionComponent
    ],
    exports: [
        InputTextModule,
        AppLogoComponent,
        AppVersionComponent
    ],
    providers: []
})
export class AppSharedModule {
    static forRoot(): ModuleWithProviders<AppSharedModule> {
        return {
            ngModule: AppSharedModule,
            providers: [
                AppClipboardService,
                AppMessageService,
                AppNotifyService,
                AppVersionService,
                AppHttpInterceptor,
                AppSessionService,
                AppTokenService,
                AppAudioService,
                AppDialogService
            ]
        };
    }
}
