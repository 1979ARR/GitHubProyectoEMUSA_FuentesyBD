import { Injectable, Injector } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, RouterStateSnapshot } from '@angular/router';
import { WarehouseComponent } from '@customer/warehouse/warehouse.component';
import { NavController } from '@ionic/angular';
import { AppSessionService } from '@shared/utils/session.service';

@Injectable({ providedIn: 'root' })
export class CustomerGuard implements CanActivate, CanActivateChild {

    private session: AppSessionService;
    private navigationController: NavController;

    constructor(_injector: Injector) {
        this.session = _injector.get(AppSessionService);
        this.navigationController = _injector.get(NavController);
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        return this.canVerification(route, state);
    }

    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        return this.canVerification(route, state);
    }

    private canVerification(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (route.component === WarehouseComponent && this.session.warehouse && this.session.product) {
            this.navigationController.navigateRoot('/customer/dashboard', {
                animated: true,
                animationDirection: 'back',
                queryParams: {},
            });
            return false;
        }

        if (!this.session.user) {
            this.navigationController.navigateRoot('/account/login', {
                animated: true,
                animationDirection: 'back',
                queryParams: {},
            });
            return false;
        }
        return true;
    }
}