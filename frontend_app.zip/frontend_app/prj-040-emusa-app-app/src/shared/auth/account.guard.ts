import { Injectable, Injector } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, RouterStateSnapshot } from '@angular/router';
import { NavController } from '@ionic/angular';
import { AppSessionService } from '@shared/utils/session.service';

@Injectable({ providedIn: 'root' })
export class AccountGuard implements CanActivate, CanActivateChild {

    private session: AppSessionService;
    private navigationController: NavController;

    constructor(_injector: Injector) {
        this.session = _injector.get(AppSessionService);
        this.navigationController = _injector.get(NavController);
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        return this.canVerification();
    }

    canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        return this.canVerification();
    }

    private canVerification() {
        if (this.session.user) {
            this.navigationController.navigateRoot('/customer/warehouse', {
                animated: true,
                animationDirection: 'forward',
                queryParams: {},
            });
            return false;
        }
        return true;
    }
}