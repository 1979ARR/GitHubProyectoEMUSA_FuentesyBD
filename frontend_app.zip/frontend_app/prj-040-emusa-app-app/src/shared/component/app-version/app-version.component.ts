import { AfterViewInit, Component, Injector } from '@angular/core';
import { AppModalComponent } from '@shared/common/app-component-base';
import { environment } from 'src/environments/environment';

@Component({
    selector: 'app-version',
    templateUrl: 'app-version.component.html',
    styleUrls: [
        'app-version.component.scss'
    ]
})
export class AppVersionComponent extends AppModalComponent implements AfterViewInit {

    versionCode: string = '';
    locationCode: string = environment.location;
    loaded: boolean = false;

    constructor(_injector: Injector) {
        super(_injector);
    }

    ngAfterViewInit(): void {
        this.platform.ready().then(() => {
            this.version.versionNumber().then((reponse) => {
                this.loaded = true;
                this.versionCode = reponse;
            });
        });
    }
}