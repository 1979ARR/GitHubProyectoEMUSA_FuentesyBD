import { Component, Injector, OnInit } from '@angular/core';
import { AppModalComponent } from 'src/shared/common/app-component-base';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: [
    'app.component.scss'
  ]
})
export class AppComponent extends AppModalComponent implements OnInit {

  constructor(_injector: Injector) {
    super(_injector);
  }

  ngOnInit(): void {
    this.platform.ready().then(() => {
      this.clipboard.init();
      this.audio.initialize();
    });
  }
}
