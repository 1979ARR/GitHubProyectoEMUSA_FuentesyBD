import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from '@customer/dashboard/dashboard.component';
import { CustomerComponent } from '@customer/customer.component';
import { WarehouseComponent } from '@customer/warehouse/warehouse.component';
import { OperationComponent } from '@customer/operation/operation.component';
import { CustomerGuard } from '@shared/auth/customer.guard';
import { InventoryComponent } from './inventory/inventory.component';
import { POTStockComponent } from './pot-stock/pot-stock.component';
import { POTApplyComponent } from './pot-apply/pot-apply.component';
import { PendingDispatchComponent } from './pending-dispatch/pending-dispatch.component';

const routes: Routes = [
    {
        path: '',
        component: CustomerComponent,
        canActivate: [CustomerGuard],
        canActivateChild: [CustomerGuard],
        children: [
            { path: 'dashboard', component: DashboardComponent },
            { path: 'warehouse', component: WarehouseComponent },
            { path: 'operation', component: OperationComponent },
            { path: 'inventory', component: InventoryComponent },
            { path: 'pot-stock', component: POTStockComponent },
            { path: 'pot-apply', component: POTApplyComponent },
            { path: 'pending-dispatch', component: PendingDispatchComponent },
            { path: '', pathMatch: 'full', redirectTo: '/customer/warehouse' },
            { path: '**', redirectTo: '/customer/warehouse' }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CustomerRoutingModule { }
