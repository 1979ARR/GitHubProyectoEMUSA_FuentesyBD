import { Component, Injector } from '@angular/core';
import { AppModalComponent } from '@shared/common/app-component-base';

@Component({
    templateUrl: 'customer.component.html',
    styleUrls: [
        'customer.component.scss'
    ]
})
export class CustomerComponent extends AppModalComponent {

    constructor(_injector: Injector) {
        super(_injector);
    }

    changeWarehouse() {
        this.message.confirm('¿Esta seguro de cambiar de almacen', 'Aviso', (confirmation) => {
            if (confirmation) {
                this.toggleMenu();
                this.token.removeWarehouse();
                this.token.removeProduct();
                this.session.removeWarehouse();
                this.session.removeProduct();
                this.navigateBack('/customer/warehouse');
            }
        }, 'Cambiar', 'Cancelar');
    }

    logout() {
        this.message.confirm('¿Estas seguro de cerrar sesión?', 'Aviso', (confirmation) => {
            if (confirmation) {
                this.session.logout();
                this.navigateForward('/account/login');
            }
        }, 'Cerrar sesión', 'Cancelar');
    }
}