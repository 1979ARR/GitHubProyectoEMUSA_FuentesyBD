import { Component, EventEmitter, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { IonInput, IonToggle, ViewDidEnter } from '@ionic/angular';
import { AppViewComponent } from '@shared/common/app-component-base';
import { EmusaServiceProxy, ProductDto } from '@shared/service-proxies/service-proxies';
import { Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';

@Component({
    templateUrl: 'pot-apply.component.html',
    styleUrls: [
        'pot-apply.component.scss'
    ]
})
export class POTApplyComponent extends AppViewComponent implements OnInit, OnDestroy, ViewDidEnter {

    @ViewChild('ubication', { static: false }) ubication: IonInput;
    @ViewChild('product', { static: false }) product: IonInput;
    @ViewChild('ubicationToggle', { static: false }) ubicationToggle: IonToggle;

    private _fixUbication: boolean = false;

    get fixUbication(): boolean {
        return this._fixUbication;
    }

    set fixUbication(value: boolean) {

        if (value && !this.ubicationText) {
            this.notify.warn('Para fijar la ubicación debe existir un código en el campo de texto', 3000);
            setTimeout(async () => {
                this._fixUbication = false;
                this.fixUbicationChange.emit(false);
                this.ubicationToggle.checked = false;
                this.ubicationToggle.disabled = false;
                this.audio.play('warning');
            }, 500);
        } else {
            this._fixUbication = value;
            this.fixUbicationChange.emit(value);
        }
    }

    ubicationText: string;
    productText: string;
    busy: boolean = false;

    loading: boolean = true;
    pendingCount: number = 0;
    pending: ProductDto[] = [];

    fixUbicationChange: EventEmitter<boolean> = new EventEmitter<boolean>();
    private pendingRequestSubscription: Subscription;
    private enterSubscription: Subscription;

    constructor(_injector: Injector, private _emusaServiceProxy: EmusaServiceProxy) {
        super(_injector);
    }

    ngOnInit(): void {
        this.enterSubscription = this.clipboard.enter.subscribe(() => {
            setTimeout(async () => {
                if (this.productText && this.ubicationText)
                    this.search();
                else {
                    if (!this.ubicationText) {
                        setTimeout(async () => this.ubication.setFocus(), 250);
                    } else {
                        if (!this.productText) {
                            setTimeout(async () => this.product.setFocus(), 250);
                        }
                    }
                }
            }, 100);
        });
    }

    ngOnDestroy(): void {
        this.enterSubscription?.unsubscribe();
    }

    ionViewDidEnter(): void {
        this.refreshPending();
        setTimeout(async () => this.ubication.setFocus(), 250);
    }

    onProductBlur(event: any) {
        this.clipboard.enter.next();
    }

    resetProductText() {
        this.productText = '';
    }

    resetUbicationText() {
        this.ubicationText = '';
    }

    search() {
        this._emusaServiceProxy
            .updatePickingOtApiladorLocation(
                this.productText,
                this.ubicationText,
                this.session.warehouse.codAlmacen,
                this.session.product
            ).pipe(finalize(() => this.busy = false))
            .subscribe((result) => {

                if (this.fixUbication) {
                    setTimeout(async () => this.product.setFocus(), 250);
                    this.productText = '';
                } else {
                    this.ubicationText = '';
                    this.productText = '';
                    setTimeout(async () => this.ubication.setFocus(), 250);
                }

                this.notify.success(result.message, 3000, 'top');
                this.audio.play('success');
                this.refreshPending();
            });
    }

    refreshPending() {
        this.pending = [];
        this.loading = true;
        this.pendingRequestSubscription?.unsubscribe();
        this.pendingRequestSubscription = this._emusaServiceProxy
            .getPickingOtApiladorPending(this.session.warehouse.codAlmacen, this.session.product)
            .pipe(finalize(() => this.loading = false))
            .subscribe(response => {
                this.pendingCount = response.totalRegistros;
                this.pending = response.pendientesPickingOT;
            });
    }

    onBackButtonPressed(): void {
        this.message.confirm('¿Esta seguro de ir a inicio?', 'Aviso', (confirmation) => {
            if (confirmation) {
                this.toggleMenu();
                this.navigateForward('/customer/home');
            }
        }, 'Si', 'Cancelar');
    }
}