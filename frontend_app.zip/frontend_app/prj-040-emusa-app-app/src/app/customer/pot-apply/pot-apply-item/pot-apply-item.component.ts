import { Component, Input } from '@angular/core';
import { ProductDto } from '@shared/service-proxies/service-proxies';

@Component({
    selector: 'pot-apply-item',
    templateUrl: 'pot-apply-item.component.html',
    styleUrls: [
        'pot-apply-item.component.scss'
    ]
})
export class PotApplyItemComponent {

    @Input() product: ProductDto;
}