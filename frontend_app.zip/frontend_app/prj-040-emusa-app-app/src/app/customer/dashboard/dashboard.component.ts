import { Component, Injector, OnInit } from '@angular/core';
import { AppViewComponent } from '@shared/common/app-component-base';

@Component({
    templateUrl: 'dashboard.component.html',
    styleUrls: [
        'dashboard.component.scss'
    ]
})
export class DashboardComponent extends AppViewComponent {

    constructor(_injector: Injector) {
        super(_injector);
    }

    onBackButtonPressed(): void {
        this.toggleMenu();
    }
}