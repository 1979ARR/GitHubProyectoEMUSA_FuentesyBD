import { Component, Injector, OnInit } from '@angular/core';
import { AppViewComponent } from '@shared/common/app-component-base';
import { EmusaServiceProxy, WarehouseDto } from '@shared/service-proxies/service-proxies';
import { finalize } from 'rxjs/operators';

@Component({
    templateUrl: 'warehouse.component.html',
    styleUrls: [
        'warehouse.component.scss'
    ]
})
export class WarehouseComponent extends AppViewComponent implements OnInit {

    warehouses: WarehouseDto[] = [];
    warehouse: WarehouseDto = undefined;
    product: 'M' | 'P' | 'T' = 'M';

    private busy: boolean = true;

    constructor(_injector: Injector, private _emusaServiceProxy: EmusaServiceProxy) {
        super(_injector);
    }

    ngOnInit(): void {
        this.showLoading('Cargando información, por favor espere...')
            .then(loading => {
                this._emusaServiceProxy
                    .getWarehouses()
                    .pipe(finalize(async () => await loading.dismiss()))
                    .subscribe(response => {
                        this.busy = false;
                        this.warehouses = response;
                    }, () => this.busy = false);
            });

    }

    warehouseChange(event: any) {
        const warehouseCode: string = event.detail.value;
        const warehouseIndex: number = this.warehouses.findIndex(p => p.codAlmacen == warehouseCode);

        if (warehouseIndex == -1) {
            this.warehouse = undefined;
        } else {
            this.warehouse = this.warehouses[warehouseIndex];
        }
    }

    dashboard() {
        if (!this.warehouse) {
            this.message.info('Debe seleccionar el almacén', 'Aviso');
            return;
        }

        this.token.setWarehouse(this.warehouse);
        this.session.setWarehouse(this.warehouse);
        this.token.setProduct(this.product);
        this.session.setProduct(this.product);

        this.navigateForward('/customer/dashboard');
    }

    onBackButtonPressed(): void {
        if (this.busy)
            return;
        this.message.confirm('¿Estas seguro de cerrar sesión?', 'Aviso', (confirmation) => {
            if (confirmation) {
                this.session.logout();
                this.navigateForward('/account/login');
            }
        }, 'Cerrar sesión', 'Cancelar');
    }
}