import { Component, Input } from '@angular/core';
import { ProductDto } from '@shared/service-proxies/service-proxies';

@Component({
    selector: 'pot-stock-item',
    templateUrl: 'pot-stock-item.component.html',
    styleUrls: [
        'pot-stock-item.component.scss'
    ]
})
export class PotStockItemComponent {

    @Input() product: ProductDto;
}