import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from '@customer/dashboard/dashboard.component';
import { CustomerRoutingModule } from '@customer/customer-routing.module';
import { AppSharedModule } from '@shared/shared.module';
import { CustomerComponent } from '@customer/customer.component';
import { WarehouseComponent } from '@customer/warehouse/warehouse.component';
import { OperationComponent } from '@customer/operation/operation.component';
import { OperationItemComponent } from '@customer/operation/operation-item/operation-item.component';
import { CustomerGuard } from '@shared/auth/customer.guard';
import { InventoryComponent } from './inventory/inventory.component';
import { POTStockComponent } from './pot-stock/pot-stock.component';
import { POTApplyComponent } from './pot-apply/pot-apply.component';
import { PotStockItemComponent } from './pot-stock/pot-stock-item/pot-stock-item.component';
import { PotApplyItemComponent } from './pot-apply/pot-apply-item/pot-apply-item.component';
import { PendingDispatchComponent } from './pending-dispatch/pending-dispatch.component';
import { DispatchContentComponent } from './pending-dispatch/dispatch-content/dispatch-content.component';
import { DispatchItemComponent } from './pending-dispatch/dispatch-item/dispatch-item.component';
import { OperationContentComponent } from './operation/operation-content/operation-content.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    AppSharedModule,
    CustomerRoutingModule
  ],
  declarations: [
    CustomerComponent,
    WarehouseComponent,
    DashboardComponent,
    OperationComponent,
    OperationItemComponent,
    OperationContentComponent,
    InventoryComponent,
    POTStockComponent,
    PotStockItemComponent,
    POTApplyComponent,
    PotApplyItemComponent,
    PendingDispatchComponent,
    DispatchContentComponent,
    DispatchItemComponent
  ],
  providers: [
    CustomerGuard
  ]
})
export class CustomerModule { }
