import { Component, Injector, Input, OnDestroy, OnInit } from '@angular/core';
import { AppModalComponent } from '@shared/common/app-component-base';
import { EmusaServiceProxy, IDefaultModalResponse, ProductDto } from '@shared/service-proxies/service-proxies';
import { Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';

@Component({
    selector: 'operation-content',
    templateUrl: 'operation-content.component.html',
    styleUrls: [
        'operation-content.component.scss'
    ]
})
export class OperationContentComponent extends AppModalComponent implements OnInit, OnDestroy {

    @Input() secuencial: string;
    @Input() ubication: string;

    saving: boolean = false;
    loading: boolean = true;
    pendingCount: number = 0;
    pendingText: string;
    pending: ProductDto[] = [];

    private pendingRequestSubscription: Subscription;

    constructor(_injector: Injector, private _emusaServiceProxy: EmusaServiceProxy) {
        super(_injector);
    }

    ngOnDestroy(): void {
        this.pendingRequestSubscription?.unsubscribe();
    }

    ngOnInit() {
        this.loading = true;
        this.pendingRequestSubscription = this._emusaServiceProxy
            .getOperationDispatchPending(this.session.warehouse.codAlmacen, this.session.product, this.secuencial)
            .pipe(finalize(() => this.loading = false))
            .subscribe(response => {
                this.pendingCount = response.totalRegistros;
                this.pending = response.pendientesPickingOT;

                if (this.pending.length > 0)
                    this.pendingText = this.pending[0].codItem;
            }, () => this.dialog.dismiss());
    }

    confirmUbication() {
        this.message.confirm('¿Esta seguro de confirmar el inventario?', 'Aviso', (confirmation) => {
            if (confirmation) {
                this.saving = true;
                this._emusaServiceProxy
                    .updateOperationDispatchLocation(
                        this.secuencial,
                        this.ubication,
                        this.session.warehouse.codAlmacen,
                        this.session.product
                    ).pipe(finalize(() => this.saving = false))
                    .subscribe((result) => {
                        this.notify.success(result.message, 3000, 'top');
                        this.audio.play('success');
                        this.dialog.dismiss(<IDefaultModalResponse<number>>{ success: true, data: this.pendingCount });
                    });
            }
        });
    }
}