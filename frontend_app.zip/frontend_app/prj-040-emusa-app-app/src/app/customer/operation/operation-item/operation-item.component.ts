import { Component, Input, OnInit } from '@angular/core';
import { ProductDto } from '@shared/service-proxies/service-proxies';

@Component({
    selector: 'operation-item',
    templateUrl: 'operation-item.component.html',
    styleUrls: [
        'operation-item.component.scss'
    ]
})
export class OperationItemComponent {

    @Input() product: ProductDto;
}