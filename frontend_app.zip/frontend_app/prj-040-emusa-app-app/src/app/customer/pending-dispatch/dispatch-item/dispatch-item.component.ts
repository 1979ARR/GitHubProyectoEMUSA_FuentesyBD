import { Component, Input, OnInit } from '@angular/core';
import { ProductDto } from '@shared/service-proxies/service-proxies';

@Component({
    selector: 'dispatch-item',
    templateUrl: 'dispatch-item.component.html',
    styleUrls: [
        'dispatch-item.component.scss'
    ]
})
export class DispatchItemComponent {

    @Input() product: ProductDto;
}