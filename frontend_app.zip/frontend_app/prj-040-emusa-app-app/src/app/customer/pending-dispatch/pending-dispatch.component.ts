import { Component, EventEmitter, Injector, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { IonInput, IonToggle, ViewDidEnter } from '@ionic/angular';
import { AppViewComponent } from '@shared/common/app-component-base';
import { EmusaServiceProxy, IDefaultModalResponse } from '@shared/service-proxies/service-proxies';
import { Subscription } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { DispatchContentComponent } from './dispatch-content/dispatch-content.component';

@Component({
    templateUrl: 'pending-dispatch.component.html',
    styleUrls: [
        'pending-dispatch.component.scss'
    ]
})
export class PendingDispatchComponent extends AppViewComponent implements OnInit, OnDestroy, ViewDidEnter {

    @ViewChild('ubication', { static: false }) ubication: IonInput;
    @ViewChild('product', { static: false }) product: IonInput;
    @ViewChild('ubicationToggle', { static: false }) ubicationToggle: IonToggle;

    private _fixUbication: boolean = false;

    get fixUbication(): boolean {
        return this._fixUbication;
    }

    set fixUbication(value: boolean) {
        this.historyubication = '';
        this.historyCount = 0;
        
        if (value && !this.ubicationText) {
            this.notify.warn('Para fijar la ubicación debe existir un código en el campo de texto', 3000);
            setTimeout(async () => {
                this._fixUbication = false;
                this.fixUbicationChange.emit(false);
                this.ubicationToggle.checked = false;
                this.ubicationToggle.disabled = false;
                this.audio.play('warning');
            }, 500);
        } else {
            this._fixUbication = value;
            this.fixUbicationChange.emit(value);
        }
    }

    ubicationText: string;
    productText: string;
    busy: boolean = false;

    loading: boolean = true;
    inventoryCount: number = 0;
    pendingInventoryCount: number = 0;

    modes = {
        operation: 0,
        secuencial: 1
    }

    mode: number = this.modes.operation;
    isOperation: boolean = true;
    isSecuencial: boolean = false;

    historyubication: string = '';
    historyCount: number = 0;

    fixUbicationChange: EventEmitter<boolean> = new EventEmitter<boolean>();
    private pendingRequestSubscription: Subscription;
    private enterSubscription: Subscription;

    constructor(_injector: Injector, private _emusaServiceProxy: EmusaServiceProxy) {
        super(_injector);
    }

    ngOnInit(): void {
        this.enterSubscription = this.clipboard.enter.subscribe(() => {
            setTimeout(async () => {
                if (this.productText && this.ubicationText)
                    this.search();
                else {
                    if (!this.ubicationText) {
                        setTimeout(async () => this.ubication.setFocus(), 250);
                    } else {
                        if (!this.productText) {
                            setTimeout(async () => this.product.setFocus(), 250);
                        }
                    }
                }
            }, 100);
        });
    }

    ngOnDestroy(): void {
        this.enterSubscription?.unsubscribe();
    }

    ionViewDidEnter(): void {
        this.refreshPending();
        setTimeout(async () => this.ubication.setFocus(), 250);
    }

    onProductBlur(event: any) {
        this.clipboard.enter.next();
    }

    resetProductText() {
        this.productText = '';
    }

    resetUbicationText() {
        this.ubicationText = '';
    }

    changeToOperation() {
        this.mode = this.modes.operation;
        this.isOperation = true;
        this.isSecuencial = false;
    }

    changeToSecuencial() {
        this.mode = this.modes.secuencial;
        this.isOperation = false;
        this.isSecuencial = true;
    }

    search() {
        if (this.isOperation) {
            this._emusaServiceProxy
                .updateInventoryLocation(
                    this.productText,
                    this.ubicationText,
                    this.session.warehouse.codAlmacen,
                    this.session.product
                ).pipe(finalize(() => this.busy = false))
                .subscribe((result) => {

                    const propertyName: string = `${this.ubicationText}`;

                    if (this.historyubication == propertyName)
                        this.historyCount++;
                    else {
                        this.historyubication = propertyName;
                        this.historyCount = 1;
                    }

                    if (this.fixUbication) {
                        setTimeout(async () => this.product.setFocus(), 250);
                        this.productText = '';
                    } else {
                        this.ubicationText = '';
                        this.productText = '';
                        setTimeout(async () => this.ubication.setFocus(), 250);
                    }

                    this.notify.success(result.message, 3000, 'top');
                    this.audio.play('success');
                    this.refreshPending();
                });
        } else {
            this.dialog.showWithData<IDefaultModalResponse<number>>({
                component: DispatchContentComponent,
                componentProps: {
                    secuencial: this.productText,
                    ubication: this.ubicationText
                }
            }).then((response) => {

                if (response.data.result?.success) {

                    const propertyName: string = `${this.ubicationText}`;

                    if (this.historyubication == propertyName)
                        this.historyCount += response.data.result.data;
                    else {
                        this.historyubication = propertyName;
                        this.historyCount = response.data.result.data;
                    }

                    if (this.fixUbication) {
                        setTimeout(async () => this.product.setFocus(), 250);
                        this.productText = '';
                    } else {
                        this.ubicationText = '';
                        this.productText = '';
                        setTimeout(async () => this.ubication.setFocus(), 250);
                    }
                } else {
                    this.productText = '';
                    setTimeout(async () => this.product.setFocus(), 250);
                }
                this.refreshPending();
            });
        }
    }

    refreshPending() {
        this.inventoryCount = 0;
        this.pendingInventoryCount = 0;
        this.loading = true;
        this.pendingRequestSubscription?.unsubscribe();
        this.pendingRequestSubscription = this._emusaServiceProxy
            .getInventoryPending(this.session.warehouse.codAlmacen, this.session.product)
            .pipe(finalize(() => this.loading = false))
            .subscribe(response => {
                this.inventoryCount = response.totalInventariado;
                this.pendingInventoryCount = response.totalPendientesInventariar;
            });
    }

    onBackButtonPressed(): void {
        this.message.confirm('¿Esta seguro de ir a inicio?', 'Aviso', (confirmation) => {
            if (confirmation) {
                this.toggleMenu();
                this.navigateForward('/customer/home');
            }
        }, 'Si', 'Cancelar');
    }

}