import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from '@account/login/login.component';
import { AccountRoutingModule } from '@account/account-routing.module';
import { AppSharedModule } from '@shared/shared.module';
import { AccountComponent } from '@account/account.component';
import { ServiceProxyModule } from '@shared/service-proxies/service-proxy.module';
import { AccountGuard } from '@shared/auth/account.guard';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    AccountRoutingModule,
    AppSharedModule,
    ServiceProxyModule
  ],
  declarations: [
    AccountComponent,
    LoginComponent
  ],
  providers: [
    AccountGuard
  ]
})
export class AccountModule {}
