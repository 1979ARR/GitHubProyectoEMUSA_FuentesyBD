import { Component, Injector, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppViewComponent } from '@shared/common/app-component-base';
import { EmusaLogin, EmusaServiceProxy } from '@shared/service-proxies/service-proxies';
import { finalize } from 'rxjs/operators';

@Component({
    templateUrl: 'login.component.html',
    styleUrls: [
        'login.component.scss'
    ]
})
export class LoginComponent extends AppViewComponent implements OnInit {

    private builder: FormBuilder;

    loginForm: FormGroup;
    passwordInputType: string = 'password';
    passwordInputIcon: string = 'eye';

    get username(): AbstractControl {
        return this.loginForm.controls['username'];
    };

    get password(): AbstractControl {
        return this.loginForm.controls['password'];
    };

    constructor(_injector: Injector, private _emusaServiceProxy: EmusaServiceProxy) {
        super(_injector);

        this.builder = _injector.get(FormBuilder);
        this.loginForm = this.builder.group({
            'username': ['', Validators.compose([Validators.required])],
            'password': ['', Validators.required]
        });
    }

    ngOnInit(): void {
        this.clipboard.paste.subscribe((text) => {
            this.notify.success(text, 1000);
        });
    }

    resetPasswordText() {
        this.password.setValue('');
    }

    resetUserText() {
        this.username.setValue('');
    }

    togglePassword() {
        if (this.passwordInputType === 'password') {
            this.passwordInputType = 'text';
            this.passwordInputIcon = 'eye-off';
        } else {
            this.passwordInputType = 'password';
            this.passwordInputIcon = 'eye';
        }
    }

    login() {
        if (!this.username.value) {
            this.message.info('Debe ingresar el nombre de usuario', 'Aviso');
            return;
        }
        if (!this.password.value) {
            this.message.info('Debe ingresar la contraseña', 'Aviso');
            return;
        }

        this.showLoading('Iniciando sesión, por favor espere...').then(loading => {
            this._emusaServiceProxy.login(new EmusaLogin({
                userName: this.username.value,
                password: this.password.value
            })).pipe(finalize(async () => await loading.dismiss())).subscribe((response) => {
                this.session.removeWarehouse();
                this.session.removeProduct();
                this.session.login(response);
                this.navigateForward('/customer/warehouse');
            });
        });
    }
}