import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from '@account/login/login.component';
import { AccountComponent } from '@account/account.component';
import { AccountGuard } from '@shared/auth/account.guard';

const routes: Routes = [
    {
        path: '',
        component: AccountComponent,
        canActivate: [AccountGuard],
        canActivateChild: [AccountGuard],
        children: [
            { path: 'login', component: LoginComponent },
            { path: '', pathMatch: 'full', redirectTo: '/account/login' },
            { path: '**', redirectTo: '/account/login' }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AccountRoutingModule { }
