﻿using Autofac;
using Microsoft.Extensions.Configuration;
using VIM.Api.Application.Services.Almacen;
using VIM.Api.Application.Services.Demo;
using VIM.Api.Application.Services.Indicadores;
using VIM.Api.Application.Services.Reportes;
using VIM.Api.Application.Services.Seguridad;

namespace VIM.Api.Infrastructure.AutofacModules
{
    public class ApplicationModule : Autofac.Module
    {
        protected string ConnectionString { get; private set; }
        protected string AuthKey { get; private set; }
        protected IConfiguration _configuration { get; private set; }

        public ApplicationModule(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        protected override void Load(ContainerBuilder builder)
        {

            #region Services

            builder.Register(c => new DemoAppService(_configuration))
              .As<IDemoAppService>()
              .InstancePerLifetimeScope();

            builder.Register(c => new SeguridadAppService(_configuration))
             .As<ISeguridadAppService>()
             .InstancePerLifetimeScope();

            builder.Register(c => new AlmacenAppService(_configuration))
             .As<IAlmacenAppService>()
             .InstancePerLifetimeScope();

            builder.Register(c => new ReportesAppService(_configuration))
             .As<IReportesAppService>()
             .InstancePerLifetimeScope();

            builder.Register(c => new IndicadoresAppService(_configuration))
             .As<IIndicadoresAppService>()
             .InstancePerLifetimeScope();

            #endregion

        }
    }
}
