﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace VIM.Api.Infrastructure.Models
{
    public class FormContent
    {
        public long Id { get; set; }
        public IFormFile? File { get; set; }
        public string? Data { get; set; }
    }

    public class DownloadFile
    {
        public MemoryStream Memory { get; set; }
        public string ContentType { get; set; }
        public byte[] Content { get; set; }
        public string FileName { get; set; }
    }
}
