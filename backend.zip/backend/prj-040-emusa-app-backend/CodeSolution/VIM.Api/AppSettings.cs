﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VIM.Api
{
    public class AppSettings
    {
       
        
    }

    public class AppAuthSettings
    {
        public string Secret { get; set; }
    }
}
