﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Owin.Security.DataHandler.Encoder;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using VIM.Api.Application.Services.Seguridad;
using VIM.Application.Shared.TransferObject.Request.Seguridad;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Seguridad;
using VIM.Common.Shared.Constant;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace VIM.Api.Controllers
{
    [EnableCors(IncomeWebApi.Cross.Cors)]
    [Route(IncomeWebApi.PrefixApi.Seguridad)]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly ISeguridadAppService _seguridadAppService;
        private readonly IConfiguration _configuration;
        private readonly ILogger _logger;
        public AuthenticationController(ILogger<AuthenticationController> logger,
                                   ISeguridadAppService seguridadAppService,
                                   IConfiguration configuration)
        {
            this._logger = logger;
            this._seguridadAppService = seguridadAppService;
            this._configuration = configuration;
        }
        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Seguridad.Login)]
        public async Task<IActionResult> Login(SeguridadRequest seguridadRequest)
        {
            var result = await _seguridadAppService.validateUser(seguridadRequest, false);
            if (result.Status)
            {
                GenerarToken(result.Result);
            }

            return Ok(result);
        }
        //[Authorize]
        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Seguridad.ValidarSesion)]
        public async Task<IActionResult> validarsesion()
        {
            var result = new Response<SeguridadResponse>();
            result.Result = new SeguridadResponse();
            try
            {
                SeguridadRequest seguridadRequest = new SeguridadRequest();
                seguridadRequest.UserName = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value ?? User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value;
                if (!string.IsNullOrEmpty(seguridadRequest.UserName))
                {
                    result = await _seguridadAppService.validateUser(seguridadRequest, true);
                }
            }
            catch (Exception)
            {
                result.Status = false;
                result.State = 200;
                result.Message = "Sessión inválida";
            }
            return Ok(result);
        }
        [NonAction]
        private void GenerarToken(SeguridadResponse usuario)
        {
            var claims = new[]
            {
                new Claim(ClaimTypes.Sid, $"{usuario.Usuario.CodUser}"),
                new Claim(ClaimTypes.Name, usuario.Usuario.NombreCompleto),
                new Claim(ClaimTypes.NameIdentifier, usuario.Usuario.UserName),
                //new Claim(ClaimTypes.StreetAddress, IP),
                //new Claim(ClaimTypes.Uri, Servidor),
                //new Claim(ClaimTypes.Email, usuario.Usuario.core),
            };
            //var secret = TextEncodings.Base64Url.Decode(_configuration.GetValue<string>("Auth:Secret"));
            var llave = Encoding.UTF8.GetBytes(_configuration.GetValue<string>("Auth:Secret"));
            //var llave = Encoding.UTF8.GetBytes(_configuracionSistema.JWT.Llave);
            var expiracion = DateTime.UtcNow.AddDays(1);   //AddHours
            usuario.ExpiracionToken = $"{expiracion:yyyy-MM-dd HH:mm:ss}";

            var createdToken = new JwtSecurityToken
            (
                // issuer: ValidIssuer,
                // audience: ValidAudience,
                claims: claims,
                expires: expiracion,
                notBefore: DateTime.UtcNow,
                signingCredentials: new SigningCredentials(new SymmetricSecurityKey(llave), SecurityAlgorithms.HmacSha256)
            );

            var tokenHandler = new JwtSecurityTokenHandler();

            usuario.Token = tokenHandler.WriteToken(createdToken);
        }
    }
}
