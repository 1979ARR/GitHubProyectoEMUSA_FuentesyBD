﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Api.Application.Services.Indicadores;
using VIM.Application.Shared.TransferObject.Request.Indicadores;
using VIM.Common.Shared.Constant;

namespace VIM.Api.Controllers
{
    [EnableCors(IncomeWebApi.Cross.Cors)]
    [Route(IncomeWebApi.PrefixApi.Indicador)]
    [ApiController]
    //[Authorize]
    public class IndicadorController : ControllerBase
    {

        private readonly IIndicadoresAppService _indicadoresAppService;
        private readonly ILogger _logger;
        public IndicadorController(ILogger<ReporteController> logger,
                                   IIndicadoresAppService indicadoresAppService)
        {
            this._logger = logger;
            this._indicadoresAppService = indicadoresAppService;
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Indicador.ObtenerDatosERI)]
        public async Task<IActionResult> ObtenerDatosERI([FromQuery] IndicadorERIRequest request)
        {
            var result = await _indicadoresAppService.ObtenerDatosERI(request);
            return Ok(result);
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Indicador.ObtenerDatosTablaERI)]
        public async Task<IActionResult> ObtenerDatosTablaERI([FromQuery] IndicadorERIRequest request)
        {
            var result = await _indicadoresAppService.ObtenerDatosTablaERI(request);
            return Ok(result);
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Indicador.ObtenerDatosPU)]
        public async Task<IActionResult> ObtenerDatosPU([FromQuery] IndicadorPURequest request)
        {
            var result = await _indicadoresAppService.ObtenerDatosPU(request);
            return Ok(result);
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Indicador.ObtenerDatosCA)]
        public async Task<IActionResult> ObtenerDatosCA([FromQuery] IndicadorCARequest request)
        {
            var result = await _indicadoresAppService.ObtenerDatosCA(request);
            return Ok(result);
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Indicador.ListarUsuariosInd)]
        public async Task<IActionResult> ListarUsuariosInd()
        {
            var result = await _indicadoresAppService.ListarUsuariosInd();
            return Ok(result);
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Indicador.ObtenerDatosFIFO)]
        public async Task<IActionResult> ObtenerDatosFIFO([FromQuery] IndicadorFIFORequest request)
        {
            var result = await _indicadoresAppService.ObtenerDatosFIFO(request);
            return Ok(result);
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Indicador.ObtenerDatosRO)]
        public async Task<IActionResult> ObtenerDatosRO([FromQuery] IndicadorRORequest request)
        {
            var result = await _indicadoresAppService.ObtenerDatosRO(request);
            return Ok(result);
        }

    }
}
