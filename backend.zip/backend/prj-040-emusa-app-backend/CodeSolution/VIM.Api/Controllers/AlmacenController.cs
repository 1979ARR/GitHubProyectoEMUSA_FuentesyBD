﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using VIM.Api.Application.Services.Almacen;
using VIM.Application.Shared.TransferObject.Request.Almacen;
using VIM.Common.Shared.Constant;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace VIM.Api.Controllers
{
    [EnableCors(IncomeWebApi.Cross.Cors)]
    [Route(IncomeWebApi.PrefixApi.Almacen)]
    [ApiController]
    [Authorize]
    public class AlmacenController : ControllerBase
    {
        private readonly IAlmacenAppService _almacenAppService;
        private readonly ILogger _logger;
        public AlmacenController(ILogger<AlmacenController> logger,
                                   IAlmacenAppService almacenAppService)
        {
            this._logger = logger;
            this._almacenAppService = almacenAppService;
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Almacen.consultar)]
        public async Task<IActionResult> ListarProductos()
        {
            var result = await _almacenAppService.ListarAlmacen();
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.pendientesubicar)]
        public async Task<IActionResult> pendientesubicar(PendientesUbicarRequest pendientesUbicarRequest)
        {
            var result = await _almacenAppService.ListarBobinaPedientesUbicar(pendientesUbicarRequest);
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.actualizarUbicacion)]
        public async Task<IActionResult> actualizarUbicacion(BobinaRequest bobinaRequest)
        {
            bobinaRequest.IdUsuario = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value;
            var result = await _almacenAppService.ActualizarBobina(bobinaRequest);
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.pendientesInventariar)]
        public async Task<IActionResult> pendientesInventariar(PendientesUbicarRequest pendientesUbicarRequest)
        {
            var result = await _almacenAppService.ListarBobinaPedientesInventariar(pendientesUbicarRequest);
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.actualizarUbicacionInventario)]
        public async Task<IActionResult> actualizarUbicacionInventario(BobinaRequest bobinaRequest)
        {
            bobinaRequest.IdUsuario = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value;
            var result = await _almacenAppService.ActualizarBobinaInventario(bobinaRequest);
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.pendientesPickupOTBobinaApilador)]
        public async Task<IActionResult> pendientesPickupOTBobinaApilador(PendientesUbicarRequest pendientesUbicarRequest)
        {
            var result = await _almacenAppService.ListarBobinaPedientesPickupOTBobinaApilador(pendientesUbicarRequest);
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.actualizarUbicacionPickingOTBobinaApilador)]
        public async Task<IActionResult> actualizarUbicacionPickingOTBobinaApilador(BobinaRequest bobinaRequest)
        {
            bobinaRequest.IdUsuario = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value;
            var result = await _almacenAppService.ActualizarBobinaPickUpOTBobinaApilador(bobinaRequest);
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.pendientesPickupOTBobinaStockero)]
        public async Task<IActionResult> pendientesPickupOTBobinaStockero(PendientesUbicarRequest pendientesUbicarRequest)
        {
            var result = await _almacenAppService.ListarBobinaPedientesPickupOTBobinaStockero(pendientesUbicarRequest);
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.actualizarUbicacionPickingOTBobinaStokero)]
        public async Task<IActionResult> actualizarUbicacionPickingOTBobinaStockero(BobinaRequest bobinaRequest)
        {
            bobinaRequest.IdUsuario = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value;
            var result = await _almacenAppService.ActualizarBobinaPickUpOTBobinaStockero(bobinaRequest);
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.obtenerBobinasporSecuencialApp)]
        public async Task<IActionResult> obtenerBobinasporSecuencialApp(BobinaporSecuencialAppRequest bobinaporSecuencialAppRequest)
        {
            var result = await _almacenAppService.obtenerBobinasporSecuencialApp(bobinaporSecuencialAppRequest);
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.obtenerBobinasporSecuencialAppNI)]
        public async Task<IActionResult> obtenerBobinasporSecuencialAppNI(BobinaporSecuencialAppRequest bobinaporSecuencialAppRequest)
        {
            var result = await _almacenAppService.obtenerBobinasporSecuencialAppNI(bobinaporSecuencialAppRequest);
            return Ok(result);
        }


        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.actualizarUbicacionInventarioSecuencialApp)]
        public async Task<IActionResult> actualizarUbicacionInventarioSecuencialApp(SecuencialAppRequest secuencialAppRequest)
        {
            secuencialAppRequest.IdUsuario = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value;
            var result = await _almacenAppService.actualizarUbicacionInventarioSecuencialApp(secuencialAppRequest);
            return Ok(result);
        }

        [HttpPost]
        [Route(IncomeWebApi.MethodApi.Almacen.actualizarUbicacionSecuencialApp)]
        public async Task<IActionResult> actualizarUbicacionSecuencialApp(SecuencialAppRequest secuencialAppRequest)
        {
            secuencialAppRequest.IdUsuario = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.NameIdentifier).Value;
            var result = await _almacenAppService.actualizarUbicacionSecuencialApp(secuencialAppRequest);
            return Ok(result);
        }

    }
}
