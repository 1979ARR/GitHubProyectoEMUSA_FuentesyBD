﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Api.Application.Services.Demo;
using VIM.Application.Shared.TransferObject.Request.Demo;
using VIM.Common.Shared.Constant;

namespace VIM.Api.Controllers
{
    //[EnableCors(IncomeWebApi.Cross.Cors)]
    //[Route(IncomeWebApi.PrefixApi.Demo)]
    //[ApiController]
    //public class DemoController : ControllerBase
    //{
    //    private readonly IDemoAppService _demoAppService;
    //    private readonly ILogger _logger;
    //    public DemoController(ILogger<DemoController> logger,
    //                               IDemoAppService demoAppService)
    //    {
    //        this._logger = logger;
    //        this._demoAppService = demoAppService;
    //    }

    //    [HttpPost]
    //    [Route(IncomeWebApi.MethodApi.Demo.RegistrarProducto)]
    //    public async Task<IActionResult> RegistrarProducto(ProductoRequest productoRequest)
    //    {
    //        var result = await _demoAppService.RegistrarProducto(productoRequest);
    //        return Ok(result);
    //    }

    //    [HttpPost]
    //    [Route(IncomeWebApi.MethodApi.Demo.ActualizarProducto)]
    //    public async Task<IActionResult> ActualizarProducto(ProductoRequest productoRequest)
    //    {
    //        var result = await _demoAppService.ActualizarProducto(productoRequest);
    //        return Ok(result);
    //    }

    //    [HttpGet]
    //    [Route(IncomeWebApi.MethodApi.Demo.ObtenerProducto)]
    //    public async Task<IActionResult> ObtenerProducto([FromQuery] ProductoRequest productoRequest)
    //    {
    //        var result = await _demoAppService.ObtenerProducto(productoRequest);
    //        return Ok(result);
    //    }

    //    [HttpGet]
    //    [Route(IncomeWebApi.MethodApi.Demo.ListarProductos)]
    //    public async Task<IActionResult> ListarProductos()
    //    {
    //        var result = await _demoAppService.ListarProductos();
    //        return Ok(result);
    //    }

    //}
}
