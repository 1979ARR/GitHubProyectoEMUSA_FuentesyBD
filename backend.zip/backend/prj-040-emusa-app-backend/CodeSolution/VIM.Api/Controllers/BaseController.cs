﻿using Microsoft.AspNetCore.Mvc;

namespace VIM.Api.Controllers
{
    public class BaseController : ControllerBase
    {
        public BaseController()
        {

        }
    }
}
