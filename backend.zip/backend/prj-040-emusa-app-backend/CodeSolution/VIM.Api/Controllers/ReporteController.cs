﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Api.Application.Services.Reportes;
using VIM.Application.Shared.TransferObject.Request.Reportes;
using VIM.Common.Shared.Constant;

namespace VIM.Api.Controllers
{
    [EnableCors(IncomeWebApi.Cross.Cors)]
    [Route(IncomeWebApi.PrefixApi.Reporte)]
    [ApiController]
    //[Authorize]
    public class ReporteController : ControllerBase
    {
        private readonly IReportesAppService _reporteAppService;
        private readonly ILogger _logger;
        public ReporteController(ILogger<ReporteController> logger,
                                   IReportesAppService reporteAppService)
        {
            this._logger = logger;
            this._reporteAppService = reporteAppService;
        }

        //Listado Linea
        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.Linea)]
        public async Task<IActionResult> Linea()
        {
            var result = await _reporteAppService.ListarLinea();
            return Ok(result);
        }

        //Listado Sublinea
        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.Sublinea)]
        public async Task<IActionResult> Sublinea([FromQuery] string codLinea)
        {
            var result = await _reporteAppService.ListarSublinea(codLinea);
            return Ok(result);
        }
        //Listado Mes Actual
        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.MesActual)]
        public async Task<IActionResult> MesActual([FromQuery] string tipo)
        {
            var result = await _reporteAppService.ListarMesActual(tipo);
            return Ok(result);
        }

        //Listado Anios
        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.AniosxReporte)]
        public async Task<IActionResult> AniosxReporte([FromQuery] string tipo)
        {
            var result = await _reporteAppService.ListarAniosxReporte(tipo);
            return Ok(result);
        }

        //Listado Almacen
        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.Almacen)]
        public async Task<IActionResult> Almacen()
        {
            var result = await _reporteAppService.ListarAlmacen();
            return Ok(result);
        }

        //Pendientes por Ubicar
        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.MateriaPrima)]
        public async Task<IActionResult> MateriaPrima([FromQuery] MateriaPrimaRequest materiaPrimaRequest)
        {
            var result = await _reporteAppService.ListarMateriaPrima(materiaPrimaRequest);
            return Ok(result);
        }


        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.ProductosEnProceso)]
        public async Task<IActionResult> ProductosEnProceso([FromQuery] ProductosEnProcesoRequest productosEnProcesoRequest)
        {
            var result = await _reporteAppService.ListarProductosEnProceso(productosEnProcesoRequest);
            return Ok(result);
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.ProductosTerminados)]
        public async Task<IActionResult> ProductosTerminados([FromQuery] ProductoTerminadoRequest productoTerminadoRequest)
        {
            var result = await _reporteAppService.ListarProductosTerminados(productoTerminadoRequest);
            return Ok(result);
        }
      

        //KardexBobina
        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.KardexBobina)]
        public async Task<IActionResult> KardexBobina([FromQuery] KardexBobinaRequest kardexBobinaRequest)
        {
            var result = await _reporteAppService.ListarKardexBobina(kardexBobinaRequest);
            return Ok(result);
        }

        //Bobina con PNC
        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.BobinaConPNC)]
        public async Task<IActionResult> BobinaConPNC([FromQuery] BobinaConPNCRequest bobinaConPNCRequest)
        {
            var result = await _reporteAppService.ListarBobinaConPNC(bobinaConPNCRequest);
            return Ok(result);
        }

        //Desarrollo de Inventario
        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.MateriaPrimaD)]
        public async Task<IActionResult> MateriaPrimaD([FromQuery] MateriaPrimaRequest materiaPrimaRequest)
        {
            var result = await _reporteAppService.ListarMateriaPrimaD(materiaPrimaRequest);
            return Ok(result);
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.ProductosEnProcesoD)]
        public async Task<IActionResult> ProductosEnProcesoD([FromQuery] ProductosEnProcesoRequest productosEnProcesoRequest)
        {
            var result = await _reporteAppService.ListarProductosEnProcesoD(productosEnProcesoRequest);
            return Ok(result);
        }

        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.ProductosTerminadosD)]
        public async Task<IActionResult> ProductosTerminadosD([FromQuery] ProductoTerminadoRequest productoTerminadoRequest)
        {
            var result = await _reporteAppService.ListarProductosTerminadosD(productoTerminadoRequest);
            return Ok(result);
        }

        //Proceso de Produccion
        [HttpGet]
        [Route(IncomeWebApi.MethodApi.Reporte.ProcesoDeProduccion)]
        public async Task<IActionResult> ProcesoDeProduccion([FromQuery] ProcesoDeProduccionRequest procesoDeProduccionRequest)
        {
            var result = await _reporteAppService.ListarProcesoDeProduccion(procesoDeProduccionRequest);
            return Ok(result);
        }

        //Exportar
        [HttpGet, DisableRequestSizeLimit]
        [Route(IncomeWebApi.MethodApi.Reporte.ExportarReporteGenerico)]
        public async Task<IActionResult> ExportarReporteGenerico([FromQuery] ReporteGenericoRequest reporteGenericoRequest)
        {
            var result = await _reporteAppService.ExportarReporteGenerico(reporteGenericoRequest);
            return File(result.Memory, result.ContentType, result.FileName);
        }

    }
}
