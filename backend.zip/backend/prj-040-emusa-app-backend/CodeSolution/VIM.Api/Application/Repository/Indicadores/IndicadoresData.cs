﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Indicadores;
using VIM.Application.Shared.TransferObject.Response.Indicadores;
using VIM.Common.Shared.Constant;

namespace VIM.Api.Application.Repository.Indicadores
{
    public class IndicadoresData : IIndicadoresData
    {
        private readonly string connectionString;
        //Paquete
        public string userPackageBD { get; set; }
        public IndicadoresData(string connectionString)
        {
            this.connectionString = connectionString;
            this.userPackageBD = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgWebReportes}"; // Desarrollo
            //this.userPackageBD = $"{IncomeDataProcedures.Package.PkgWebReportes}"; // Producción
        }

        public async Task<dynamic> ObtenerDatosERIMP(IndicadorERIRequest request)
        {
            dynamic result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorERIMP}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            if (request.Linea == null)
                            {
                                result = new
                                {
                                    SuministroAvance = await reader.IsDBNullAsync(0) ? 0 : Convert.ToInt64(reader.GetString(0)),
                                    SuministroFalta = await reader.IsDBNullAsync(1) ? 0 : Convert.ToInt64(reader.GetString(1)),
                                    InsumoAvance = await reader.IsDBNullAsync(2) ? 0 : Convert.ToInt64(reader.GetString(2)),
                                    InsumoFalta = await reader.IsDBNullAsync(3) ? 0 : Convert.ToInt64(reader.GetString(3)),
                                    MateriaPrimaAvance = await reader.IsDBNullAsync(4) ? 0 : Convert.ToInt64(reader.GetString(4)),
                                    MateriaPrimaFalta = await reader.IsDBNullAsync(5) ? 0 : Convert.ToInt64(reader.GetString(5))
                                };
                            }
                            else
                            {
                                result = new
                                {
                                    Cantidad = await reader.IsDBNullAsync(0) ? 0 : Convert.ToInt64(reader.GetString(0)),
                                    Total = await reader.IsDBNullAsync(1) ? 0 : Convert.ToInt64(reader.GetString(1))
                                };
                            }
                        }

                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<List<IndicadorERIResponse>> ObtenerDatosTablaERIMP(IndicadorERIRequest request)
        {
            List<IndicadorERIResponse> list = new List<IndicadorERIResponse>();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorTablaERIMP}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            list.Add(new IndicadorERIResponse()
                            {
                                OrigenDescripcion = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                UnidadCodigo = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                LineaDescripcion = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                Cantidad = await reader.IsDBNullAsync(3) ? 0 : reader.GetInt64(3),
                                Peso = await reader.IsDBNullAsync(4) ? 0 : reader.GetDecimal(4)
                            });
                        }

                        await reader.DisposeAsync();
                        return list;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<List<IndicadorERIResponse>> ObtenerDatosTablaERIPP(IndicadorERIRequest request)
        {
            List<IndicadorERIResponse> list = new List<IndicadorERIResponse>();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorTablaERIPP}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            list.Add(new IndicadorERIResponse()
                            {
                                Cantidad = await reader.IsDBNullAsync(0) ? 0 : reader.GetInt64(0),
                                Peso = await reader.IsDBNullAsync(1) ? 0 : reader.GetDecimal(1)
                            });
                        }

                        await reader.DisposeAsync();
                        return list;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<List<IndicadorERIResponse>> ObtenerDatosTablaERIPT(IndicadorERIRequest request)
        {
            List<IndicadorERIResponse> list = new List<IndicadorERIResponse>();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorTablaERIPT}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            list.Add(new IndicadorERIResponse()
                            {
                                OrigenDescripcion = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                ClienteCodigo = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                SucursalDescripcion = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                Cantidad = await reader.IsDBNullAsync(3) ? 0 : reader.GetInt64(3),
                                Peso = await reader.IsDBNullAsync(4) ? 0 : reader.GetDecimal(4)
                            });
                        }

                        await reader.DisposeAsync();
                        return list;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<dynamic> ObtenerDatosERIPP(IndicadorERIRequest request)
        {
            dynamic result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorERIPP}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            result = new
                            {
                                Cantidad = await reader.IsDBNullAsync(0) ? 0 : Convert.ToInt64(reader.GetString(0)),
                                Total = await reader.IsDBNullAsync(1) ? 0 : Convert.ToInt64(reader.GetString(1))
                            };
                        }

                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<dynamic> ObtenerDatosERIPT(IndicadorERIRequest request)
        {
            dynamic result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorERIPT}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            if (request.Linea == null)
                            {
                                result = new
                                {
                                    ProductoTerminadoInventariado = await reader.IsDBNullAsync(0) ? 0 : Convert.ToInt64(reader.GetString(0)),
                                    ProductoTerminadoNoInventariado = await reader.IsDBNullAsync(1) ? 0 : Convert.ToInt64(reader.GetString(1)),
                                    MuestraVentaInventariada = await reader.IsDBNullAsync(2) ? 0 : Convert.ToInt64(reader.GetString(2)),
                                    MuestraVentaNoInventariada = await reader.IsDBNullAsync(3) ? 0 : Convert.ToInt64(reader.GetString(3))
                                };
                            }
                            else
                            {
                                result = new
                                {
                                    Cantidad = await reader.IsDBNullAsync(0) ? 0 : Convert.ToInt64(reader.GetString(0)),
                                    Total = await reader.IsDBNullAsync(1) ? 0 : Convert.ToInt64(reader.GetString(1))
                                };
                            }
                        }

                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<List<ItemProduccion>> ObtenerDatosPU(IndicadorPURequest request)
        {
            List<ItemProduccion> lst = new List<ItemProduccion>();

            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorPU}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("ANIO", OracleDbType.Varchar2, request.Anio, ParameterDirection.Input);
                        cmd.Parameters.Add("USUARIO", OracleDbType.Varchar2, request.Usuario, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            lst.Add(new ItemProduccion()
                            {
                                Cantidad = await reader.IsDBNullAsync(0) ? 0 : Convert.ToInt32(reader.GetString(0)),
                                Fecha = await reader.IsDBNullAsync(1) ? "" : reader.GetString(1)
                            });
                        }

                        await reader.DisposeAsync();
                        return lst;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<List<ItemRotacion>> ObtenerDatosROMP(IndicadorRORequest request)
        {
            List<ItemRotacion> lst = new List<ItemRotacion>();

            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorROMP}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("ANIO", OracleDbType.Varchar2, request.Anio, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            lst.Add(new ItemRotacion()
                            {
                                Cantidad = await reader.IsDBNullAsync(0) ? 0 : reader.GetDecimal(0),
                                Fecha = await reader.IsDBNullAsync(1) ? "" : reader.GetString(1)
                            });
                        }

                        await reader.DisposeAsync();
                        return lst;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<List<ItemRotacion>> ObtenerDatosROPP(IndicadorRORequest request)
        {
            List<ItemRotacion> lst = new List<ItemRotacion>();

            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorROPP}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("ANIO", OracleDbType.Varchar2, request.Anio, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            lst.Add(new ItemRotacion()
                            {
                                Cantidad = await reader.IsDBNullAsync(0) ? 0 : reader.GetDecimal(0),
                                Fecha = await reader.IsDBNullAsync(1) ? "" : reader.GetString(1)
                            });
                        }

                        await reader.DisposeAsync();
                        return lst;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<List<ItemRotacion>> ObtenerDatosROPT(IndicadorRORequest request)
        {
            List<ItemRotacion> lst = new List<ItemRotacion>();

            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorROPT}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("ANIO", OracleDbType.Varchar2, request.Anio, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            lst.Add(new ItemRotacion()
                            {
                                Cantidad = await reader.IsDBNullAsync(0) ? 0 : reader.GetDecimal(0),
                                Fecha = await reader.IsDBNullAsync(1) ? "" : reader.GetString(1)
                            });
                        }

                        await reader.DisposeAsync();
                        return lst;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<ItemCAResponse> ObtenerDatosCAMP(IndicadorCARequest request)
        {
            ItemCAResponse result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorCAMP}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("UBICACION", OracleDbType.Varchar2, request.Ubicacion, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            result = new ItemCAResponse()
                            {
                                LimiteVerde = await reader.IsDBNullAsync(0) ? 0 : reader.GetInt64(0),
                                LimiteAmarillo = await reader.IsDBNullAsync(1) ? 0 : reader.GetInt64(1),
                                LimiteRojo = await reader.IsDBNullAsync(2) ? 0 : reader.GetInt64(2),
                                Valor = await reader.IsDBNullAsync(3) ? 0 : reader.GetDecimal(3)
                            };
                        }

                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<ItemCAResponse> ObtenerDatosCAPP(IndicadorCARequest request)
        {
            ItemCAResponse result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorCAPP}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("UBICACION", OracleDbType.Varchar2, request.Ubicacion, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            result = new ItemCAResponse()
                            {
                                LimiteVerde = await reader.IsDBNullAsync(0) ? 0 : reader.GetInt64(0),
                                LimiteAmarillo = await reader.IsDBNullAsync(1) ? 0 : reader.GetInt64(1),
                                LimiteRojo = await reader.IsDBNullAsync(2) ? 0 : reader.GetInt64(2),
                                Valor = await reader.IsDBNullAsync(3) ? 0 : reader.GetDecimal(3)
                            };
                        }

                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<ItemCAResponse> ObtenerDatosCAPT(IndicadorCARequest request)
        {
            ItemCAResponse result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerIndicadorCAPT}"; 

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("UBICACION", OracleDbType.Varchar2, request.Ubicacion, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            result = new ItemCAResponse()
                            {
                                LimiteVerde = await reader.IsDBNullAsync(0) ? 0 : reader.GetInt64(0),
                                LimiteAmarillo = await reader.IsDBNullAsync(1) ? 0 : reader.GetInt64(1),
                                LimiteRojo = await reader.IsDBNullAsync(2) ? 0 : reader.GetInt64(2),
                                Valor = await reader.IsDBNullAsync(3) ? 0 : reader.GetDecimal(3)
                            };
                        }

                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<List<UsuarioInd>> ListarUsuariosInd()
        {
            List<UsuarioInd> lst = new List<UsuarioInd>();

            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerUsuariosInd}";
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            lst.Add(new UsuarioInd()
                            {
                                Codigo = await reader.IsDBNullAsync(0) ? "" : reader.GetString(0),
                                Descripcion = await reader.IsDBNullAsync(1) ? "" : reader.GetString(1)
                            });
                        }

                        await reader.DisposeAsync();
                        return lst;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<IndicadorFIFOResponse> ObtenerDatosFIFOMP(IndicadorFIFORequest request)
        {
            IndicadorFIFOResponse result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerDatosFIFOMP}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            result = new IndicadorFIFOResponse()
                            {
                                Valor1 = await reader.IsDBNullAsync(0) ? 0 : reader.GetDecimal(0),
                                Valor2 = await reader.IsDBNullAsync(1) ? 0 : reader.GetDecimal(1),
                                Valor3 = await reader.IsDBNullAsync(2) ? 0 : reader.GetDecimal(2),
                                Valor4 = await reader.IsDBNullAsync(3) ? 0 : reader.GetDecimal(3),
                                Valor5 = await reader.IsDBNullAsync(4) ? 0 : reader.GetDecimal(4),
                                Valor6 = await reader.IsDBNullAsync(5) ? 0 : reader.GetDecimal(5)
                            };
                        }

                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<IndicadorFIFOResponse> ObtenerDatosFIFOPP(IndicadorFIFORequest request)
        {
            IndicadorFIFOResponse result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerDatosFIFOPP}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            result = new IndicadorFIFOResponse()
                            {
                                Valor1 = await reader.IsDBNullAsync(0) ? 0 : reader.GetDecimal(0),
                                Valor2 = await reader.IsDBNullAsync(1) ? 0 : reader.GetDecimal(1),
                                Valor3 = await reader.IsDBNullAsync(2) ? 0 : reader.GetDecimal(2),
                                Valor4 = await reader.IsDBNullAsync(3) ? 0 : reader.GetDecimal(3),
                                Valor5 = await reader.IsDBNullAsync(4) ? 0 : reader.GetDecimal(4),
                                Valor6 = await reader.IsDBNullAsync(5) ? 0 : reader.GetDecimal(5)
                            };
                        }

                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<IndicadorFIFOResponse> ObtenerDatosFIFOPT(IndicadorFIFORequest request)
        {
            IndicadorFIFOResponse result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerDatosFIFOPT}";

                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, request.Almacen, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, request.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, request.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULSET", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            result = new IndicadorFIFOResponse()
                            {
                                Valor1 = await reader.IsDBNullAsync(0) ? 0 : reader.GetDecimal(0),
                                Valor2 = await reader.IsDBNullAsync(1) ? 0 : reader.GetDecimal(1),
                                Valor3 = await reader.IsDBNullAsync(2) ? 0 : reader.GetDecimal(2),
                                Valor4 = await reader.IsDBNullAsync(3) ? 0 : reader.GetDecimal(3),
                                Valor5 = await reader.IsDBNullAsync(4) ? 0 : reader.GetDecimal(4),
                                Valor6 = await reader.IsDBNullAsync(5) ? 0 : reader.GetDecimal(5)
                            };
                        }

                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
    }
}
