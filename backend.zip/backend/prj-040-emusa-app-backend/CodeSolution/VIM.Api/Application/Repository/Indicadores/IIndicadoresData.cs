﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Indicadores;
using VIM.Application.Shared.TransferObject.Response.Indicadores;

namespace VIM.Api.Application.Repository.Indicadores
{
    public interface IIndicadoresData
    {
        Task<dynamic> ObtenerDatosERIMP(IndicadorERIRequest request);
        Task<List<IndicadorERIResponse>> ObtenerDatosTablaERIMP(IndicadorERIRequest request);
        Task<List<IndicadorERIResponse>> ObtenerDatosTablaERIPP(IndicadorERIRequest request);
        Task<List<IndicadorERIResponse>> ObtenerDatosTablaERIPT(IndicadorERIRequest request);
        Task<dynamic> ObtenerDatosERIPP(IndicadorERIRequest request);
        Task<dynamic> ObtenerDatosERIPT(IndicadorERIRequest request);
        Task<List<ItemProduccion>> ObtenerDatosPU(IndicadorPURequest request);
        Task<List<ItemRotacion>> ObtenerDatosROMP(IndicadorRORequest request);
        Task<List<ItemRotacion>> ObtenerDatosROPP(IndicadorRORequest request);
        Task<List<ItemRotacion>> ObtenerDatosROPT(IndicadorRORequest request);
        Task<ItemCAResponse> ObtenerDatosCAMP(IndicadorCARequest request);
        Task<ItemCAResponse> ObtenerDatosCAPP(IndicadorCARequest request);
        Task<ItemCAResponse> ObtenerDatosCAPT(IndicadorCARequest request);
        Task<List<UsuarioInd>> ListarUsuariosInd();
        Task<IndicadorFIFOResponse> ObtenerDatosFIFOMP(IndicadorFIFORequest request);
        Task<IndicadorFIFOResponse> ObtenerDatosFIFOPP(IndicadorFIFORequest request);
        Task<IndicadorFIFOResponse> ObtenerDatosFIFOPT(IndicadorFIFORequest request);
    }
}
