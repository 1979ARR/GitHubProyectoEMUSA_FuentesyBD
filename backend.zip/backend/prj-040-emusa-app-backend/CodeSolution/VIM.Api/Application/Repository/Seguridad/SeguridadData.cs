﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Seguridad;
using VIM.Application.Shared.TransferObject.Response.Seguridad;
using VIM.Common.Shared.Constant;

namespace VIM.Api.Application.Repository.Seguridad
{
    public class SeguridadData : ISeguridadData
    {
        private readonly string connectionString;
        public SeguridadData(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public async Task<SeguridadResponse> ObtenerUsuario(SeguridadRequest seguridadRequest, bool autenticacionBasica)
        {
            SeguridadResponse result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{IncomeDataProcedures.Schema.Seguridad}.{IncomeDataProcedures.Package.PkgMobileSeguridad}.{IncomeDataProcedures.Procedure.ObtenerUsuario}";
                        cmd.Parameters.Add("P_AUTENTICACION_BASICA", OracleDbType.Int32, autenticacionBasica ? 1 : 0, ParameterDirection.Input);
                        cmd.Parameters.Add("P_USERNAME", OracleDbType.Varchar2, seguridadRequest.UserName, ParameterDirection.Input);
                        cmd.Parameters.Add("P_PASSWORD", OracleDbType.Varchar2, seguridadRequest.Password, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULT_USUARIO", OracleDbType.RefCursor, ParameterDirection.Output);
                        cmd.Parameters.Add("P_RESULT_PERFIL", OracleDbType.RefCursor, ParameterDirection.Output);
                        cmd.Parameters.Add("P_RESULT_ACCION", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            result = new SeguridadResponse()
                            {
                                Usuario = new Usuario()
                                {
                                    CodUser = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                    UserName = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                    NombreCompleto = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2)
                                }
                            };
                        }
                        if (result != null)
                        {
                            await reader.NextResultAsync();
                            var listPerfil = new List<Perfil>();
                            while (await reader.ReadAsync())
                            {
                                listPerfil.Add(new Perfil()
                                {
                                    CodPerfil = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                    DescPerfil = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1)
                                });
                            }
                            result.Perfil = listPerfil;

                            await reader.NextResultAsync();
                            var listOpciones = new List<Opciones>();
                            while (await reader.ReadAsync())
                            {
                                listOpciones.Add(new Opciones()
                                {
                                    CodOpcion = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                    DescOpcion = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1)
                                });
                            }
                            result.Opciones = listOpciones;
                        }
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
    }
}
