﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Seguridad;
using VIM.Application.Shared.TransferObject.Response.Seguridad;

namespace VIM.Api.Application.Repository.Seguridad
{
    public interface ISeguridadData
    {
        Task<SeguridadResponse> ObtenerUsuario(SeguridadRequest seguridadRequest, bool autenticacionBasica);
    }
}
