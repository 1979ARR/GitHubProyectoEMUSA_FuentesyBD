﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Demo;
using VIM.Application.Shared.TransferObject.Response;

namespace VIM.Api.Application.Repository.Persona
{
    public class PersonaData : IPersonaData
    {

    }
}
