﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Reportes;
using VIM.Application.Shared.TransferObject.Response.Reportes;
using VIM.Common.Shared.Constant;

namespace VIM.Api.Application.Repository.Reportes
{
    public class ReportesData : IReportesData
    {
        private readonly string connectionString;
        //Paquete
        public string userPackageBD { get; set; }
        public ReportesData(string connectionString)
        {
            this.connectionString = connectionString;
            this.userPackageBD = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgWebReportes}"; // Desarrollo
            //this.userPackageBD = $"{IncomeDataProcedures.Package.PkgWebReportes}"; // Producción
        }

        //Listado Mes Actual
        public async Task<List<string>> ListarMesActual(string tipo)
        {
            var lstMes = new List<string>();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarMes}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";
                        cmd.Parameters.Add("TIPO", OracleDbType.Varchar2, tipo, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();


                        while (await reader.ReadAsync())
                        {
                            lstMes.Add(await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0));
                        }

                        await reader.DisposeAsync();
                        return lstMes;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Listado Anio
        public async Task<List<int>> ListarAniosxReporte(string tipo)
        {
            var lstAnios = new List<int>();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarAnios}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";
                        cmd.Parameters.Add("TIPO", OracleDbType.Varchar2, tipo, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();
                        

                        while (await reader.ReadAsync())
                        {
                            lstAnios.Add(await reader.IsDBNullAsync(0) ? 0 : Convert.ToInt32(reader.GetString(0)));
                         }
                        
                        await reader.DisposeAsync();
                        return lstAnios;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Listar Linea
        //Listado Almacen
        public async Task<LineaResponse> ListarLinea()
        {
            LineaResponse result = new LineaResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarLinea}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();
                        List<LineaResponseDetalle> resultDetalle = new List<LineaResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new LineaResponseDetalle
                            {

                                LineaCodigo = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                LineaDescripcion = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1)
                            });

                        }
                        result.Linea = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        //Listado Sublinea
        public async Task<SublineaResponse> ListarSublinea(string codLinea)
        {
            SublineaResponse result = new SublineaResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarSublinea}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";
                        cmd.Parameters.Add("CODLINEA", OracleDbType.Varchar2, codLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();
                        List<SublineaResponseDetalle> resultDetalle = new List<SublineaResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new SublineaResponseDetalle
                            {
                                LineaCodigo = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                SublineaCodigo = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                SublineaDescripcion = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2)
                            });

                        }
                        result.Sublinea = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Listado Almacen
        public async Task<AlmacenResponse> ListarAlmacen()
        {
            AlmacenResponse result = new AlmacenResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarAlmacenC}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();
                        List<AlmacenResponseDetalle> resultDetalle = new List<AlmacenResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new AlmacenResponseDetalle
                            {

                                almacenSerie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                almacenNombre = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1)
                            });
                            
                        }
                        result.Almacen = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Pendientes por Ubicar
        public async Task<MateriaPrimaResponse> ListarMateriaPrima(MateriaPrimaRequest materiaPrimaRequest)
        {
            MateriaPrimaResponse result = new MateriaPrimaResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarMateriaPrima}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, materiaPrimaRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, materiaPrimaRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, materiaPrimaRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Varchar2, materiaPrimaRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Varchar2, materiaPrimaRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, materiaPrimaRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, materiaPrimaRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, materiaPrimaRequest.PeriodoMes, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, materiaPrimaRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("CANTIDAD", OracleDbType.Int32, materiaPrimaRequest.CantidadPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("PAGINA", OracleDbType.Int32, materiaPrimaRequest.NumeroPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDERCOLUMN", OracleDbType.Int32, materiaPrimaRequest.ColumnaOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("DIRECTION", OracleDbType.Varchar2, materiaPrimaRequest.DireccionOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        Int64 totalRegistros = 0;
                        List<MateriaPrimaResponseDetalle> resultDetalle = new List<MateriaPrimaResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new MateriaPrimaResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                almacen_serie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobi_serie = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                bobi_codigo = await reader.IsDBNullAsync(2) ? 0 : reader.GetInt32(2),
                                ubi_almacen_serie = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                ubi_subalmnum = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                ubifisi_codigo = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                bobi_peso = await reader.IsDBNullAsync(6) ? 0 : reader.GetDouble(6),
                                bobi_peso_stock = await reader.IsDBNullAsync(7) ? 0 : reader.GetDouble(7),
                                mitem_codigo = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                item_descripcio = await reader.IsDBNullAsync(9) ? string.Empty : reader.GetString(9),
                                unidad_codigo = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                origen_descripcion = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                linea_descripcion = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                sublinea_descripcion = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                bobi_fecha_ingreso = await reader.IsDBNullAsync(14) ? string.Empty : reader.GetString(14),
                                flag = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                hoia_secuencial = await reader.IsDBNullAsync(16) ? string.Empty : reader.GetString(16),
                                trans_descripcion = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                usu_ult_modif = await reader.IsDBNullAsync(18) ? string.Empty : reader.GetString(18),
                                bobi_fec_ult_modif = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                ubic_orig = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                bobina_inventariada = await reader.IsDBNullAsync(21) ? string.Empty : reader.GetString(21),
                                bobi_fec_leida = await reader.IsDBNullAsync(22) ? string.Empty : reader.GetString(22),
                                bca_codigo = await reader.IsDBNullAsync(23) ? 0 : reader.GetInt32(23),
                                bobi_observaciones = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                ancho = await reader.IsDBNullAsync(25) ? 0 : reader.GetDouble(25),
                                espesor = await reader.IsDBNullAsync(26) ? 0 : reader.GetDouble(26),
                                bobi_fecha_salida = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27),
                                fecha_ingreso_orden = await reader.IsDBNullAsync(28) ? string.Empty : reader.GetString(28),
                                fecha_ult_orden = await reader.IsDBNullAsync(29) ? string.Empty : reader.GetString(29),
                                fecha_leida_orden = await reader.IsDBNullAsync(30) ? string.Empty : reader.GetString(30),
                                fecha_salida_orden = await reader.IsDBNullAsync(31) ? string.Empty : reader.GetString(31)
                            });
                            totalRegistros = await reader.IsDBNullAsync(32) ? 0 : reader.GetInt64(32);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.MateriaPrima = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<ProductosEnProcesoResponse> ListarProductosEnProceso(ProductosEnProcesoRequest productosEnProcesoRequest)
        {
            ProductosEnProcesoResponse result = new ProductosEnProcesoResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarProductosEnProceso}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, productosEnProcesoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, productosEnProcesoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, productosEnProcesoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Varchar2, productosEnProcesoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Varchar2, productosEnProcesoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, productosEnProcesoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, productosEnProcesoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, productosEnProcesoRequest.PeriodoMes, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, productosEnProcesoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("CANTIDAD", OracleDbType.Int32, productosEnProcesoRequest.CantidadPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("PAGINA", OracleDbType.Int32, productosEnProcesoRequest.NumeroPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDERCOLUMN", OracleDbType.Int32, productosEnProcesoRequest.ColumnaOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("DIRECTION", OracleDbType.Varchar2, productosEnProcesoRequest.DireccionOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        Int64 totalRegistros = 0;
                        List<ProductosEnProcesoResponseDetalle> resultDetalle = new List<ProductosEnProcesoResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new ProductosEnProcesoResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                almacen_serie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobi_codigo = await reader.IsDBNullAsync(1) ? 0 : reader.GetInt32(1),
                                bobi_serie = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                mitem_codigo = await reader.IsDBNullAsync(3) ? 0 : reader.GetInt32(3),
                                bobi_peso = await reader.IsDBNullAsync(4) ? 0 : reader.GetDouble(4),
                                unidad_codigo  = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                bobina_longitud = await reader.IsDBNullAsync(6) ? 0 : reader.GetDouble(6),
                                bobi_fecha_ingreso = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                bobina_peso_bruto = await reader.IsDBNullAsync(8) ? 0 : reader.GetDouble(8),
                                bobina_inventariada = await reader.IsDBNullAsync(9) ? string.Empty : reader.GetString(9),
                                hproc_secuencial = await reader.IsDBNullAsync(10) ? 0 : reader.GetInt32(10),
                                condicion_codigo = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                hord_trab_secuencial = await reader.IsDBNullAsync(12) ? 0 : reader.GetInt32(12),
                                proceso_codigo = await reader.IsDBNullAsync(13) ? 0 : reader.GetInt32(13),
                                maquina_codigo = await reader.IsDBNullAsync(14) ? 0 : reader.GetInt32(14),
                                alm_serie_transfer = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                dmot_codigo = await reader.IsDBNullAsync(16) ? string.Empty : reader.GetString(16),
                                MOTIVO2 = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                mot_devolucion = await reader.IsDBNullAsync(18) ? string.Empty : reader.GetString(18),
                                item_descripcio = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                unidad_equivalente = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                cantidad_equivalente = await reader.IsDBNullAsync(21) ? 0 : reader.GetInt32(21),
                                planta_serie = await reader.IsDBNullAsync(22) ? string.Empty : reader.GetString(22),
                                codigo_transaccion = await reader.IsDBNullAsync(23) ? string.Empty : reader.GetString(23),
                                causa_descripcion = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                hped_numero = await reader.IsDBNullAsync(25) ? 0 : reader.GetInt32(25),
                                situacion = await reader.IsDBNullAsync(26) ? 0 : reader.GetInt32(26),
                                vendedor_nombre = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27),
                                hproc_fecha_grab = await reader.IsDBNullAsync(28) ? string.Empty : reader.GetString(28),
                                ubifisi_codigo = await reader.IsDBNullAsync(29) ? string.Empty : reader.GetString(29),
                                bobi_fec_prod = await reader.IsDBNullAsync(30) ? string.Empty : reader.GetString(30),
                                cod_naturaleza = await reader.IsDBNullAsync(31) ? string.Empty : reader.GetString(31),
                                bobi_fec_leida = await reader.IsDBNullAsync(32) ? string.Empty : reader.GetString(32),
                                fecha_ingreso_orden = await reader.IsDBNullAsync(33) ? string.Empty : reader.GetString(33),
                                fecha_hproc_orden = await reader.IsDBNullAsync(34) ? string.Empty : reader.GetString(34),
                                fecha_prod_orden = await reader.IsDBNullAsync(35) ? string.Empty : reader.GetString(35),
                                fecha_leida_orden = await reader.IsDBNullAsync(36) ? string.Empty : reader.GetString(36)
                            });
                            totalRegistros = await reader.IsDBNullAsync(37) ? 0 : reader.GetInt64(37);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.ProductosEnProceso = resultDetalle.AsQueryable();
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<ProductoTerminadoResponse> ListarProductosTerminados(ProductoTerminadoRequest productoTerminadoRequest)
        {
            ProductoTerminadoResponse result = new ProductoTerminadoResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarProductosTerminados}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";

                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, productoTerminadoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, productoTerminadoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, productoTerminadoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Varchar2, productoTerminadoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Varchar2, productoTerminadoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, productoTerminadoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, productoTerminadoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, productoTerminadoRequest.PeriodoMes, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, productoTerminadoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("CANTIDAD", OracleDbType.Int32, productoTerminadoRequest.CantidadPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("PAGINA", OracleDbType.Int32, productoTerminadoRequest.NumeroPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDERCOLUMN", OracleDbType.Int32, productoTerminadoRequest.ColumnaOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("DIRECTION", OracleDbType.Varchar2, productoTerminadoRequest.DireccionOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();
                        //Int64 totalRegistros = 0;
                        List<ProductoTerminadoResponseDetalle> resultDetalle = new List<ProductoTerminadoResponseDetalle>();
                        
                        while (await reader.ReadAsync())
                        {
                            
                                resultDetalle.Add(new ProductoTerminadoResponseDetalle
                                {
                                    id = Guid.NewGuid().ToString(),
                                    tipo = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                    desc_tipo = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                    bobina_inventariada = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                    bobi_serie = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                    bobi_codigo = await reader.IsDBNullAsync(4) ? 0 : reader.GetInt32(4),
                                    bobi_peso = await reader.IsDBNullAsync(5) ? 0 : reader.GetDouble(5),
                                    bobina_peso_bruto = await reader.IsDBNullAsync(6) ? 0 : reader.GetDouble(6),
                                    bobina_unidad_codigo = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                    bobina_longitud = await reader.IsDBNullAsync(8) ? 0 : reader.GetDouble(8),
                                    mitem_codigo = await reader.IsDBNullAsync(9) ? 0 : reader.GetInt32(9),
                                    unidad_codigo = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                    almacen_serie = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                    item_descripcio = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                    planta_serie = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                    hord_trab_secuencial = await reader.IsDBNullAsync(14) ? 0 : reader.GetInt32(14),
                                    descripcion_tamano = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                    mitem_gramaje = await reader.IsDBNullAsync(16) ? 0 : reader.GetInt32(16),
                                    unidad_equivalente = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                    cantidad_equivalente = await reader.IsDBNullAsync(18) ? 0 : reader.GetInt32(18),
                                    pedido = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                    cliente = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                    sucursal_descripcion = await reader.IsDBNullAsync(21) ? string.Empty : reader.GetString(21),
                                    hproc_secuencial = await reader.IsDBNullAsync(22) ? 0 : reader.GetInt32(22),
                                    condicion_codigo = await reader.IsDBNullAsync(23) ? string.Empty : reader.GetString(23),
                                    condicion_descripcion = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                    hproc_fecha_grab = await reader.IsDBNullAsync(25) ? string.Empty : reader.GetString(25),
                                    ubifisi_codigo = await reader.IsDBNullAsync(26) ? string.Empty : reader.GetString(26),
                                    bobi_fec_prod = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27),
                                    fecha_hproc_orden = await reader.IsDBNullAsync(28) ? string.Empty : reader.GetString(28),
                                    fecha_prod_orden = await reader.IsDBNullAsync(29) ? string.Empty : reader.GetString(29)
                                });
                            //totalRegistros = await reader.IsDBNullAsync(30) ? 0 : reader.GetInt64(30);
                        }
                        
                        //result.TotalRegistros = totalRegistros;
                        result.ProductosTerminados = resultDetalle.AsQueryable();
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Bobina con PNC
        public async Task<BobinaConPNCResponse> ListarBobinaConPNC(BobinaConPNCRequest bobinaConPNCRequest)
        {
            BobinaConPNCResponse result = new BobinaConPNCResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarBobinaConPNC}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, bobinaConPNCRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, bobinaConPNCRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, bobinaConPNCRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Varchar2, bobinaConPNCRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Varchar2, bobinaConPNCRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, bobinaConPNCRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, bobinaConPNCRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, bobinaConPNCRequest.PeriodoMes, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, bobinaConPNCRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("CANTIDAD", OracleDbType.Int32, bobinaConPNCRequest.CantidadPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("PAGINA", OracleDbType.Int32, bobinaConPNCRequest.NumeroPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDERCOLUMN", OracleDbType.Int32, bobinaConPNCRequest.ColumnaOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("DIRECTION", OracleDbType.Varchar2, bobinaConPNCRequest.DireccionOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        Int64 totalRegistros = 0;
                        List<BobinaConPNCResponseDetalle> resultDetalle = new List<BobinaConPNCResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new BobinaConPNCResponseDetalle
                            {

                                id = Guid.NewGuid().ToString(),
                                almacen_serie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobi_serie = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                bobi_codigo = await reader.IsDBNullAsync(2) ? 0 : reader.GetInt32(2),
                                bobi_peso = await reader.IsDBNullAsync(3) ? 0 : reader.GetDouble(3),
                                bobi_peso_stock = await reader.IsDBNullAsync(4) ? 0 : reader.GetDouble(4),
                                hoia_fecha_oia = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                hoia_secuencial = await reader.IsDBNullAsync(6) ? 0 : reader.GetInt32(6),
                                codigo_transaccion = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                porden_int_panasa = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                mitem_codigo = await reader.IsDBNullAsync(9) ? 0 : reader.GetInt32(9),
                                unidad_codigo = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                bobina_inventariada = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                desc_proveedor = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                num_compra = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                bobi_estado = await reader.IsDBNullAsync(14) ? string.Empty : reader.GetString(14),
                                cc_result = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                sec_pnc = await reader.IsDBNullAsync(16) ? 0 : reader.GetInt32(16),
                                sec_pnc_tiempo = await reader.IsDBNullAsync(17) ? 0 : reader.GetInt32(17),
                                ubi_almacen_serie = await reader.IsDBNullAsync(18) ? string.Empty : reader.GetString(18),
                                ubi_subalmnum = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                ubifisi_codigo = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                bp_lote = await reader.IsDBNullAsync(21) ? string.Empty : reader.GetString(21),
                                hcc_fecha_muestra = await reader.IsDBNullAsync(22) ? string.Empty : reader.GetString(22),
                                fecha_emusa = await reader.IsDBNullAsync(23) ? string.Empty : reader.GetString(23),
                                fecha_hoia_orden = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                fecha_emusa_orden = await reader.IsDBNullAsync(25) ? string.Empty : reader.GetString(25),
                                fecha_hcc_orden = await reader.IsDBNullAsync(26) ? string.Empty : reader.GetString(26)
                            });
                            totalRegistros = await reader.IsDBNullAsync(27) ? 0 : reader.GetInt64(27);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.BobinaConPNC = resultDetalle.AsQueryable();
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Kardex Bobina
        public async Task<KardexBobinaResponse> ListarKardexBobina(KardexBobinaRequest kardexBobinaRequest)
        {
            KardexBobinaResponse result = new KardexBobinaResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarKardexBobina}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, kardexBobinaRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, kardexBobinaRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, kardexBobinaRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Varchar2, kardexBobinaRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Varchar2, kardexBobinaRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, kardexBobinaRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, kardexBobinaRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, kardexBobinaRequest.PeriodoMes, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, kardexBobinaRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("ESTADO", OracleDbType.Varchar2, kardexBobinaRequest.Estado, ParameterDirection.Input);
                        cmd.Parameters.Add("CANTIDAD", OracleDbType.Int32, kardexBobinaRequest.CantidadPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("PAGINA", OracleDbType.Int32, kardexBobinaRequest.NumeroPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDERCOLUMN", OracleDbType.Int32, kardexBobinaRequest.ColumnaOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("DIRECTION", OracleDbType.Varchar2, kardexBobinaRequest.DireccionOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        Int64 totalRegistros = 0;
                        List<KardexBobinaResponseDetalle> resultDetalle = new List<KardexBobinaResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new KardexBobinaResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                fechaGrabacion = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobiCodigo = await reader.IsDBNullAsync(1) ? 0 : reader.GetInt32(1),
                                bobiSerie = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                ubifisiCodigo = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                ubiAlmacenSerie = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                unidadCodigo = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                usuUltModif = await reader.IsDBNullAsync(6) ? string.Empty : reader.GetString(6),
                                bobiPeso = await reader.IsDBNullAsync(7) ? 0 : reader.GetDouble(7),
                                bobiPesoStock = await reader.IsDBNullAsync(8) ? 0 : reader.GetDouble(8),
                                mitemCodigo = await reader.IsDBNullAsync(9) ? 0 : reader.GetInt32(9),
                                descripcion = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                almacenSerie = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                bobiEstado = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                linea = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                sublinea = await reader.IsDBNullAsync(14) ? string.Empty : reader.GetString(14),
                                fechaOrden = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15)

                            });
                            totalRegistros = await reader.IsDBNullAsync(16) ? 0 : reader.GetInt64(16);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.KardexBobina = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Desarrollo de Inventario
        public async Task<MateriaPrimaResponse> ListarMateriaPrimaD(MateriaPrimaRequest materiaPrimaRequest)
        {
            MateriaPrimaResponse result = new MateriaPrimaResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarMateriaPrimaD}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, materiaPrimaRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, materiaPrimaRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, materiaPrimaRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Varchar2, materiaPrimaRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Varchar2, materiaPrimaRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, materiaPrimaRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, materiaPrimaRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, materiaPrimaRequest.PeriodoMes, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, materiaPrimaRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("CANTIDAD", OracleDbType.Int32, materiaPrimaRequest.CantidadPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("PAGINA", OracleDbType.Int32, materiaPrimaRequest.NumeroPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDERCOLUMN", OracleDbType.Int32, materiaPrimaRequest.ColumnaOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("DIRECTION", OracleDbType.Varchar2, materiaPrimaRequest.DireccionOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        Int64 totalRegistros = 0;
                        List<MateriaPrimaResponseDetalle> resultDetalle = new List<MateriaPrimaResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new MateriaPrimaResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                almacen_serie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobi_serie = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                bobi_codigo = await reader.IsDBNullAsync(2) ? 0 : reader.GetInt32(2),
                                ubi_almacen_serie = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                ubi_subalmnum = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                ubifisi_codigo = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                bobi_peso =  await reader.IsDBNullAsync(6) ? 0 : reader.GetDouble(6),
                                bobi_peso_stock = await reader.IsDBNullAsync(7) ? 0 : reader.GetDouble(7),
                                mitem_codigo = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                item_descripcio = await reader.IsDBNullAsync(9) ? string.Empty : reader.GetString(9),
                                unidad_codigo = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                origen_descripcion = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                linea_descripcion = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                sublinea_descripcion = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                bobi_fecha_ingreso = await reader.IsDBNullAsync(14) ? string.Empty : reader.GetString(14),
                                flag = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                hoia_secuencial = await reader.IsDBNullAsync(16) ? string.Empty : reader.GetString(16),
                                trans_descripcion = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                usu_ult_modif = await reader.IsDBNullAsync(18) ? string.Empty : reader.GetString(18),
                                bobi_fec_ult_modif = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                ubic_orig = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                bobina_inventariada = await reader.IsDBNullAsync(21) ? string.Empty : reader.GetString(21),
                                bobi_fec_leida = await reader.IsDBNullAsync(22) ? string.Empty : reader.GetString(22),
                                bca_codigo = await reader.IsDBNullAsync(23) ? 0 : reader.GetInt32(23),
                                bobi_observaciones = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                ancho = await reader.IsDBNullAsync(25) ? 0 : reader.GetDouble(25),
                                espesor = await reader.IsDBNullAsync(26) ? 0 : reader.GetDouble(26),
                                bobi_fecha_salida = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27),
                                fecha_ingreso_orden = await reader.IsDBNullAsync(28) ? string.Empty : reader.GetString(28),
                                fecha_ult_orden = await reader.IsDBNullAsync(29) ? string.Empty : reader.GetString(29),
                                fecha_leida_orden = await reader.IsDBNullAsync(30) ? string.Empty : reader.GetString(30),
                                fecha_salida_orden = await reader.IsDBNullAsync(31) ? string.Empty : reader.GetString(31)
                            });
                            totalRegistros = await reader.IsDBNullAsync(32) ? 0 : reader.GetInt64(32);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.MateriaPrima = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<ProductosEnProcesoResponse> ListarProductosEnProcesoD(ProductosEnProcesoRequest productosEnProcesoRequest)
        {
            ProductosEnProcesoResponse result = new ProductosEnProcesoResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarProductosEnProcesoD}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, productosEnProcesoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, productosEnProcesoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, productosEnProcesoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Varchar2, productosEnProcesoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Varchar2, productosEnProcesoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, productosEnProcesoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, productosEnProcesoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, productosEnProcesoRequest.PeriodoMes, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, productosEnProcesoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("CANTIDAD", OracleDbType.Int32, productosEnProcesoRequest.CantidadPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("PAGINA", OracleDbType.Int32, productosEnProcesoRequest.NumeroPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDERCOLUMN", OracleDbType.Int32, productosEnProcesoRequest.ColumnaOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("DIRECTION", OracleDbType.Varchar2, productosEnProcesoRequest.DireccionOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        Int64 totalRegistros = 0;
                        List<ProductosEnProcesoResponseDetalle> resultDetalle = new List<ProductosEnProcesoResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new ProductosEnProcesoResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                almacen_serie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobi_codigo = await reader.IsDBNullAsync(1) ? 0 : reader.GetInt32(1),
                                bobi_serie = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                mitem_codigo = await reader.IsDBNullAsync(3) ? 0 : reader.GetInt32(3),
                                bobi_peso = await reader.IsDBNullAsync(4) ? 0 : reader.GetDouble(4),
                                unidad_codigo = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                bobina_longitud = await reader.IsDBNullAsync(6) ? 0 : reader.GetDouble(6),
                                bobi_fecha_ingreso = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                bobina_peso_bruto = await reader.IsDBNullAsync(8) ? 0 : reader.GetDouble(8),
                                bobina_inventariada = await reader.IsDBNullAsync(9) ? string.Empty : reader.GetString(9),
                                hproc_secuencial = await reader.IsDBNullAsync(10) ? 0 : reader.GetInt32(10),
                                condicion_codigo = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                hord_trab_secuencial = await reader.IsDBNullAsync(12) ? 0 : reader.GetInt32(12),
                                proceso_codigo = await reader.IsDBNullAsync(13) ? 0 : reader.GetInt32(13),
                                maquina_codigo = await reader.IsDBNullAsync(14) ? 0 : reader.GetInt32(14),
                                alm_serie_transfer = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                dmot_codigo = await reader.IsDBNullAsync(16) ? string.Empty : reader.GetString(16),
                                MOTIVO2 = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                mot_devolucion = await reader.IsDBNullAsync(18) ? string.Empty : reader.GetString(18),
                                item_descripcio = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                unidad_equivalente = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                cantidad_equivalente = await reader.IsDBNullAsync(21) ? 0 : reader.GetInt32(21),
                                planta_serie = await reader.IsDBNullAsync(22) ? string.Empty : reader.GetString(22),
                                codigo_transaccion = await reader.IsDBNullAsync(23) ? string.Empty : reader.GetString(23),
                                causa_descripcion = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                hped_numero = await reader.IsDBNullAsync(25) ? 0 : reader.GetInt32(25),
                                situacion = await reader.IsDBNullAsync(26) ? 0 : reader.GetInt32(26),
                                vendedor_nombre = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27),
                                hproc_fecha_grab = await reader.IsDBNullAsync(28) ? string.Empty : reader.GetString(28),
                                ubifisi_codigo = await reader.IsDBNullAsync(29) ? string.Empty : reader.GetString(29),
                                bobi_fec_prod = await reader.IsDBNullAsync(30) ? string.Empty : reader.GetString(30),
                                cod_naturaleza = await reader.IsDBNullAsync(31) ? string.Empty : reader.GetString(31),
                                bobi_fec_leida = await reader.IsDBNullAsync(32) ? string.Empty : reader.GetString(32),
                                fecha_ingreso_orden = await reader.IsDBNullAsync(33) ? string.Empty : reader.GetString(33),
                                fecha_hproc_orden = await reader.IsDBNullAsync(34) ? string.Empty : reader.GetString(34),
                                fecha_prod_orden = await reader.IsDBNullAsync(35) ? string.Empty : reader.GetString(35),
                                fecha_leida_orden = await reader.IsDBNullAsync(36) ? string.Empty : reader.GetString(36)
                            });
                            totalRegistros = await reader.IsDBNullAsync(37) ? 0 : reader.GetInt64(37);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.ProductosEnProceso = resultDetalle.AsQueryable();
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<ProductoTerminadoResponse> ListarProductosTerminadosD(ProductoTerminadoRequest productoTerminadoRequest)
        {
            ProductoTerminadoResponse result = new ProductoTerminadoResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarProductosTerminadosD}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, productoTerminadoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, productoTerminadoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, productoTerminadoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Varchar2, productoTerminadoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Varchar2, productoTerminadoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, productoTerminadoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, productoTerminadoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, productoTerminadoRequest.PeriodoMes, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, productoTerminadoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("CANTIDAD", OracleDbType.Int32, productoTerminadoRequest.CantidadPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("PAGINA", OracleDbType.Int32, productoTerminadoRequest.NumeroPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDERCOLUMN", OracleDbType.Int32, productoTerminadoRequest.ColumnaOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("DIRECTION", OracleDbType.Varchar2, productoTerminadoRequest.DireccionOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        //Int64 totalRegistros = 0;
                        List<ProductoTerminadoResponseDetalle> resultDetalle = new List<ProductoTerminadoResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new ProductoTerminadoResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                tipo = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                desc_tipo = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                bobina_inventariada = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                bobi_serie = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                bobi_codigo = await reader.IsDBNullAsync(4) ? 0 : reader.GetInt32(4),
                                bobi_peso = await reader.IsDBNullAsync(5) ? 0 : reader.GetDouble(5),
                                bobina_peso_bruto = await reader.IsDBNullAsync(6) ? 0 : reader.GetDouble(6),
                                bobina_unidad_codigo = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                bobina_longitud = await reader.IsDBNullAsync(8) ? 0 : reader.GetDouble(8),
                                mitem_codigo = await reader.IsDBNullAsync(9) ? 0 : reader.GetInt32(9),
                                unidad_codigo = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                almacen_serie = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                item_descripcio = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                planta_serie = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                hord_trab_secuencial = await reader.IsDBNullAsync(14) ? 0 : reader.GetInt32(14),
                                descripcion_tamano = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                mitem_gramaje = await reader.IsDBNullAsync(16) ? 0 : reader.GetInt32(16),
                                unidad_equivalente = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                cantidad_equivalente = await reader.IsDBNullAsync(18) ? 0 : reader.GetInt32(18),
                                pedido = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                cliente = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                sucursal_descripcion = await reader.IsDBNullAsync(21) ? string.Empty : reader.GetString(21),
                                hproc_secuencial = await reader.IsDBNullAsync(22) ? 0 : reader.GetInt32(22),
                                condicion_codigo = await reader.IsDBNullAsync(23) ? string.Empty : reader.GetString(23),
                                condicion_descripcion = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                hproc_fecha_grab = await reader.IsDBNullAsync(25) ? string.Empty : reader.GetString(25),
                                ubifisi_codigo = await reader.IsDBNullAsync(26) ? string.Empty : reader.GetString(26),
                                bobi_fec_prod = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27),
                                fecha_hproc_orden = await reader.IsDBNullAsync(28) ? string.Empty : reader.GetString(28),
                                fecha_prod_orden = await reader.IsDBNullAsync(29) ? string.Empty : reader.GetString(29)
                            });
                           // totalRegistros = await reader.IsDBNullAsync(30) ? 0 : reader.GetInt64(30);
                        }
                        //result.TotalRegistros = totalRegistros;
                        result.ProductosTerminados = resultDetalle.AsQueryable();
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Proceso de Produccion
        public async Task<ProcesoDeProduccionResponse> ListarProcesoDeProduccion(ProcesoDeProduccionRequest procesoDeProduccionRequest)
        {
            ProcesoDeProduccionResponse result = new ProcesoDeProduccionResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarProcesoDeProduccion}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, procesoDeProduccionRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, procesoDeProduccionRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, procesoDeProduccionRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Int32, procesoDeProduccionRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Int32, procesoDeProduccionRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDENTRABAJO", OracleDbType.Varchar2, procesoDeProduccionRequest.OrdenTrabajo, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, procesoDeProduccionRequest.PeriodoMes, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, procesoDeProduccionRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("CANTIDAD", OracleDbType.Int32, procesoDeProduccionRequest.CantidadPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("PAGINA", OracleDbType.Int32, procesoDeProduccionRequest.NumeroPagina, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDERCOLUMN", OracleDbType.Int32, procesoDeProduccionRequest.ColumnaOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("DIRECTION", OracleDbType.Varchar2, procesoDeProduccionRequest.DireccionOrdenamiento, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        Int64 totalRegistros = 0;
                        List<ProcesoDeProduccionResponseDetalle> resultDetalle = new List<ProcesoDeProduccionResponseDetalle>();

                        while (await reader.ReadAsync())
                        {
                            var item = new ProcesoDeProduccionResponseDetalle();
                            resultDetalle.Add(new ProcesoDeProduccionResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                hproc_fecha_grab = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                proceso_codigo = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                maquina_codigo = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                unidad_equivalente = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                cantidad_equivalente = await reader.IsDBNullAsync(4) ? 0 : reader.GetInt32(4),
                                planta_serie = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                hord_trab_secuencial = await reader.IsDBNullAsync(6) ? string.Empty : reader.GetString(6),
                                maquina_descripcion = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                proceso_descripcion = await reader.IsDBNullAsync(8) ? string.Empty : reader.GetString(8),
                                eproc_bobi_peso = await reader.IsDBNullAsync(9) ? 0 : reader.GetInt32(9),
                                fecha_hproc_orden = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10)
                            });
                            
                            totalRegistros = await reader.IsDBNullAsync(11) ? 0 : reader.GetInt64(11);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.ProcesoProduccion = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        #region EXPORTAR REPORTE

        //Pendientes por Ubicar
        public async Task<MateriaPrimaResponse> ListarMateriaPrimaExport(ReporteGenericoRequest reporteGenericoRequest)
        {
            MateriaPrimaResponse result = new MateriaPrimaResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarMateriaPrimaExport}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";

                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, reporteGenericoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, reporteGenericoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, reporteGenericoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Int32, reporteGenericoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Int32, reporteGenericoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, reporteGenericoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, reporteGenericoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        List<MateriaPrimaResponseDetalle> resultDetalle = new List<MateriaPrimaResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new MateriaPrimaResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                almacen_serie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobi_serie = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                bobi_codigo = await reader.IsDBNullAsync(2) ? 0 : reader.GetInt32(2),
                                ubi_almacen_serie = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                ubi_subalmnum = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                ubifisi_codigo = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                bobi_peso = await reader.IsDBNullAsync(6) ? 0 : reader.GetInt32(6),
                                bobi_peso_stock = await reader.IsDBNullAsync(7) ? 0 : reader.GetInt32(7),
                                mitem_codigo = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                item_descripcio = await reader.IsDBNullAsync(9) ? string.Empty : reader.GetString(9),
                                unidad_codigo = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                origen_descripcion = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                linea_descripcion = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                sublinea_descripcion = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                bobi_fecha_ingreso = await reader.IsDBNullAsync(14) ? string.Empty : reader.GetString(14),
                                flag = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                hoia_secuencial = await reader.IsDBNullAsync(16) ? string.Empty : reader.GetString(16),
                                trans_descripcion = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                usu_ult_modif = await reader.IsDBNullAsync(18) ? string.Empty : reader.GetString(18),
                                bobi_fec_ult_modif = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                ubic_orig = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                bobina_inventariada = await reader.IsDBNullAsync(21) ? string.Empty : reader.GetString(21),
                                bobi_fec_leida = await reader.IsDBNullAsync(22) ? string.Empty : reader.GetString(22),
                                bca_codigo = await reader.IsDBNullAsync(23) ? 0 : reader.GetInt32(23),
                                bobi_observaciones = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                ancho = await reader.IsDBNullAsync(25) ? 0 : reader.GetInt32(25),
                                espesor = await reader.IsDBNullAsync(26) ? 0 : reader.GetInt32(26),
                                bobi_fecha_salida = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27)
                            });
                        }
                        result.MateriaPrima = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<ProductosEnProcesoResponse> ListarProductosEnProcesoExport(ReporteGenericoRequest reporteGenericoRequest)
        {
            ProductosEnProcesoResponse result = new ProductosEnProcesoResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarProductosEnProcesoExport}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, reporteGenericoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, reporteGenericoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, reporteGenericoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Int32, reporteGenericoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Int32, reporteGenericoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, reporteGenericoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, reporteGenericoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        List<ProductosEnProcesoResponseDetalle> resultDetalle = new List<ProductosEnProcesoResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new ProductosEnProcesoResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                almacen_serie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobi_codigo = await reader.IsDBNullAsync(1) ? 0 : reader.GetInt32(1),
                                bobi_serie = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                mitem_codigo = await reader.IsDBNullAsync(3) ? 0 : reader.GetInt32(3),
                                bobi_peso = await reader.IsDBNullAsync(4) ? 0 : reader.GetInt32(4),
                                unidad_codigo = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                bobina_longitud = await reader.IsDBNullAsync(6) ? 0 : reader.GetInt32(6),
                                bobi_fecha_ingreso = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                bobina_peso_bruto = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                bobina_inventariada = await reader.IsDBNullAsync(9) ? string.Empty : reader.GetString(9),
                                hproc_secuencial = await reader.IsDBNullAsync(10) ? 0 : reader.GetInt32(10),
                                condicion_codigo = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                hord_trab_secuencial = await reader.IsDBNullAsync(12) ? 0 : reader.GetInt32(12),
                                proceso_codigo = await reader.IsDBNullAsync(13) ? 0 : reader.GetInt32(13),
                                maquina_codigo = await reader.IsDBNullAsync(14) ? 0 : reader.GetInt32(14),
                                alm_serie_transfer = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                dmot_codigo = await reader.IsDBNullAsync(16) ? string.Empty : reader.GetString(16),
                                MOTIVO2 = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                mot_devolucion = await reader.IsDBNullAsync(18) ? string.Empty : reader.GetString(18),
                                item_descripcio = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                unidad_equivalente = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                cantidad_equivalente = await reader.IsDBNullAsync(21) ? 0 : reader.GetInt32(21),
                                planta_serie = await reader.IsDBNullAsync(22) ? string.Empty : reader.GetString(22),
                                codigo_transaccion = await reader.IsDBNullAsync(23) ? string.Empty : reader.GetString(23),
                                causa_descripcion = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                hped_numero = await reader.IsDBNullAsync(25) ? 0 : reader.GetInt32(25),
                                situacion = await reader.IsDBNullAsync(26) ? 0 : reader.GetInt32(26),
                                vendedor_nombre = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27),
                                hproc_fecha_grab = await reader.IsDBNullAsync(28) ? string.Empty : reader.GetString(28),
                                ubifisi_codigo = await reader.IsDBNullAsync(29) ? string.Empty : reader.GetString(29),
                                bobi_fec_prod = await reader.IsDBNullAsync(30) ? string.Empty : reader.GetString(30),
                                cod_naturaleza = await reader.IsDBNullAsync(31) ? string.Empty : reader.GetString(31),
                                bobi_fec_leida = await reader.IsDBNullAsync(32) ? string.Empty : reader.GetString(32)
                            });
                        }
                        result.ProductosEnProceso = resultDetalle.AsQueryable();
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<ProductoTerminadoResponse> ListarProductosTerminadosExport(ReporteGenericoRequest reporteGenericoRequest)
        {
            ProductoTerminadoResponse result = new ProductoTerminadoResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarProductosTerminadosExport}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";

                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, reporteGenericoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, reporteGenericoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, reporteGenericoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Int32, reporteGenericoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Int32, reporteGenericoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, reporteGenericoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, reporteGenericoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();
                        Int64 totalRegistros = 0;
                        List<ProductoTerminadoResponseDetalle> resultDetalle = new List<ProductoTerminadoResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new ProductoTerminadoResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                tipo = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                desc_tipo = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                bobina_inventariada = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                bobi_serie = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                bobi_codigo = await reader.IsDBNullAsync(4) ? 0 : reader.GetInt32(4),
                                bobi_peso = await reader.IsDBNullAsync(5) ? 0 : reader.GetInt32(5),
                                bobina_peso_bruto = await reader.IsDBNullAsync(6) ? 0 : reader.GetInt32(6),
                                bobina_unidad_codigo = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                bobina_longitud = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                mitem_codigo = await reader.IsDBNullAsync(9) ? 0 : reader.GetInt32(9),
                                unidad_codigo = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                almacen_serie = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                item_descripcio = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                planta_serie = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                hord_trab_secuencial = await reader.IsDBNullAsync(14) ? 0 : reader.GetInt32(14),
                                descripcion_tamano = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                mitem_gramaje = await reader.IsDBNullAsync(16) ? 0 : reader.GetInt32(16),
                                unidad_equivalente = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                cantidad_equivalente = await reader.IsDBNullAsync(18) ? 0 : reader.GetInt32(18),
                                pedido = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                cliente = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                sucursal_descripcion = await reader.IsDBNullAsync(21) ? string.Empty : reader.GetString(21),
                                hproc_secuencial = await reader.IsDBNullAsync(22) ? 0 : reader.GetInt32(22),
                                condicion_codigo = await reader.IsDBNullAsync(23) ? string.Empty : reader.GetString(23),
                                condicion_descripcion = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                hproc_fecha_grab = await reader.IsDBNullAsync(25) ? string.Empty : reader.GetString(25),
                                ubifisi_codigo = await reader.IsDBNullAsync(26) ? string.Empty : reader.GetString(26),
                                bobi_fec_prod = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27)
                            });
                            totalRegistros = await reader.IsDBNullAsync(28) ? 0 : reader.GetInt64(28);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.ProductosTerminados = resultDetalle.AsQueryable();
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Kardex Bobina
        public async Task<KardexBobinaResponse> ListarKardexBobinaExport(ReporteGenericoRequest reporteGenericoRequest)
        {
            KardexBobinaResponse result = new KardexBobinaResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarKardexBobinaExport}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, reporteGenericoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, reporteGenericoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, reporteGenericoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Int32, reporteGenericoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Int32, reporteGenericoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, reporteGenericoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, reporteGenericoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoMes, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        List<KardexBobinaResponseDetalle> resultDetalle = new List<KardexBobinaResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new KardexBobinaResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                fechaGrabacion = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobiCodigo = await reader.IsDBNullAsync(1) ? 0 : reader.GetInt32(1),
                                bobiSerie = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                ubifisiCodigo = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                ubiAlmacenSerie = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                unidadCodigo = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                usuUltModif = await reader.IsDBNullAsync(6) ? string.Empty : reader.GetString(6),
                                bobiPeso = await reader.IsDBNullAsync(7) ? 0 : reader.GetInt32(7),
                                bobiPesoStock = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                mitemCodigo = await reader.IsDBNullAsync(9) ? 0 : reader.GetInt32(9),
                                descripcion = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                almacenSerie = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                bobiEstado = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                linea = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                sublinea = await reader.IsDBNullAsync(14) ? string.Empty : reader.GetString(14)

                            });
                        }
                        result.KardexBobina = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Bobina con PNC
        public async Task<BobinaConPNCResponse> ListarBobinaConPNCExport(ReporteGenericoRequest reporteGenericoRequest)
        {
            BobinaConPNCResponse result = new BobinaConPNCResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarBobinaConPNCExport}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, reporteGenericoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, reporteGenericoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, reporteGenericoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Int32, reporteGenericoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Int32, reporteGenericoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, reporteGenericoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, reporteGenericoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        List<BobinaConPNCResponseDetalle> resultDetalle = new List<BobinaConPNCResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new BobinaConPNCResponseDetalle
                            {

                                id = Guid.NewGuid().ToString(),
                                almacen_serie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobi_serie = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                bobi_codigo = await reader.IsDBNullAsync(2) ? 0 : reader.GetInt32(2),
                                bobi_peso = await reader.IsDBNullAsync(3) ? 0 : reader.GetInt32(3),
                                bobi_peso_stock = await reader.IsDBNullAsync(4) ? 0 : reader.GetInt32(4),
                                hoia_fecha_oia = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                hoia_secuencial = await reader.IsDBNullAsync(6) ? 0 : reader.GetInt32(6),
                                codigo_transaccion = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                porden_int_panasa = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                mitem_codigo = await reader.IsDBNullAsync(9) ? 0 : reader.GetInt32(9),
                                unidad_codigo = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                bobina_inventariada = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                desc_proveedor = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                num_compra = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                bobi_estado = await reader.IsDBNullAsync(14) ? string.Empty : reader.GetString(14),
                                cc_result = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                sec_pnc = await reader.IsDBNullAsync(16) ? 0 : reader.GetInt32(16),
                                sec_pnc_tiempo = await reader.IsDBNullAsync(17) ? 0 : reader.GetInt32(17),
                                ubi_almacen_serie = await reader.IsDBNullAsync(18) ? string.Empty : reader.GetString(18),
                                ubi_subalmnum = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                ubifisi_codigo = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                bp_lote = await reader.IsDBNullAsync(21) ? string.Empty : reader.GetString(21),
                                hcc_fecha_muestra = await reader.IsDBNullAsync(22) ? string.Empty : reader.GetString(22),
                                fecha_emusa = await reader.IsDBNullAsync(23) ? string.Empty : reader.GetString(23)
                            });
                        }
                        result.BobinaConPNC = resultDetalle.AsQueryable();
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Desarrollo de Inventario
        public async Task<MateriaPrimaResponse> ListarMateriaPrimaDExport(ReporteGenericoRequest reporteGenericoRequest)
        {
            MateriaPrimaResponse result = new MateriaPrimaResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarMateriaPrimaExport}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, reporteGenericoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, reporteGenericoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, reporteGenericoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Int32, reporteGenericoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Int32, reporteGenericoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, reporteGenericoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, reporteGenericoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        List<MateriaPrimaResponseDetalle> resultDetalle = new List<MateriaPrimaResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new MateriaPrimaResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                almacen_serie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobi_serie = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                bobi_codigo = await reader.IsDBNullAsync(2) ? 0 : reader.GetInt32(2),
                                ubi_almacen_serie = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                ubi_subalmnum = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                ubifisi_codigo = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                bobi_peso = await reader.IsDBNullAsync(6) ? 0 : reader.GetInt32(6),
                                bobi_peso_stock = await reader.IsDBNullAsync(7) ? 0 : reader.GetInt32(7),
                                mitem_codigo = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                item_descripcio = await reader.IsDBNullAsync(9) ? string.Empty : reader.GetString(9),
                                unidad_codigo = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                origen_descripcion = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                linea_descripcion = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                sublinea_descripcion = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                bobi_fecha_ingreso = await reader.IsDBNullAsync(14) ? string.Empty : reader.GetString(14),
                                flag = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                hoia_secuencial = await reader.IsDBNullAsync(16) ? string.Empty : reader.GetString(16),
                                trans_descripcion = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                usu_ult_modif = await reader.IsDBNullAsync(18) ? string.Empty : reader.GetString(18),
                                bobi_fec_ult_modif = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                ubic_orig = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                bobina_inventariada = await reader.IsDBNullAsync(21) ? string.Empty : reader.GetString(21),
                                bobi_fec_leida = await reader.IsDBNullAsync(22) ? string.Empty : reader.GetString(22),
                                bca_codigo = await reader.IsDBNullAsync(23) ? 0 : reader.GetInt32(23),
                                bobi_observaciones = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                ancho = await reader.IsDBNullAsync(25) ? 0 : reader.GetInt32(25),
                                espesor = await reader.IsDBNullAsync(26) ? 0 : reader.GetInt32(26),
                                bobi_fecha_salida = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27)
                            });
                        }
                        result.MateriaPrima = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<ProductosEnProcesoResponse> ListarProductosEnProcesoDExport(ReporteGenericoRequest reporteGenericoRequest)
        {
            ProductosEnProcesoResponse result = new ProductosEnProcesoResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarProductosEnProcesoDExport}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, reporteGenericoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, reporteGenericoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, reporteGenericoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Int32, reporteGenericoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Int32, reporteGenericoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, reporteGenericoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, reporteGenericoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        List<ProductosEnProcesoResponseDetalle> resultDetalle = new List<ProductosEnProcesoResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new ProductosEnProcesoResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                almacen_serie = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                bobi_codigo = await reader.IsDBNullAsync(1) ? 0 : reader.GetInt32(1),
                                bobi_serie = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                mitem_codigo = await reader.IsDBNullAsync(3) ? 0 : reader.GetInt32(3),
                                bobi_peso = await reader.IsDBNullAsync(4) ? 0 : reader.GetInt32(4),
                                unidad_codigo = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                bobina_longitud = await reader.IsDBNullAsync(6) ? 0 : reader.GetInt32(6),
                                bobi_fecha_ingreso = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                bobina_peso_bruto = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                bobina_inventariada = await reader.IsDBNullAsync(9) ? string.Empty : reader.GetString(9),
                                hproc_secuencial = await reader.IsDBNullAsync(10) ? 0 : reader.GetInt32(10),
                                condicion_codigo = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                hord_trab_secuencial = await reader.IsDBNullAsync(12) ? 0 : reader.GetInt32(12),
                                proceso_codigo = await reader.IsDBNullAsync(13) ? 0 : reader.GetInt32(13),
                                maquina_codigo = await reader.IsDBNullAsync(14) ? 0 : reader.GetInt32(14),
                                alm_serie_transfer = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                dmot_codigo = await reader.IsDBNullAsync(16) ? string.Empty : reader.GetString(16),
                                MOTIVO2 = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                mot_devolucion = await reader.IsDBNullAsync(18) ? string.Empty : reader.GetString(18),
                                item_descripcio = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                unidad_equivalente = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                cantidad_equivalente = await reader.IsDBNullAsync(21) ? 0 : reader.GetInt32(21),
                                planta_serie = await reader.IsDBNullAsync(22) ? string.Empty : reader.GetString(22),
                                codigo_transaccion = await reader.IsDBNullAsync(23) ? string.Empty : reader.GetString(23),
                                causa_descripcion = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                hped_numero = await reader.IsDBNullAsync(25) ? 0 : reader.GetInt32(25),
                                situacion = await reader.IsDBNullAsync(26) ? 0 : reader.GetInt32(26),
                                vendedor_nombre = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27),
                                hproc_fecha_grab = await reader.IsDBNullAsync(28) ? string.Empty : reader.GetString(28),
                                ubifisi_codigo = await reader.IsDBNullAsync(29) ? string.Empty : reader.GetString(29),
                                bobi_fec_prod = await reader.IsDBNullAsync(30) ? string.Empty : reader.GetString(30),
                                cod_naturaleza = await reader.IsDBNullAsync(31) ? string.Empty : reader.GetString(31),
                                bobi_fec_leida = await reader.IsDBNullAsync(32) ? string.Empty : reader.GetString(32)
                            });
                        }
                        result.ProductosEnProceso = resultDetalle.AsQueryable();
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
        public async Task<ProductoTerminadoResponse> ListarProductosTerminadosDExport(ReporteGenericoRequest reporteGenericoRequest)
        {
            ProductoTerminadoResponse result = new ProductoTerminadoResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarProductosTerminadosDExport}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, reporteGenericoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, reporteGenericoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, reporteGenericoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Int32, reporteGenericoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Int32, reporteGenericoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("LINEA", OracleDbType.Varchar2, reporteGenericoRequest.Linea, ParameterDirection.Input);
                        cmd.Parameters.Add("SUBLINEA", OracleDbType.Varchar2, reporteGenericoRequest.SubLinea, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        List<ProductoTerminadoResponseDetalle> resultDetalle = new List<ProductoTerminadoResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new ProductoTerminadoResponseDetalle
                            {
                                id = Guid.NewGuid().ToString(),
                                tipo = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                desc_tipo = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                bobina_inventariada = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                bobi_serie = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                bobi_codigo = await reader.IsDBNullAsync(4) ? 0 : reader.GetInt32(4),
                                bobi_peso = await reader.IsDBNullAsync(5) ? 0 : reader.GetInt32(5),
                                bobina_peso_bruto = await reader.IsDBNullAsync(6) ? 0 : reader.GetInt32(6),
                                bobina_unidad_codigo = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                bobina_longitud = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8),
                                mitem_codigo = await reader.IsDBNullAsync(9) ? 0 : reader.GetInt32(9),
                                unidad_codigo = await reader.IsDBNullAsync(10) ? string.Empty : reader.GetString(10),
                                almacen_serie = await reader.IsDBNullAsync(11) ? string.Empty : reader.GetString(11),
                                item_descripcio = await reader.IsDBNullAsync(12) ? string.Empty : reader.GetString(12),
                                planta_serie = await reader.IsDBNullAsync(13) ? string.Empty : reader.GetString(13),
                                hord_trab_secuencial = await reader.IsDBNullAsync(14) ? 0 : reader.GetInt32(14),
                                descripcion_tamano = await reader.IsDBNullAsync(15) ? string.Empty : reader.GetString(15),
                                mitem_gramaje = await reader.IsDBNullAsync(16) ? 0 : reader.GetInt32(16),
                                unidad_equivalente = await reader.IsDBNullAsync(17) ? string.Empty : reader.GetString(17),
                                cantidad_equivalente = await reader.IsDBNullAsync(18) ? 0 : reader.GetInt32(18),
                                pedido = await reader.IsDBNullAsync(19) ? string.Empty : reader.GetString(19),
                                cliente = await reader.IsDBNullAsync(20) ? string.Empty : reader.GetString(20),
                                sucursal_descripcion = await reader.IsDBNullAsync(21) ? string.Empty : reader.GetString(21),
                                hproc_secuencial = await reader.IsDBNullAsync(22) ? 0 : reader.GetInt32(22),
                                condicion_codigo = await reader.IsDBNullAsync(23) ? string.Empty : reader.GetString(23),
                                condicion_descripcion = await reader.IsDBNullAsync(24) ? string.Empty : reader.GetString(24),
                                hproc_fecha_grab = await reader.IsDBNullAsync(25) ? string.Empty : reader.GetString(25),
                                ubifisi_codigo = await reader.IsDBNullAsync(26) ? string.Empty : reader.GetString(26),
                                bobi_fec_prod = await reader.IsDBNullAsync(27) ? string.Empty : reader.GetString(27)
                            });
                        }
                        result.ProductosTerminados = resultDetalle.AsQueryable();
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        //Proceso de Produccion
        public async Task<ProcesoDeProduccionResponse> ListarProcesoDeProduccionExport(ReporteGenericoRequest reporteGenericoRequest)
        {
            ProcesoDeProduccionResponse result = new ProcesoDeProduccionResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarProcesoDeProduccionExport}";//$"{IncomeDataProcedures.Procedure.ListarProductosTerminados}";


                        cmd.Parameters.Add("FECHA_DESDE", OracleDbType.Varchar2, reporteGenericoRequest.FechaDesde, ParameterDirection.Input);
                        cmd.Parameters.Add("FECHA_HASTA", OracleDbType.Varchar2, reporteGenericoRequest.FechaHasta, ParameterDirection.Input);
                        cmd.Parameters.Add("ALMACEN", OracleDbType.Varchar2, reporteGenericoRequest.AlmacenSerie, ParameterDirection.Input);
                        cmd.Parameters.Add("ITEM", OracleDbType.Int32, reporteGenericoRequest.MitemCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("CODBOBINA", OracleDbType.Int32, reporteGenericoRequest.BobiCodigo, ParameterDirection.Input);
                        cmd.Parameters.Add("ORDENTRABAJO", OracleDbType.Varchar2, reporteGenericoRequest.OrdenTrabajo, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOMES", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("PERIODOANIO", OracleDbType.Varchar2, reporteGenericoRequest.PeriodoAnio, ParameterDirection.Input);
                        cmd.Parameters.Add("p_resultset", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        List<ProcesoDeProduccionResponseDetalle> resultDetalle = new List<ProcesoDeProduccionResponseDetalle>();

                        while (await reader.ReadAsync())
                        {

                            resultDetalle.Add(new ProcesoDeProduccionResponseDetalle
                            {

                                id = Guid.NewGuid().ToString(),
                                hproc_fecha_grab = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                proceso_codigo = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                maquina_codigo = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                unidad_equivalente = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                cantidad_equivalente = await reader.IsDBNullAsync(4) ? 0 : reader.GetInt32(4),
                                planta_serie = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                hord_trab_secuencial = await reader.IsDBNullAsync(6) ? string.Empty : reader.GetString(6),
                                maquina_descripcion = await reader.IsDBNullAsync(7) ? string.Empty : reader.GetString(7),
                                proceso_descripcion = await reader.IsDBNullAsync(8) ? string.Empty : reader.GetString(8),
                                eproc_bobi_peso = await reader.IsDBNullAsync(9) ? 0 : reader.GetInt32(9)

                            });
                        }
                        result.ProcesoProduccion = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }


        #endregion
        
    }
}
