﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Reportes;
using VIM.Application.Shared.TransferObject.Response.Reportes;

namespace VIM.Api.Application.Repository.Reportes
{
    public interface IReportesData
    {
        //Listado Lineas
        Task<LineaResponse> ListarLinea();
        //Listado Sublineas
        Task<SublineaResponse> ListarSublinea(string codLinea);
        //Listado Mes Actual
        Task<List<string>> ListarMesActual(string tipo);
        //Listado Anios
        Task<List<int>> ListarAniosxReporte(string tipo);

        //Listado Almacen
        Task<AlmacenResponse> ListarAlmacen();

        //Pendientes por Ubicar
        Task<MateriaPrimaResponse> ListarMateriaPrima(MateriaPrimaRequest materiaPrimaRequest);
        Task<ProductosEnProcesoResponse> ListarProductosEnProceso(ProductosEnProcesoRequest productosEnProcesoRequest);
        Task<ProductoTerminadoResponse> ListarProductosTerminados(ProductoTerminadoRequest pendientesUbicarRequest);
        //Kardex Bobina
        Task<KardexBobinaResponse> ListarKardexBobina(KardexBobinaRequest kardexBobinaRequest);

        //Bobina con PNC
        Task<BobinaConPNCResponse> ListarBobinaConPNC(BobinaConPNCRequest bobinaConPNCRequest);

        //Desarrollo de Inventario
        Task<MateriaPrimaResponse> ListarMateriaPrimaD(MateriaPrimaRequest materiaPrimaRequest);
        Task<ProductoTerminadoResponse> ListarProductosTerminadosD(ProductoTerminadoRequest pendientesUbicarRequest);
        Task<ProductosEnProcesoResponse> ListarProductosEnProcesoD(ProductosEnProcesoRequest productosEnProcesoRequest);

        //Proceso de Produccion
        Task<ProcesoDeProduccionResponse> ListarProcesoDeProduccion(ProcesoDeProduccionRequest procesoDeProduccionRequest);

        #region EXPORTAR REPORTE

        //Pendientes por ubicar
        Task<MateriaPrimaResponse> ListarMateriaPrimaExport(ReporteGenericoRequest reporteGenericoRequest);
        Task<ProductosEnProcesoResponse> ListarProductosEnProcesoExport(ReporteGenericoRequest reporteGenericoRequest);
        Task<ProductoTerminadoResponse> ListarProductosTerminadosExport(ReporteGenericoRequest reporteGenericoRequest);

        //Kardex Bobina
        Task<KardexBobinaResponse> ListarKardexBobinaExport(ReporteGenericoRequest reporteGenericoRequest);

        //Bobina con PNC
        Task<BobinaConPNCResponse> ListarBobinaConPNCExport(ReporteGenericoRequest reporteGenericoRequest);

        //Desarrollo de Inventario
        Task<MateriaPrimaResponse> ListarMateriaPrimaDExport(ReporteGenericoRequest reporteGenericoRequest);
        Task<ProductoTerminadoResponse> ListarProductosTerminadosDExport(ReporteGenericoRequest reporteGenericoRequest);
        Task<ProductosEnProcesoResponse> ListarProductosEnProcesoDExport(ReporteGenericoRequest reporteGenericoRequest);

        //Proceso de Produccion
        Task<ProcesoDeProduccionResponse> ListarProcesoDeProduccionExport(ReporteGenericoRequest reporteGenericoRequest);

        #endregion
        
    }
}
