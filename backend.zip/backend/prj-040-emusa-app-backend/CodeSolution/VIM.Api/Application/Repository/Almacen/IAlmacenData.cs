﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Almacen;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Almacen;

namespace VIM.Api.Application.Repository.Almacen
{
    public interface IAlmacenData
    {
        Task<List<AlmacenResponse>> ListarAlmacen();        
        Task<PendientesUbicarResponse> ListarBobinaPedientesUbicar(PendientesUbicarRequest pendientesUbicarRequest);
        Task<ResultEntity> ActualizarBobina(BobinaRequest bobinaRequest);

        Task<PendientesInventariarResponse> ListarBobinaPedientesInventariar(PendientesUbicarRequest pendientesUbicarRequest);
        Task<ResultEntity> ActualizarBobinaInventario(BobinaRequest bobinaRequest);

        Task<PendientesPickingOTResponse> ListarBobinaPedientesPickupOTBobinaApilador(PendientesUbicarRequest pendientesUbicarRequest);
        Task<ResultEntity> ActualizarBobinaPickUpOTBobinaApilador(BobinaRequest bobinaRequest);

        Task<PendientesPickingOTResponse> ListarBobinaPedientesPickupOTBobinaStockero(PendientesUbicarRequest pendientesUbicarRequest);
        Task<ResultEntity> ActualizarBobinaPickUpOTBobinaStockero(BobinaRequest bobinaRequest);

        Task<PendientesPickingOTResponse> ObtenerBobinasporSecuencialApp(BobinaporSecuencialAppRequest bobinaporSecuencialAppRequest);
        Task<PendientesPickingOTResponse> ObtenerBobinasporSecuencialAppNI(BobinaporSecuencialAppRequest bobinaporSecuencialAppRequest);
        Task<ResultEntity> ActualizarUbicacionInventarioSecuencialApp(SecuencialAppRequest secuencialAppRequest);

        Task<ResultEntity> ActualizarUbicacionSecuencialApp(SecuencialAppRequest secuencialAppRequest);








    }
}
