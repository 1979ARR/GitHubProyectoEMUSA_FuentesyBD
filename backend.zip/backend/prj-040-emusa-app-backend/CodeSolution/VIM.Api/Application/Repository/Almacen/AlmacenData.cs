﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Almacen;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Almacen;
using VIM.Common.Shared.Constant;

namespace VIM.Api.Application.Repository.Almacen
{
    public class AlmacenData : IAlmacenData
    {
        private readonly string connectionString;
        public string userPackageBD { get; set; }
        public AlmacenData(string connectionString)
        {
            this.connectionString = connectionString;
            this.userPackageBD = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}"; // Desarrollo
            //this.userPackageBD = $"{IncomeDataProcedures.Package.PkgMobileAlmacen}"; // Producción
        }

        public async Task<ResultEntity> ActualizarBobina(BobinaRequest bobinaRequest)
        {

            ResultEntity response = new ResultEntity();
            string Mensaje;
            long IdResult;
            OracleConnection connection = null;

            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ActualizarBobina}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ActualizarBobina}";
                        cmd.Parameters.Add("P_ID_USUARIO", OracleDbType.Varchar2, bobinaRequest.IdUsuario, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_BOBINA", OracleDbType.Varchar2, bobinaRequest.CodBobina, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, bobinaRequest.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_UBICACION", OracleDbType.Varchar2, bobinaRequest.CodUbicacion, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, bobinaRequest.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_MENSAJE", OracleDbType.NVarchar2, 500, null, ParameterDirection.Output);
                        cmd.Parameters.Add("ID_RESULT", OracleDbType.Int64, ParameterDirection.Output);

                        await cmd.ExecuteNonQueryAsync();
                        Mensaje = cmd.Parameters["P_MENSAJE"].Value.ToString() != string.Empty ? cmd.Parameters["P_MENSAJE"].Value.ToString() : string.Empty;
                        IdResult = cmd.Parameters["ID_RESULT"].Value.ToString() != string.Empty ? Convert.ToInt64(cmd.Parameters["ID_RESULT"].Value.ToString()) : 0;

                        response.Message = Mensaje;
                        response.IdGenerated = IdResult;
                        response.Result = IdResult != 0;

                        return response;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<List<AlmacenResponse>> ListarAlmacen()
        {
            List<AlmacenResponse> result = new List<AlmacenResponse>();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ListarAlmacen}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ListarAlmacen}";
                        cmd.Parameters.Add("P_RESULT", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            AlmacenResponse _item = new AlmacenResponse
                            {
                                codAlmacen = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                descAlmacen = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1)
                            };
                            result.Add(_item);
                        }
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<PendientesUbicarResponse> ListarBobinaPedientesUbicar(PendientesUbicarRequest pendientesUbicarRequest)
        {
            PendientesUbicarResponse result = new PendientesUbicarResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ObtenerBobina}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerBobina}";
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, pendientesUbicarRequest.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, pendientesUbicarRequest.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULT", OracleDbType.RefCursor, ParameterDirection.Output);
                        var reader = await cmd.ExecuteReaderAsync();
                        Int32 totalRegistros = 0;
                        List<PendientesUbicarResponseDetalle> resultDetalle = new List<PendientesUbicarResponseDetalle>();
                        while (await reader.ReadAsync())
                        {
                            resultDetalle.Add(new PendientesUbicarResponseDetalle
                            {
                                CodItem = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                CodBobina = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                DescBobina = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                Peso = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                UnidadMedida = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                FecIngreso = await reader.IsDBNullAsync(6) ? string.Empty : reader.GetString(6),                                
                            });                            
                            totalRegistros = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.PendientesUbicar = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<ResultEntity> ActualizarBobinaInventario(BobinaRequest bobinaRequest)
        {

            ResultEntity response = new ResultEntity();
            string Mensaje;
            long IdResult;
            OracleConnection connection = null;

            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ActualizarBobinaInventario}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ActualizarBobinaInventario}";
                        cmd.Parameters.Add("P_ID_USUARIO", OracleDbType.Varchar2, bobinaRequest.IdUsuario, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_BOBINA", OracleDbType.Varchar2, bobinaRequest.CodBobina, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, bobinaRequest.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_UBICACION", OracleDbType.Varchar2, bobinaRequest.CodUbicacion, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, bobinaRequest.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_MENSAJE", OracleDbType.NVarchar2, 500, null, ParameterDirection.Output);
                        cmd.Parameters.Add("ID_RESULT", OracleDbType.Int64, ParameterDirection.Output);

                        await cmd.ExecuteNonQueryAsync();
                        Mensaje = cmd.Parameters["P_MENSAJE"].Value.ToString() != string.Empty ? cmd.Parameters["P_MENSAJE"].Value.ToString() : string.Empty;
                        IdResult = cmd.Parameters["ID_RESULT"].Value.ToString() != string.Empty ? Convert.ToInt64(cmd.Parameters["ID_RESULT"].Value.ToString()) : 0;

                        response.Message = Mensaje;
                        response.IdGenerated = IdResult;
                        response.Result = IdResult != 0;

                        return response;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<PendientesInventariarResponse> ListarBobinaPedientesInventariar(PendientesUbicarRequest pendientesUbicarRequest)
        {
            PendientesInventariarResponse result = new PendientesInventariarResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ObtenerBobinaInventario}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerBobinaInventario}";
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, pendientesUbicarRequest.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, pendientesUbicarRequest.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULT", OracleDbType.RefCursor, ParameterDirection.Output);
                        var reader = await cmd.ExecuteReaderAsync();
                        Int32 totalPendientesInventariar = 0;
                        Int32 totalInventariado = 0;
                        while (await reader.ReadAsync())
                        {
                           
                            totalPendientesInventariar = await reader.IsDBNullAsync(0) ? 0 : reader.GetInt32(0);
                            totalInventariado = await reader.IsDBNullAsync(1) ? 0 : reader.GetInt32(1);
                        }
                        result.TotalPendientesInventariar = totalPendientesInventariar;
                        result.TotalInventariado = totalInventariado;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }


        public async Task<ResultEntity> ActualizarBobinaPickUpOTBobinaStockero(BobinaRequest bobinaRequest)
        {

            ResultEntity response = new ResultEntity();
            string Mensaje;
            long IdResult;
            OracleConnection connection = null;

            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ActualizarBobinaInventarioStockero}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ActualizarBobinaInventarioStockero}";
                        cmd.Parameters.Add("P_ID_USUARIO", OracleDbType.Varchar2, bobinaRequest.IdUsuario, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_BOBINA", OracleDbType.Varchar2, bobinaRequest.CodBobina, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, bobinaRequest.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_UBICACION", OracleDbType.Varchar2, bobinaRequest.CodUbicacion, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, bobinaRequest.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_MENSAJE", OracleDbType.NVarchar2, 500, null, ParameterDirection.Output);
                        cmd.Parameters.Add("ID_RESULT", OracleDbType.Int64, ParameterDirection.Output);

                        await cmd.ExecuteNonQueryAsync();
                        Mensaje = cmd.Parameters["P_MENSAJE"].Value.ToString() != string.Empty ? cmd.Parameters["P_MENSAJE"].Value.ToString() : string.Empty;
                        IdResult = cmd.Parameters["ID_RESULT"].Value.ToString() != string.Empty ? Convert.ToInt64(cmd.Parameters["ID_RESULT"].Value.ToString()) : 0;

                        response.Message = Mensaje;
                        response.IdGenerated = IdResult;
                        response.Result = IdResult != 0;

                        return response;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<PendientesPickingOTResponse> ListarBobinaPedientesPickupOTBobinaStockero(PendientesUbicarRequest pendientesUbicarRequest)
        {
            PendientesPickingOTResponse result = new PendientesPickingOTResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ObtenerBobinaInventarioStockero}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerBobinaInventarioStockero}";
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, pendientesUbicarRequest.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, pendientesUbicarRequest.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULT", OracleDbType.RefCursor, ParameterDirection.Output);
                        var reader = await cmd.ExecuteReaderAsync();
                        Int32 totalRegistros = 0;
                        List<PendientesPickingOTResponseDetalle> resultDetalle = new List<PendientesPickingOTResponseDetalle>();
                        while (await reader.ReadAsync())
                        {
                            resultDetalle.Add(new PendientesPickingOTResponseDetalle
                            {
                                Ubicacion = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                CodBobina = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                DescBobina = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                Ot = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                Peso = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                UnidadMedida = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                Cantidad = await reader.IsDBNullAsync(6) ? string.Empty : reader.GetString(6),
                                Maquina = await reader.IsDBNullAsync(8) ? string.Empty : reader.GetString(8)
                            });
                            totalRegistros = await reader.IsDBNullAsync(7) ? 0 : reader.GetInt32(7);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.PendientesPickingOT = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<ResultEntity> ActualizarBobinaPickUpOTBobinaApilador(BobinaRequest bobinaRequest)
        {

            ResultEntity response = new ResultEntity();
            string Mensaje;
            long IdResult;
            OracleConnection connection = null;

            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ActualizarBobinaInventarioApilador}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ActualizarBobinaInventarioApilador}";
                        cmd.Parameters.Add("P_ID_USUARIO", OracleDbType.Varchar2, bobinaRequest.IdUsuario, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_BOBINA", OracleDbType.Varchar2, bobinaRequest.CodBobina, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, bobinaRequest.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_UBICACION", OracleDbType.Varchar2, bobinaRequest.CodUbicacion, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, bobinaRequest.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_MENSAJE", OracleDbType.NVarchar2, 500, null, ParameterDirection.Output);
                        cmd.Parameters.Add("ID_RESULT", OracleDbType.Int64, ParameterDirection.Output);

                        await cmd.ExecuteNonQueryAsync();
                        Mensaje = cmd.Parameters["P_MENSAJE"].Value.ToString() != string.Empty ? cmd.Parameters["P_MENSAJE"].Value.ToString() : string.Empty;
                        IdResult = cmd.Parameters["ID_RESULT"].Value.ToString() != string.Empty ? Convert.ToInt64(cmd.Parameters["ID_RESULT"].Value.ToString()) : 0;

                        response.Message = Mensaje;
                        response.IdGenerated = IdResult;
                        response.Result = IdResult != 0;

                        return response;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<PendientesPickingOTResponse> ListarBobinaPedientesPickupOTBobinaApilador(PendientesUbicarRequest pendientesUbicarRequest)
        {
            PendientesPickingOTResponse result = new PendientesPickingOTResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ObtenerBobinaInventarioApilador}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerBobinaInventarioApilador}";
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, pendientesUbicarRequest.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, pendientesUbicarRequest.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULT", OracleDbType.RefCursor, ParameterDirection.Output);
                        var reader = await cmd.ExecuteReaderAsync();
                        Int32 totalRegistros = 0;
                        List<PendientesPickingOTResponseDetalle> resultDetalle = new List<PendientesPickingOTResponseDetalle>();
                        while (await reader.ReadAsync())
                        {
                            resultDetalle.Add(new PendientesPickingOTResponseDetalle
                            {
                                Ubicacion = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                CodBobina = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                DescBobina = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                Ot = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                Peso = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                UnidadMedida = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                Cantidad = await reader.IsDBNullAsync(6) ? string.Empty : reader.GetString(6),
                                Maquina = await reader.IsDBNullAsync(8) ? string.Empty : reader.GetString(8)
                            });
                            totalRegistros = await reader.IsDBNullAsync(7) ? 0 : reader.GetInt32(7);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.PendientesPickingOT = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<PendientesPickingOTResponse> ObtenerBobinasporSecuencialApp(BobinaporSecuencialAppRequest request)
        {
            PendientesPickingOTResponse result = new PendientesPickingOTResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ObtenerBobinaInventarioStockero}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerBobinasporSecuencialApp}";
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, request.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, request.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_SECAPP", OracleDbType.Varchar2, request.CodSecuencialApp, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULT", OracleDbType.RefCursor, ParameterDirection.Output);
                        var reader = await cmd.ExecuteReaderAsync();
                        Int32 totalRegistros = 0;
                        List<PendientesPickingOTResponseDetalle> resultDetalle = new List<PendientesPickingOTResponseDetalle>();
                        while (await reader.ReadAsync())
                        {
                            resultDetalle.Add(new PendientesPickingOTResponseDetalle
                            {
                                Ubicacion = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                CodBobina = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                CodItem = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                DescBobina = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                Peso = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                UnidadMedida = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                FecIngreso = await reader.IsDBNullAsync(6) ? string.Empty : reader.GetString(6)
                            });
                            totalRegistros = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.PendientesPickingOT = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<PendientesPickingOTResponse> ObtenerBobinasporSecuencialAppNI(BobinaporSecuencialAppRequest request)
        {
            PendientesPickingOTResponse result = new PendientesPickingOTResponse();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ObtenerBobinaInventarioStockero}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ObtenerBobinasporSecuencialAppNI}";
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, request.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, request.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_SECAPP", OracleDbType.Varchar2, request.CodSecuencialApp, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULT", OracleDbType.RefCursor, ParameterDirection.Output);
                        var reader = await cmd.ExecuteReaderAsync();
                        Int32 totalRegistros = 0;
                        List<PendientesPickingOTResponseDetalle> resultDetalle = new List<PendientesPickingOTResponseDetalle>();
                        while (await reader.ReadAsync())
                        {
                            resultDetalle.Add(new PendientesPickingOTResponseDetalle
                            {
                                Ubicacion = await reader.IsDBNullAsync(0) ? string.Empty : reader.GetString(0),
                                CodBobina = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                CodItem = await reader.IsDBNullAsync(2) ? string.Empty : reader.GetString(2),
                                DescBobina = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3),
                                Peso = await reader.IsDBNullAsync(4) ? string.Empty : reader.GetString(4),
                                UnidadMedida = await reader.IsDBNullAsync(5) ? string.Empty : reader.GetString(5),
                                FecIngreso = await reader.IsDBNullAsync(6) ? string.Empty : reader.GetString(6)
                            });
                            totalRegistros = await reader.IsDBNullAsync(8) ? 0 : reader.GetInt32(8);
                        }
                        result.TotalRegistros = totalRegistros;
                        result.PendientesPickingOT = resultDetalle;
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        

        public async Task<ResultEntity> ActualizarUbicacionInventarioSecuencialApp(SecuencialAppRequest request)
        {

            ResultEntity response = new ResultEntity();
            string Mensaje;
            long IdResult;
            OracleConnection connection = null;

            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ActualizarBobinaInventarioApilador}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ActualizarUbicacionInventarioSecuencialApp}";
                        cmd.Parameters.Add("P_ID_USUARIO", OracleDbType.Varchar2, request.IdUsuario, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_SECAPP", OracleDbType.Varchar2, request.CodSecuencialApp, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, request.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_UBICACION", OracleDbType.Varchar2, request.CodUbicacion, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, request.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_MENSAJE", OracleDbType.NVarchar2, 500, null, ParameterDirection.Output);
                        cmd.Parameters.Add("ID_RESULT", OracleDbType.Int64, ParameterDirection.Output);

                        await cmd.ExecuteNonQueryAsync();
                        Mensaje = cmd.Parameters["P_MENSAJE"].Value.ToString() != string.Empty ? cmd.Parameters["P_MENSAJE"].Value.ToString() : string.Empty;
                        IdResult = cmd.Parameters["ID_RESULT"].Value.ToString() != string.Empty ? Convert.ToInt64(cmd.Parameters["ID_RESULT"].Value.ToString()) : 0;

                        response.Message = Mensaje;
                        response.IdGenerated = IdResult;
                        response.Result = IdResult != 0;

                        return response;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<ResultEntity> ActualizarUbicacionSecuencialApp(SecuencialAppRequest request)
        {

            ResultEntity response = new ResultEntity();
            string Mensaje;
            long IdResult;
            OracleConnection connection = null;

            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        //cmd.CommandText = $"{IncomeDataProcedures.Schema.Impor}.{IncomeDataProcedures.Package.PkgMobileAlmacen}.{IncomeDataProcedures.Procedure.ActualizarBobinaInventarioApilador}";
                        cmd.CommandText = $"{this.userPackageBD}.{IncomeDataProcedures.Procedure.ActualizarUbicacionSecuencialApp}";
                        cmd.Parameters.Add("P_ID_USUARIO", OracleDbType.Varchar2, request.IdUsuario, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_SECAPP", OracleDbType.Varchar2, request.CodSecuencialApp, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_ALMACEN", OracleDbType.Varchar2, request.CodAlmacen, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_UBICACION", OracleDbType.Varchar2, request.CodUbicacion, ParameterDirection.Input);
                        cmd.Parameters.Add("P_COD_TIPOPRODUCTO", OracleDbType.Varchar2, request.CodTipoProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_MENSAJE", OracleDbType.NVarchar2, 500, null, ParameterDirection.Output);
                        cmd.Parameters.Add("ID_RESULT", OracleDbType.Int64, ParameterDirection.Output);

                        await cmd.ExecuteNonQueryAsync();
                        Mensaje = cmd.Parameters["P_MENSAJE"].Value.ToString() != string.Empty ? cmd.Parameters["P_MENSAJE"].Value.ToString() : string.Empty;
                        IdResult = cmd.Parameters["ID_RESULT"].Value.ToString() != string.Empty ? Convert.ToInt64(cmd.Parameters["ID_RESULT"].Value.ToString()) : 0;

                        response.Message = Mensaje;
                        response.IdGenerated = IdResult;
                        response.Result = IdResult != 0;

                        return response;
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }


    }
}
