﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Demo;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Demo;

namespace VIM.Api.Application.Repository.Demo
{
    public interface IDemoData
    {
        Task<ResultEntity> RegistrarProducto(ProductoRequest productoRequest);
        Task<ResultEntity> ActualizarProducto(ProductoRequest productoRequest);
        Task<ProductoResponse> ObtenerProducto(ProductoRequest productoRequest);
        Task<List<ProductoResponse>> ListarProductos();

    }
}
