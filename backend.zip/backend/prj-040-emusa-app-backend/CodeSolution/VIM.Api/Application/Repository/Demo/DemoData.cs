﻿using Dapper;
using Oracle.ManagedDataAccess.Client;
//using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Demo;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Demo;
using VIM.Common.Shared.Constant;

namespace VIM.Api.Application.Repository.Demo
{
    public class DemoData : IDemoData
    {
        private readonly string connectionString;
        public DemoData(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public async Task<ResultEntity> ActualizarProducto(ProductoRequest productoRequest)
        {
            ResultEntity response = new ResultEntity();
            long IdResult;
            OracleConnection connection = null;

            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{IncomeDataProcedures.Package.PkgDemo}.{IncomeDataProcedures.Procedure.ActualizarProducto}";
                        cmd.Parameters.Add("P_IDPRODUCTO", OracleDbType.Int64, productoRequest.IdProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_NOMBRE", OracleDbType.Varchar2, productoRequest.Nombre, ParameterDirection.Input);
                        cmd.Parameters.Add("P_PRECIO", OracleDbType.Decimal, productoRequest.Precio, ParameterDirection.Input);
                        cmd.Parameters.Add("ID_RESULT", OracleDbType.Int64, ParameterDirection.Output);

                        await cmd.ExecuteNonQueryAsync();

                        IdResult = cmd.Parameters["ID_RESULT"].Value.ToString() != string.Empty ? Convert.ToInt64(cmd.Parameters["ID_RESULT"].Value.ToString()) : 0;
                        response.IdGenerated = IdResult;
                        response.Result = IdResult != 0;
                        return response;
                    }
                }

            }
            catch (Exception ex)
            {
                throw new NotImplementedException();
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<List<ProductoResponse>> ListarProductos()
        {
            List<ProductoResponse> result = new List<ProductoResponse>();
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{IncomeDataProcedures.Package.PkgDemo}.{IncomeDataProcedures.Procedure.ListarProductos}";
                        cmd.Parameters.Add("P_RESULT", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            ProductoResponse _item = new ProductoResponse
                            {
                                IdProducto = await reader.IsDBNullAsync(0) ? 0 : reader.GetInt64(0),
                                Nombre = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                Precio = await reader.IsDBNullAsync(2) ? 0 : reader.GetDecimal(2),
                                FechaReg = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3)
                            };
                            result.Add(_item);
                        }
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception)
            {
                throw new NotImplementedException();
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<ProductoResponse> ObtenerProducto(ProductoRequest productoRequest)
        {
            ProductoResponse result = null;
            OracleConnection connection = null;
            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();
                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{IncomeDataProcedures.Package.PkgDemo}.{IncomeDataProcedures.Procedure.ObtenerProducto}";
                        cmd.Parameters.Add("P_IDPRODUCTO", OracleDbType.Int64, productoRequest.IdProducto, ParameterDirection.Input);
                        cmd.Parameters.Add("P_RESULT", OracleDbType.RefCursor, ParameterDirection.Output);

                        var reader = await cmd.ExecuteReaderAsync();

                        while (await reader.ReadAsync())
                        {
                            result = new ProductoResponse
                            {
                                IdProducto = await reader.IsDBNullAsync(0) ? 0 : reader.GetInt64(0),
                                Nombre = await reader.IsDBNullAsync(1) ? string.Empty : reader.GetString(1),
                                Precio = await reader.IsDBNullAsync(2) ? 0 : reader.GetDecimal(2),
                                FechaReg = await reader.IsDBNullAsync(3) ? string.Empty : reader.GetString(3)
                            };
                        }
                        await reader.DisposeAsync();
                        return result;
                    }
                }

            }
            catch (Exception)
            {
                throw new NotImplementedException();
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }

        public async Task<ResultEntity> RegistrarProducto(ProductoRequest productoRequest)
        {
            ResultEntity response = new ResultEntity();
            long IdResult;
            OracleConnection connection = null;

            try
            {
                using (connection = new OracleConnection(connectionString))
                {
                    connection.Open();

                    using (OracleCommand cmd = new OracleCommand())
                    {
                        cmd.Connection = connection;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = $"{IncomeDataProcedures.Package.PkgDemo}.{IncomeDataProcedures.Procedure.RegistrarProducto}";
                        cmd.Parameters.Add("P_NOMBRE", OracleDbType.Varchar2, productoRequest.Nombre, ParameterDirection.Input);
                        cmd.Parameters.Add("P_PRECIO", OracleDbType.Decimal, productoRequest.Precio, ParameterDirection.Input);
                        cmd.Parameters.Add("ID_RESULT", OracleDbType.Int64, ParameterDirection.Output);

                        await cmd.ExecuteNonQueryAsync();

                        IdResult = cmd.Parameters["ID_RESULT"].Value.ToString() != string.Empty ? Convert.ToInt64(cmd.Parameters["ID_RESULT"].Value.ToString()) : 0;
                        response.IdGenerated = IdResult;
                        response.Result = IdResult != 0;
                        return response;
                    }
                }

            }
            catch (Exception ex)
            {
                throw new NotImplementedException();
            }
            finally
            {
                if (connection != null)
                    connection.Close();
            }
        }
    }
}
