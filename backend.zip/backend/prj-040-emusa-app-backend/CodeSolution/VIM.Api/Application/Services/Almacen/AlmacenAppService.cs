﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using VIM.Api.Application.Repository.Almacen;
using VIM.Application.Shared.TransferObject.Request.Almacen;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Almacen;

namespace VIM.Api.Application.Services.Almacen
{
    public class AlmacenAppService : IAlmacenAppService
    {
        private readonly IAlmacenData _almacenData;

        public AlmacenAppService(IConfiguration configuration)
        {
            _almacenData = new AlmacenData(configuration.GetConnectionString("defaultConnection"));
        }

        public async Task<Response<bool>> ActualizarBobina(BobinaRequest bobinaRequest)
        {
            Response<bool> _response;
            ResultEntity _resultEntity;
            //try
            //{
            using (var transaction = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                _resultEntity = await _almacenData.ActualizarBobina(bobinaRequest);
                transaction.Complete();
            }

            _response = new Response<bool>
            {
                Status = _resultEntity.Result,
                Message = _resultEntity.Message
            };
            //}
            //catch (Exception ex)
            //{
            //    _response = new Response<bool>()
            //    {
            //        Status = false,
            //        Message = ex.Message
            //    };
            //}
            return _response;
        }

        public async Task<Response<List<AlmacenResponse>>> ListarAlmacen()
        {
            var productos = await _almacenData.ListarAlmacen();

            var response = new Response<List<AlmacenResponse>>
            {
                Result = productos
            };

            return response;
        }

        public async Task<Response<PendientesUbicarResponse>> ListarBobinaPedientesUbicar(PendientesUbicarRequest pendientesUbicarRequest)
        {
            var producto = await _almacenData.ListarBobinaPedientesUbicar(pendientesUbicarRequest);

            var response = new Response<PendientesUbicarResponse>
            {
                Result = producto
            };

            return response;
        }

        public async Task<Response<bool>> ActualizarBobinaInventario(BobinaRequest bobinaRequest)
        {
            Response<bool> _response;
            ResultEntity _resultEntity;
           
            using (var transaction = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                _resultEntity = await _almacenData.ActualizarBobinaInventario(bobinaRequest);
                transaction.Complete();
            }

            _response = new Response<bool>
            {
                Status = _resultEntity.Result,
                Message = _resultEntity.Message
            };
            
            return _response;
        }

        public async Task<Response<PendientesInventariarResponse>> ListarBobinaPedientesInventariar(PendientesUbicarRequest pendientesUbicarRequest)
        {
            var producto = await _almacenData.ListarBobinaPedientesInventariar(pendientesUbicarRequest);

            var response = new Response<PendientesInventariarResponse>
            {
                Result = producto
            };

            return response;
        }

        public async Task<Response<bool>> ActualizarBobinaPickUpOTBobinaApilador(BobinaRequest bobinaRequest)
        {
            Response<bool> _response;
            ResultEntity _resultEntity;

            using (var transaction = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                _resultEntity = await _almacenData.ActualizarBobinaPickUpOTBobinaApilador(bobinaRequest);
                transaction.Complete();
            }

            _response = new Response<bool>
            {
                Status = _resultEntity.Result,
                Message = _resultEntity.Message
            };

            return _response;
        }

        public async Task<Response<PendientesPickingOTResponse>> ListarBobinaPedientesPickupOTBobinaApilador(PendientesUbicarRequest pendientesUbicarRequest)
        {
            var producto = await _almacenData.ListarBobinaPedientesPickupOTBobinaApilador(pendientesUbicarRequest);

            var response = new Response<PendientesPickingOTResponse>
            {
                Result = producto
            };

            return response;
        }

        public async Task<Response<bool>> ActualizarBobinaPickUpOTBobinaStockero(BobinaRequest bobinaRequest)
        {
            Response<bool> _response;
            ResultEntity _resultEntity;

            using (var transaction = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                _resultEntity = await _almacenData.ActualizarBobinaPickUpOTBobinaStockero(bobinaRequest);
                transaction.Complete();
            }

            _response = new Response<bool>
            {
                Status = _resultEntity.Result,
                Message = _resultEntity.Message
            };

            return _response;
        }

        public async Task<Response<PendientesPickingOTResponse>> ListarBobinaPedientesPickupOTBobinaStockero(PendientesUbicarRequest pendientesUbicarRequest)
        {
            var producto = await _almacenData.ListarBobinaPedientesPickupOTBobinaStockero(pendientesUbicarRequest);

            var response = new Response<PendientesPickingOTResponse>
            {
                Result = producto
            };

            return response;
        }


        public async Task<Response<PendientesPickingOTResponse>> obtenerBobinasporSecuencialApp(BobinaporSecuencialAppRequest bobinaporSecuencialAppRequest)
        {
            var producto = await _almacenData.ObtenerBobinasporSecuencialApp(bobinaporSecuencialAppRequest);

            var response = new Response<PendientesPickingOTResponse>
            {
                Result = producto
            };

            return response;
        }
        public async Task<Response<PendientesPickingOTResponse>> obtenerBobinasporSecuencialAppNI(BobinaporSecuencialAppRequest bobinaporSecuencialAppRequest)
        {
            var producto = await _almacenData.ObtenerBobinasporSecuencialAppNI(bobinaporSecuencialAppRequest);

            var response = new Response<PendientesPickingOTResponse>
            {
                Result = producto
            };

            return response;
        }



        public async Task<Response<bool>> actualizarUbicacionInventarioSecuencialApp(SecuencialAppRequest secuencialAppRequest)
        {
            Response<bool> _response;
            ResultEntity _resultEntity;

            using (var transaction = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                _resultEntity = await _almacenData.ActualizarUbicacionInventarioSecuencialApp(secuencialAppRequest);
                transaction.Complete();
            }

            _response = new Response<bool>
            {
                Status = _resultEntity.Result,
                Message = _resultEntity.Message
            };

            return _response;
        }

        public async Task<Response<bool>> actualizarUbicacionSecuencialApp(SecuencialAppRequest secuencialAppRequest)
        {
            Response<bool> _response;
            ResultEntity _resultEntity;

            using (var transaction = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                _resultEntity = await _almacenData.ActualizarUbicacionSecuencialApp(secuencialAppRequest);
                transaction.Complete();
            }

            _response = new Response<bool>
            {
                Status = _resultEntity.Result,
                Message = _resultEntity.Message
            };

            return _response;
        }



    }
}
