﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Almacen;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Almacen;

namespace VIM.Api.Application.Services.Almacen
{
    public interface IAlmacenAppService
    {
        Task<Response<List<AlmacenResponse>>> ListarAlmacen();
        Task<Response<PendientesUbicarResponse>> ListarBobinaPedientesUbicar(PendientesUbicarRequest pendientesUbicarRequest);
        Task<Response<bool>> ActualizarBobina(BobinaRequest bobinaRequest);
        Task<Response<PendientesInventariarResponse>> ListarBobinaPedientesInventariar(PendientesUbicarRequest pendientesUbicarRequest);
        Task<Response<bool>> ActualizarBobinaInventario(BobinaRequest bobinaRequest);

        Task<Response<PendientesPickingOTResponse>> ListarBobinaPedientesPickupOTBobinaApilador(PendientesUbicarRequest pendientesUbicarRequest);
        Task<Response<bool>> ActualizarBobinaPickUpOTBobinaApilador(BobinaRequest bobinaRequest);

        Task<Response<PendientesPickingOTResponse>> ListarBobinaPedientesPickupOTBobinaStockero(PendientesUbicarRequest pendientesUbicarRequest);
        Task<Response<bool>> ActualizarBobinaPickUpOTBobinaStockero(BobinaRequest bobinaRequest);

        Task<Response<PendientesPickingOTResponse>> obtenerBobinasporSecuencialApp(BobinaporSecuencialAppRequest bobinaporSecuencialAppRequest);
        Task<Response<PendientesPickingOTResponse>> obtenerBobinasporSecuencialAppNI(BobinaporSecuencialAppRequest bobinaporSecuencialAppRequest);

        Task<Response<bool>> actualizarUbicacionInventarioSecuencialApp(SecuencialAppRequest secuencialAppRequest);
        Task<Response<bool>> actualizarUbicacionSecuencialApp(SecuencialAppRequest secuencialAppRequest);







    }
}
