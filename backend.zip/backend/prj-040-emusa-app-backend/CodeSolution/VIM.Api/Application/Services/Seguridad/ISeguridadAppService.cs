﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Seguridad;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Seguridad;

namespace VIM.Api.Application.Services.Seguridad
{
    public interface ISeguridadAppService
    {
        Task<Response<SeguridadResponse>> validateUser(SeguridadRequest seguridadRequest, bool autenticacionBasica);
    }
}
