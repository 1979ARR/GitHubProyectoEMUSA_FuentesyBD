﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Api.Application.Repository.Seguridad;
using VIM.Application.Shared.TransferObject.Request.Seguridad;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Seguridad;

namespace VIM.Api.Application.Services.Seguridad
{
    public class SeguridadAppService : ISeguridadAppService
    {
        private readonly ISeguridadData _seguridadData;

        public SeguridadAppService(IConfiguration configuration)
        {
            _seguridadData = new SeguridadData(configuration.GetConnectionString("defaultConnection"));
        }

        public async Task<Response<SeguridadResponse>> validateUser(SeguridadRequest seguridadRequest, bool autenticacionBasica)
        {
            var producto = await _seguridadData.ObtenerUsuario(seguridadRequest, autenticacionBasica);
            var response = new Response<SeguridadResponse>();
            if (producto != null)
            {
                response.Result = producto;
            }
            else
            {
                response.State = 200;
                response.Status = false;
                response.Message = "Usuario y/o contraseña incorrecta";
            }
            return response;
        }
    }
}
