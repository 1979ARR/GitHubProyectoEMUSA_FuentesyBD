﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Api.Infrastructure.Models;
using VIM.Application.Shared.TransferObject.Request.Reportes;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Reportes;

namespace VIM.Api.Application.Services.Reportes
{
    public interface IReportesAppService
    {
        //Listado Linea
        Task<Response<LineaResponse>> ListarLinea();
        
        //Listado Sublinea
        Task<Response<SublineaResponse>> ListarSublinea(string codLinea);
        //Listado Mes Actual
        Task<Response<List<string>>> ListarMesActual(string tipo);

        //Listado Anios
        Task<Response<List<int>>> ListarAniosxReporte(string tipo);

        //Listado Almacen
        Task<Response<AlmacenResponse>> ListarAlmacen();

        //Pendientes por Ubicar
        Task<Response<MateriaPrimaResponse>> ListarMateriaPrima(MateriaPrimaRequest materiaPrimaRequest);
        Task<Response<ProductosEnProcesoResponse>> ListarProductosEnProceso(ProductosEnProcesoRequest productosEnProcesoRequest);
        Task<Response<ProductoTerminadoResponse>> ListarProductosTerminados(ProductoTerminadoRequest productoTerminadoRequest);
     
        //Kardex Bobina
        Task<Response<KardexBobinaResponse>> ListarKardexBobina(KardexBobinaRequest kardexBobinaRequest);

        //Bobina con PNC
        Task<Response<BobinaConPNCResponse>> ListarBobinaConPNC(BobinaConPNCRequest bobinaConPNCRequest);
        //Desarrollo de Inventario
        Task<Response<MateriaPrimaResponse>> ListarMateriaPrimaD(MateriaPrimaRequest materiaPrimaRequest);
        Task<Response<ProductoTerminadoResponse>> ListarProductosTerminadosD(ProductoTerminadoRequest productoTerminadoRequest);
        Task<Response<ProductosEnProcesoResponse>> ListarProductosEnProcesoD(ProductosEnProcesoRequest productosEnProcesoRequest);

        //Proceso de Produccion
        Task<Response<ProcesoDeProduccionResponse>> ListarProcesoDeProduccion(ProcesoDeProduccionRequest procesoDeProduccionRequest);

        //Reporte Genérico - Exportar
        Task<DownloadFile> ExportarReporteGenerico(ReporteGenericoRequest reporteGenericoRequest);
    }
}
