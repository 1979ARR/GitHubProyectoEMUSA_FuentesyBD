﻿using Microsoft.Extensions.Configuration;
using Spire.Xls;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using VIM.Api.Application.Repository.Reportes;
using VIM.Api.Infrastructure.Models;
using VIM.Application.Shared.TransferObject.Request.Reportes;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Reportes;

namespace VIM.Api.Application.Services.Reportes
{
    public class ReportesAppService : IReportesAppService
    {
        private readonly IReportesData _reportesData;

        public ReportesAppService(IConfiguration configuration)
        {
            _reportesData = new ReportesData(configuration.GetConnectionString("defaultConnection"));
        }
        //Listado Linea
        public async Task<Response<LineaResponse>> ListarLinea()
        {
            var linea = await _reportesData.ListarLinea();

            var response = new Response<LineaResponse>
            {
                Result = linea
            };

            return response;
        }
        //Listado Sublinea
        public async Task<Response<SublineaResponse>> ListarSublinea(string codLinea)
        {
            var sublinea = await _reportesData.ListarSublinea(codLinea);

            var response = new Response<SublineaResponse>
            {
                Result = sublinea
            };

            return response;
        }
        //Listado Mes Actual
        public async Task<Response<List<string>>> ListarMesActual(string tipo)
        {
            var mes = await _reportesData.ListarMesActual(tipo);
            
            var response = new Response<List<string>>
            {
                Result = mes
            };

            return response;
        }

        //Listado Anios
        public async Task<Response<List<int>>> ListarAniosxReporte(string tipo)
        {
            var anios = await _reportesData.ListarAniosxReporte(tipo);
            var result = anios.AsEnumerable().Where(i => i != 0).ToList();

            var response = new Response<List<int>>
            {
                Result = result
            };

            return response;
        }

        //Listado Almacen
        public async Task<Response<AlmacenResponse>> ListarAlmacen()
        {
            var almacen = await _reportesData.ListarAlmacen();

            var response = new Response<AlmacenResponse>
            {
                Result = almacen
            };

            return response;
        }

        //Pendientes por Ubicar
        public async Task<Response<MateriaPrimaResponse>> ListarMateriaPrima(MateriaPrimaRequest materiaPrimaRequest)
        {
            var productos = await _reportesData.ListarMateriaPrima(materiaPrimaRequest);

            var response = new Response<MateriaPrimaResponse>
            {
                Result = productos
            };

            return response;
        }
        public async Task<Response<ProductoTerminadoResponse>> ListarProductosTerminados(ProductoTerminadoRequest productoTerminadoRequest)
        {
            var productos = await _reportesData.ListarProductosTerminados(productoTerminadoRequest);

            var response = new Response<ProductoTerminadoResponse>
            {
                Result = productos
            };

            return response;
        }
        public async Task<Response<ProductosEnProcesoResponse>> ListarProductosEnProceso(ProductosEnProcesoRequest productosEnProcesoRequest)
        {
            var productos = await _reportesData.ListarProductosEnProceso(productosEnProcesoRequest);

            var response = new Response<ProductosEnProcesoResponse>
            {
                Result = productos
            };

            return response;
        }

        //Kardex Bobina
        public async Task<Response<KardexBobinaResponse>> ListarKardexBobina(KardexBobinaRequest kardexBobinaRequest)
        {
            var kardex = await _reportesData.ListarKardexBobina(kardexBobinaRequest);

            var response = new Response<KardexBobinaResponse>
            {
                Result = kardex
            };

            return response;
        }

        //Bobina con PNC
        public async Task<Response<BobinaConPNCResponse>> ListarBobinaConPNC(BobinaConPNCRequest bobinaConPNCRequest)
        {
            var bobina = await _reportesData.ListarBobinaConPNC(bobinaConPNCRequest);

            var response = new Response<BobinaConPNCResponse>
            {
                Result = bobina
            };

            return response;
        }

        //Desarrollo de Inventario
        public async Task<Response<MateriaPrimaResponse>> ListarMateriaPrimaD(MateriaPrimaRequest materiaPrimaRequest)
        {
            var productos = await _reportesData.ListarMateriaPrimaD(materiaPrimaRequest);

            var response = new Response<MateriaPrimaResponse>
            {
                Result = productos
            };

            return response;
        }
        public async Task<Response<ProductoTerminadoResponse>> ListarProductosTerminadosD(ProductoTerminadoRequest productoTerminadoRequest)
        {
            var productos = await _reportesData.ListarProductosTerminadosD(productoTerminadoRequest);

            var response = new Response<ProductoTerminadoResponse>
            {
                Result = productos
            };

            return response;
        }
        public async Task<Response<ProductosEnProcesoResponse>> ListarProductosEnProcesoD(ProductosEnProcesoRequest productosEnProcesoRequest)
        {
            var productos = await _reportesData.ListarProductosEnProcesoD(productosEnProcesoRequest);

            var response = new Response<ProductosEnProcesoResponse>
            {
                Result = productos
            };

            return response;
        }

        //Proceso de Produccion
        public async Task<Response<ProcesoDeProduccionResponse>> ListarProcesoDeProduccion(ProcesoDeProduccionRequest procesoDeProduccionRequest)
        {
            var proceso = await _reportesData.ListarProcesoDeProduccion(procesoDeProduccionRequest);

            var response = new Response<ProcesoDeProduccionResponse>
            {
                Result = proceso
            };

            return response;
        }

        //Reporte Genérico - Exportar
        public async Task<DownloadFile> ExportarReporteGenerico(ReporteGenericoRequest reporteGenericoRequest)
        {
            DownloadFile _downloadFile;

            try
            {
                Workbook workbook = new Workbook();
                Worksheet sheet = workbook.Worksheets[0];
                int rowStart = 0;

                switch (reporteGenericoRequest.TipoReporte)
                {
                    case "PPU-MP": //Pendientes por Ubicar - Materia Prima

                        var lstReporte = await _reportesData.ListarMateriaPrimaExport(reporteGenericoRequest);

                        #region GENERAR EXCEL

                        //Worksheet sheet = workbook.Worksheets[0];
                        rowStart = 1;

                        //Cabecera - row: 1
                        rowStart++;
                        sheet.Range[rowStart, 1].Text = "Almacen Serie";
                        sheet.Range[rowStart, 2].Text = "Bobina Serie";
                        sheet.Range[rowStart, 3].Text = "Bobina Codigo";
                        sheet.Range[rowStart, 4].Text = "Ubi Almacen Serie";
                        sheet.Range[rowStart, 5].Text = "Ubi Subalmnum";
                        sheet.Range[rowStart, 6].Text = "Ubifisi Codigo";
                        sheet.Range[rowStart, 7].Text = "Bobina Peso";
                        sheet.Range[rowStart, 8].Text = "Bobina Peso Stock";
                        sheet.Range[rowStart, 9].Text = "Mitem Codigo";
                        sheet.Range[rowStart, 10].Text = "Item Descripcion";
                        sheet.Range[rowStart, 11].Text = "Unidad Codigo";
                        sheet.Range[rowStart, 12].Text = "Origen Descripcion";
                        sheet.Range[rowStart, 13].Text = "Linea Descripcion";
                        sheet.Range[rowStart, 14].Text = "Sublinea Descripcion";
                        sheet.Range[rowStart, 15].Text = "Bobina Fecha Ingreso";
                        sheet.Range[rowStart, 16].Text = "Flag";
                        sheet.Range[rowStart, 17].Text = "Hoia Secuencial";
                        sheet.Range[rowStart, 18].Text = "Trans Descripcion";
                        sheet.Range[rowStart, 19].Text = "Usu Ult Modif";
                        sheet.Range[rowStart, 20].Text = "Bobina Fec Ult Modif";
                        sheet.Range[rowStart, 21].Text = "Ubi Orig";
                        sheet.Range[rowStart, 22].Text = "Bobina Inventariada";
                        sheet.Range[rowStart, 23].Text = "Bobina Fec Leida";
                        sheet.Range[rowStart, 24].Text = "Bca Codigo";
                        sheet.Range[rowStart, 25].Text = "Bobina Observaciones";
                        sheet.Range[rowStart, 26].Text = "Ancho";
                        sheet.Range[rowStart, 27].Text = "Espesor";
                        sheet.Range[rowStart, 28].Text = "Bobina Fecha Salida";
                        sheet.Range[$"A1:AB1"].Style.Font.IsBold = true;
                        var data = lstReporte.MateriaPrima.ToList();
                        foreach (var d in data)
                        {
                            rowStart++;
                            sheet.Range[rowStart, 1].Text = d.almacen_serie.ToString();
                            sheet.Range[rowStart, 2].Text = d.bobi_serie.ToString();
                            sheet.Range[rowStart, 3].Text = d.bobi_codigo.ToString();
                            sheet.Range[rowStart, 4].Text = d.ubi_almacen_serie.ToString();
                            sheet.Range[rowStart, 5].Text = d.ubi_subalmnum.ToString();
                            sheet.Range[rowStart, 6].Text = d.ubifisi_codigo.ToString();
                            sheet.Range[rowStart, 7].Text = d.bobi_peso.ToString();
                            sheet.Range[rowStart, 8].Text = d.bobi_peso_stock.ToString();
                            sheet.Range[rowStart, 9].Text = d.mitem_codigo.ToString();
                            sheet.Range[rowStart, 10].Text = d.item_descripcio.ToString();
                            sheet.Range[rowStart, 11].Text = d.unidad_codigo.ToString();
                            sheet.Range[rowStart, 12].Text = d.origen_descripcion.ToString();
                            sheet.Range[rowStart, 13].Text = d.linea_descripcion.ToString();
                            sheet.Range[rowStart, 14].Text = d.sublinea_descripcion.ToString();
                            sheet.Range[rowStart, 15].Text = d.bobi_fecha_ingreso.ToString();
                            sheet.Range[rowStart, 16].Text = d.flag.ToString();
                            sheet.Range[rowStart, 17].Text = d.hoia_secuencial.ToString();
                            sheet.Range[rowStart, 18].Text = d.trans_descripcion.ToString();
                            sheet.Range[rowStart, 19].Text = d.usu_ult_modif.ToString();
                            sheet.Range[rowStart, 20].Text = d.bobi_fec_ult_modif.ToString();
                            sheet.Range[rowStart, 21].Text = d.ubic_orig.ToString();
                            sheet.Range[rowStart, 22].Text = d.bobina_inventariada.ToString();
                            sheet.Range[rowStart, 23].Text = d.bobi_fec_leida.ToString();
                            sheet.Range[rowStart, 24].Text = d.bca_codigo.ToString();
                            sheet.Range[rowStart, 25].Text = d.bobi_observaciones.ToString();
                            sheet.Range[rowStart, 26].Text = d.ancho.ToString();
                            sheet.Range[rowStart, 27].Text = d.espesor.ToString();
                            sheet.Range[rowStart, 28].Text = d.bobi_fecha_salida.ToString();
                        }

                        #endregion

                        break;
                    case "PPU-PP": //Pendientes por Ubicar - Productos en Proceso

                        var lstReportePPUPP = await _reportesData.ListarProductosEnProcesoExport(reporteGenericoRequest);

                        #region GENERAR EXCEL

                        //Worksheet sheet = workbook.Worksheets[0];
                        rowStart = 1;

                        //Cabecera - row: 1
                        rowStart++;
                        sheet.Range[rowStart, 1].Text = "Almacen Serie";
                        sheet.Range[rowStart, 2].Text = "Bobina Codigo";
                        sheet.Range[rowStart, 3].Text = "Bobina Serie";
                        sheet.Range[rowStart, 4].Text = "Item Codigo";
                        sheet.Range[rowStart, 5].Text = "Bobina Peso";
                        sheet.Range[rowStart, 6].Text = "Unidad Codigo";
                        sheet.Range[rowStart, 7].Text = "Bobina Longitud";
                        sheet.Range[rowStart, 8].Text = "Bobina Fecha Ingreso";
                        sheet.Range[rowStart, 9].Text = "Bobina Peso Bruto";
                        sheet.Range[rowStart, 10].Text = "Bobina Inventariada";
                        sheet.Range[rowStart, 11].Text = "Hproc Secuencial";
                        sheet.Range[rowStart, 12].Text = "Condicion Codigo";
                        sheet.Range[rowStart, 13].Text = "Orden de Trabajo";
                        sheet.Range[rowStart, 14].Text = "Proceso Codigo";
                        sheet.Range[rowStart, 15].Text = "Maquina Codigo";
                        sheet.Range[rowStart, 16].Text = "Almacen Serie Transfer";
                        sheet.Range[rowStart, 17].Text = "Dmot Codigo";
                        sheet.Range[rowStart, 18].Text = "Motivo 2";
                        sheet.Range[rowStart, 19].Text = "Mot Devolucion";
                        sheet.Range[rowStart, 20].Text = "Item Descripcion";
                        sheet.Range[rowStart, 21].Text = "Unidad Equivalente";
                        sheet.Range[rowStart, 22].Text = "Cantidad Equivalente";
                        sheet.Range[rowStart, 23].Text = "Planta Serie";
                        sheet.Range[rowStart, 24].Text = "Codigo Transaccion";
                        sheet.Range[rowStart, 25].Text = "Causa Descripcion";
                        sheet.Range[rowStart, 26].Text = "Hped Numero";
                        sheet.Range[rowStart, 27].Text = "Situacion";
                        sheet.Range[rowStart, 28].Text = "Vendedor Nombre";
                        sheet.Range[rowStart, 29].Text = "Hproc Fecha Grab";
                        sheet.Range[rowStart, 30].Text = "Ubisifi Codigo";
                        sheet.Range[rowStart, 31].Text = "Bobina Fecha Prod";
                        sheet.Range[rowStart, 32].Text = "Codigo Naturaleza";
                        sheet.Range[rowStart, 33].Text = "Bobina Fecha Leida";
                        sheet.Range[$"A1:AG1"].Style.Font.IsBold = true;
                        var dataPPUPP = lstReportePPUPP.ProductosEnProceso.ToList();
                        foreach (var d in dataPPUPP)
                        {
                            rowStart++;
                            sheet.Range[rowStart, 1].Text = d.almacen_serie.ToString();
                            sheet.Range[rowStart, 2].Text = d.bobi_codigo.ToString();
                            sheet.Range[rowStart, 3].Text = d.bobi_serie.ToString();
                            sheet.Range[rowStart, 4].Text = d.mitem_codigo.ToString();
                            sheet.Range[rowStart, 5].Text = d.bobi_peso.ToString();
                            sheet.Range[rowStart, 6].Text = d.unidad_codigo.ToString();
                            sheet.Range[rowStart, 7].Text = d.bobina_longitud.ToString();
                            sheet.Range[rowStart, 8].Text = d.bobi_fecha_ingreso.ToString();
                            sheet.Range[rowStart, 9].Text = d.bobina_peso_bruto.ToString();
                            sheet.Range[rowStart, 10].Text = d.bobina_inventariada.ToString();
                            sheet.Range[rowStart, 11].Text = d.hproc_secuencial.ToString();
                            sheet.Range[rowStart, 12].Text = d.condicion_codigo.ToString();
                            sheet.Range[rowStart, 13].Text = d.hord_trab_secuencial.ToString();
                            sheet.Range[rowStart, 14].Text = d.proceso_codigo.ToString();
                            sheet.Range[rowStart, 15].Text = d.maquina_codigo.ToString();
                            sheet.Range[rowStart, 16].Text = d.alm_serie_transfer.ToString();
                            sheet.Range[rowStart, 17].Text = d.dmot_codigo.ToString();
                            sheet.Range[rowStart, 18].Text = d.MOTIVO2.ToString();
                            sheet.Range[rowStart, 19].Text = d.mot_devolucion.ToString();
                            sheet.Range[rowStart, 20].Text = d.item_descripcio.ToString();
                            sheet.Range[rowStart, 21].Text = d.unidad_equivalente.ToString();
                            sheet.Range[rowStart, 22].Text = d.cantidad_equivalente.ToString();
                            sheet.Range[rowStart, 23].Text = d.planta_serie.ToString();
                            sheet.Range[rowStart, 24].Text = d.codigo_transaccion.ToString();
                            sheet.Range[rowStart, 25].Text = d.causa_descripcion.ToString();
                            sheet.Range[rowStart, 26].Text = d.hped_numero.ToString();
                            sheet.Range[rowStart, 27].Text = d.situacion.ToString();
                            sheet.Range[rowStart, 28].Text = d.vendedor_nombre.ToString();
                            sheet.Range[rowStart, 29].Text = d.hproc_fecha_grab.ToString();
                            sheet.Range[rowStart, 30].Text = d.ubifisi_codigo.ToString();
                            sheet.Range[rowStart, 31].Text = d.bobi_fec_prod.ToString();
                            sheet.Range[rowStart, 32].Text = d.cod_naturaleza.ToString();
                            sheet.Range[rowStart, 33].Text = d.bobi_fec_leida.ToString();
                        }

                        #endregion

                        break;
                    case "PPU-PT": //Pendientes por Ubicar - Productos Terminados

                        var lstReportePPUPT = await _reportesData.ListarProductosTerminadosExport(reporteGenericoRequest);

                        #region GENERAR EXCEL

                        //Worksheet sheet = workbook.Worksheets[0];
                        rowStart = 1;

                        //Cabecera - row: 1
                        rowStart++;
                        sheet.Range[rowStart, 1].Text = "Tipo";
                        sheet.Range[rowStart, 2].Text = "Descripcion del Tipo";
                        sheet.Range[rowStart, 3].Text = "Bobina Inventariada";
                        sheet.Range[rowStart, 4].Text = "Bobina Serie";
                        sheet.Range[rowStart, 5].Text = "Bobina Codigo";
                        sheet.Range[rowStart, 6].Text = "Bobina Peso";
                        sheet.Range[rowStart, 7].Text = "Bobina Peso Bruto";
                        sheet.Range[rowStart, 8].Text = "Bobina Unidad Codigo";
                        sheet.Range[rowStart, 9].Text = "Bobina Longitud";
                        sheet.Range[rowStart, 10].Text = "Item Codigo";
                        sheet.Range[rowStart, 11].Text = "Unidad Codigo";
                        sheet.Range[rowStart, 12].Text = "Almacen Serie";
                        sheet.Range[rowStart, 13].Text = "Item Descripcion";
                        sheet.Range[rowStart, 14].Text = "Planta Serie";
                        sheet.Range[rowStart, 15].Text = "Orden de Trabajo";
                        sheet.Range[rowStart, 16].Text = "Descripcion Tamaño";
                        sheet.Range[rowStart, 17].Text = "Item Gramaje";
                        sheet.Range[rowStart, 18].Text = "Unidad Equivalente";
                        sheet.Range[rowStart, 19].Text = "Cantidad Equivalente";
                        sheet.Range[rowStart, 20].Text = "Sucursal Descripcion";
                        sheet.Range[rowStart, 21].Text = "Pedido";
                        sheet.Range[rowStart, 22].Text = "Cliente";
                        sheet.Range[rowStart, 23].Text = "Hproc Secuencial";
                        sheet.Range[rowStart, 24].Text = "Condicion Codigo";
                        sheet.Range[rowStart, 25].Text = "Condicion Descripcion";
                        sheet.Range[rowStart, 26].Text = "Fecha de Grabacion";
                        sheet.Range[rowStart, 27].Text = "Ubisifi Codigo";
                        sheet.Range[rowStart, 28].Text = "Fecha de Produccion";
                        sheet.Range[$"A1:AB1"].Style.Font.IsBold = true;
                        var dataPPUPT = lstReportePPUPT.ProductosTerminados.ToList();
                        foreach (var d in dataPPUPT)
                        {
                            rowStart++;
                            sheet.Range[rowStart, 1].Text = d.tipo.ToString();
                            sheet.Range[rowStart, 2].Text = d.desc_tipo.ToString();
                            sheet.Range[rowStart, 3].Text = d.bobina_inventariada.ToString();
                            sheet.Range[rowStart, 4].Text = d.bobi_serie.ToString();
                            sheet.Range[rowStart, 5].Text = d.bobi_codigo.ToString();
                            sheet.Range[rowStart, 6].Text = d.bobi_peso.ToString();
                            sheet.Range[rowStart, 7].Text = d.bobina_peso_bruto.ToString();
                            sheet.Range[rowStart, 8].Text = d.bobina_unidad_codigo.ToString();
                            sheet.Range[rowStart, 9].Text = d.bobina_longitud.ToString();
                            sheet.Range[rowStart, 10].Text = d.mitem_codigo.ToString();
                            sheet.Range[rowStart, 11].Text = d.unidad_codigo.ToString();
                            sheet.Range[rowStart, 12].Text = d.almacen_serie.ToString();
                            sheet.Range[rowStart, 13].Text = d.item_descripcio.ToString();
                            sheet.Range[rowStart, 14].Text = d.planta_serie.ToString();
                            sheet.Range[rowStart, 15].Text = d.hord_trab_secuencial.ToString();
                            sheet.Range[rowStart, 16].Text = d.descripcion_tamano.ToString();
                            sheet.Range[rowStart, 17].Text = d.mitem_gramaje.ToString();
                            sheet.Range[rowStart, 18].Text = d.unidad_equivalente.ToString();
                            sheet.Range[rowStart, 19].Text = d.cantidad_equivalente.ToString();
                            sheet.Range[rowStart, 20].Text = d.pedido.ToString();
                            sheet.Range[rowStart, 21].Text = d.cliente.ToString();
                            sheet.Range[rowStart, 22].Text = d.sucursal_descripcion.ToString();
                            sheet.Range[rowStart, 23].Text = d.hproc_secuencial.ToString();
                            sheet.Range[rowStart, 24].Text = d.condicion_codigo.ToString();
                            sheet.Range[rowStart, 25].Text = d.condicion_descripcion.ToString();
                            sheet.Range[rowStart, 26].Text = d.hproc_fecha_grab.ToString();
                            sheet.Range[rowStart, 27].Text = d.ubifisi_codigo.ToString();
                            sheet.Range[rowStart, 28].Text = d.bobi_fec_prod.ToString();
                        }

                        #endregion

                        break;
                    case "KB-K": //Kardex Bobina - Kardex

                        var lstReporteKBK = await _reportesData.ListarKardexBobinaExport(reporteGenericoRequest);

                        #region GENERAR EXCEL

                        //Worksheet sheet = workbook.Worksheets[0];
                        rowStart = 1;

                        //Cabecera - row: 1
                        rowStart++;
                        sheet.Range[rowStart, 1].Text = "Fecha Grabacion";
                        sheet.Range[rowStart, 2].Text = "Bobina Codigo";
                        sheet.Range[rowStart, 3].Text = "Bobina Serie";
                        sheet.Range[rowStart, 4].Text = "Ubifisi Codigo";
                        sheet.Range[rowStart, 5].Text = "Ubi Almacen Serie";
                        sheet.Range[rowStart, 6].Text = "Unidad Codigo";
                        sheet.Range[rowStart, 7].Text = "Usu Ult Modificacion";
                        sheet.Range[rowStart, 8].Text = "Bobina Peso";
                        sheet.Range[rowStart, 9].Text = "Bobina Peso Stock";
                        sheet.Range[rowStart, 10].Text = "Mitem Codigo";
                        sheet.Range[rowStart, 11].Text = "Descripcion";
                        sheet.Range[rowStart, 12].Text = "Almacen Serie";
                        sheet.Range[rowStart, 13].Text = "Bobina Estado";
                        sheet.Range[$"A1:M1"].Style.Font.IsBold = true;
                        var dataKbk = lstReporteKBK.KardexBobina.ToList();
                        foreach (var d in dataKbk)
                        {
                            rowStart++;
                            sheet.Range[rowStart, 1].Text = d.fechaGrabacion.ToString();
                            sheet.Range[rowStart, 2].Text = d.bobiCodigo.ToString();
                            sheet.Range[rowStart, 3].Text = d.bobiSerie.ToString();
                            sheet.Range[rowStart, 4].Text = d.ubifisiCodigo.ToString();
                            sheet.Range[rowStart, 5].Text = d.ubiAlmacenSerie.ToString();
                            sheet.Range[rowStart, 6].Text = d.unidadCodigo.ToString();
                            sheet.Range[rowStart, 7].Text = d.usuUltModif.ToString();
                            sheet.Range[rowStart, 8].Text = d.bobiPeso.ToString();
                            sheet.Range[rowStart, 9].Text = d.bobiPesoStock.ToString();
                            sheet.Range[rowStart, 10].Text = d.mitemCodigo.ToString();
                            sheet.Range[rowStart, 11].Text = d.descripcion.ToString();
                            sheet.Range[rowStart, 12].Text = d.almacenSerie.ToString();
                            sheet.Range[rowStart, 13].Text = d.bobiEstado.ToString();
                        }

                        #endregion

                        break;
                    case "BPNC-R": //Bobina con PNC - Reporte
                        var lstReporteBPNC = await _reportesData.ListarBobinaConPNCExport(reporteGenericoRequest);
                        #region GENERAR EXCEL
                        rowStart = 1;

                        //Cabecera - row: 1
                        rowStart++;
                        sheet.Range[rowStart, 1].Text = "Almacen Serie";
                        sheet.Range[rowStart, 2].Text = "Bobina Serie";
                        sheet.Range[rowStart, 3].Text = "Bobina Codigo";
                        sheet.Range[rowStart, 4].Text = "Bobina Peso";
                        sheet.Range[rowStart, 5].Text = "Bobina Peso Stock";
                        sheet.Range[rowStart, 6].Text = "Hoia Fecha Oia";
                        sheet.Range[rowStart, 7].Text = "Hoia Secuencial";
                        sheet.Range[rowStart, 8].Text = "Codigo Transaccion";
                        sheet.Range[rowStart, 9].Text = "Orden Panasa";
                        sheet.Range[rowStart, 10].Text = "Mitem Codigo";
                        sheet.Range[rowStart, 11].Text = "Unidad Codigo";
                        sheet.Range[rowStart, 12].Text = "Bobina Inventariada";
                        sheet.Range[rowStart, 13].Text = "Descripcion Proveedor";
                        sheet.Range[rowStart, 14].Text = "Num Compra";
                        sheet.Range[rowStart, 15].Text = "Bobina Estado";
                        sheet.Range[rowStart, 16].Text = "Sec PNC";
                        sheet.Range[rowStart, 17].Text = "CC Result";
                        sheet.Range[rowStart, 18].Text = "Sec PNC Tiempo";
                        sheet.Range[rowStart, 19].Text = "Ubi Almacen Serie";
                        sheet.Range[rowStart, 20].Text = "Ubi Sublamnum";
                        sheet.Range[rowStart, 21].Text = "Ubifisi Codigo";
                        sheet.Range[rowStart, 22].Text = "Bp Lote";
                        sheet.Range[rowStart, 23].Text = "Hcc Fecha Muestra";
                        sheet.Range[rowStart, 24].Text = "Fecha Emusa";
                        sheet.Range[$"A1:AB1"].Style.Font.IsBold = true;
                        var dataBPNC = lstReporteBPNC.BobinaConPNC.ToList();
                        foreach (var d in dataBPNC)
                        {
                            rowStart++;
                            sheet.Range[rowStart, 1].Text = d.almacen_serie.ToString();
                            sheet.Range[rowStart, 2].Text = d.bobi_serie.ToString();
                            sheet.Range[rowStart, 3].Text = d.bobi_codigo.ToString();
                            sheet.Range[rowStart, 4].Text = d.bobi_peso.ToString();
                            sheet.Range[rowStart, 5].Text = d.bobi_peso_stock.ToString();
                            sheet.Range[rowStart, 6].Text = d.hoia_fecha_oia.ToString();
                            sheet.Range[rowStart, 7].Text = d.hoia_secuencial.ToString();
                            sheet.Range[rowStart, 8].Text = d.codigo_transaccion.ToString();
                            sheet.Range[rowStart, 9].Text = d.porden_int_panasa.ToString();
                            sheet.Range[rowStart, 10].Text = d.mitem_codigo.ToString();
                            sheet.Range[rowStart, 11].Text = d.unidad_codigo.ToString();
                            sheet.Range[rowStart, 12].Text = d.bobina_inventariada.ToString();
                            sheet.Range[rowStart, 13].Text = d.desc_proveedor.ToString();
                            sheet.Range[rowStart, 14].Text = d.num_compra.ToString();
                            sheet.Range[rowStart, 15].Text = d.bobi_estado.ToString();
                            sheet.Range[rowStart, 16].Text = d.cc_result.ToString();
                            sheet.Range[rowStart, 17].Text = d.sec_pnc.ToString();
                            sheet.Range[rowStart, 18].Text = d.sec_pnc_tiempo.ToString();
                            sheet.Range[rowStart, 19].Text = d.ubi_almacen_serie.ToString();
                            sheet.Range[rowStart, 20].Text = d.ubi_subalmnum.ToString();
                            sheet.Range[rowStart, 21].Text = d.ubifisi_codigo.ToString();
                            sheet.Range[rowStart, 22].Text = d.bp_lote.ToString();
                            sheet.Range[rowStart, 23].Text = d.hcc_fecha_muestra.ToString();
                            sheet.Range[rowStart, 24].Text = d.fecha_emusa.ToString();
                        }
                        #endregion
                        break;
                    case "DI-MP": //Desarrollo de Inventario - Materia Prima

                        var lstReporteDIMP = await _reportesData.ListarMateriaPrimaDExport(reporteGenericoRequest);

                        #region GENERAR EXCEL

                        //Worksheet sheet = workbook.Worksheets[0];
                        rowStart = 1;

                        //Cabecera - row: 1
                        rowStart++;
                        sheet.Range[rowStart, 1].Text = "Almacen Serie";
                        sheet.Range[rowStart, 2].Text = "Bobina Serie";
                        sheet.Range[rowStart, 3].Text = "Bobina Codigo";
                        sheet.Range[rowStart, 4].Text = "Ubi Almacen Serie";
                        sheet.Range[rowStart, 5].Text = "Ubi Subalmnum";
                        sheet.Range[rowStart, 6].Text = "Ubifisi Codigo";
                        sheet.Range[rowStart, 7].Text = "Bobina Peso";
                        sheet.Range[rowStart, 8].Text = "Bobina Peso Stock";
                        sheet.Range[rowStart, 9].Text = "Mitem Codigo";
                        sheet.Range[rowStart, 10].Text = "Item Descripcion";
                        sheet.Range[rowStart, 11].Text = "Unidad Codigo";
                        sheet.Range[rowStart, 12].Text = "Origen Descripcion";
                        sheet.Range[rowStart, 13].Text = "Linea Descripcion";
                        sheet.Range[rowStart, 14].Text = "Sublinea Descripcion";
                        sheet.Range[rowStart, 15].Text = "Bobina Fecha Ingreso";
                        sheet.Range[rowStart, 16].Text = "Flag";
                        sheet.Range[rowStart, 17].Text = "Hoia Secuencial";
                        sheet.Range[rowStart, 18].Text = "Trans Descripcion";
                        sheet.Range[rowStart, 19].Text = "Usu Ult Modif";
                        sheet.Range[rowStart, 20].Text = "Bobina Fec Ult Modif";
                        sheet.Range[rowStart, 21].Text = "Ubi Orig";
                        sheet.Range[rowStart, 22].Text = "Bobina Inventariada";
                        sheet.Range[rowStart, 23].Text = "Bobina Fec Leida";
                        sheet.Range[rowStart, 24].Text = "Bca Codigo";
                        sheet.Range[rowStart, 25].Text = "Bobina Observaciones";
                        sheet.Range[rowStart, 26].Text = "Ancho";
                        sheet.Range[rowStart, 27].Text = "Espesor";
                        sheet.Range[rowStart, 28].Text = "Bobina Fecha Salida";
                        sheet.Range[$"A1:AB1"].Style.Font.IsBold = true;
                        var dataDIMP = lstReporteDIMP.MateriaPrima.ToList();
                        foreach (var d in dataDIMP)
                        {
                            rowStart++;
                            sheet.Range[rowStart, 1].Text = d.almacen_serie.ToString();
                            sheet.Range[rowStart, 2].Text = d.bobi_serie.ToString();
                            sheet.Range[rowStart, 3].Text = d.bobi_codigo.ToString();
                            sheet.Range[rowStart, 4].Text = d.ubi_almacen_serie.ToString();
                            sheet.Range[rowStart, 5].Text = d.ubi_subalmnum.ToString();
                            sheet.Range[rowStart, 6].Text = d.ubifisi_codigo.ToString();
                            sheet.Range[rowStart, 7].Text = d.bobi_peso.ToString();
                            sheet.Range[rowStart, 8].Text = d.bobi_peso_stock.ToString();
                            sheet.Range[rowStart, 9].Text = d.mitem_codigo.ToString();
                            sheet.Range[rowStart, 10].Text = d.item_descripcio.ToString();
                            sheet.Range[rowStart, 11].Text = d.unidad_codigo.ToString();
                            sheet.Range[rowStart, 12].Text = d.origen_descripcion.ToString();
                            sheet.Range[rowStart, 13].Text = d.linea_descripcion.ToString();
                            sheet.Range[rowStart, 14].Text = d.sublinea_descripcion.ToString();
                            sheet.Range[rowStart, 15].Text = d.bobi_fecha_ingreso.ToString();
                            sheet.Range[rowStart, 16].Text = d.flag.ToString();
                            sheet.Range[rowStart, 17].Text = d.hoia_secuencial.ToString();
                            sheet.Range[rowStart, 18].Text = d.trans_descripcion.ToString();
                            sheet.Range[rowStart, 19].Text = d.usu_ult_modif.ToString();
                            sheet.Range[rowStart, 20].Text = d.bobi_fec_ult_modif.ToString();
                            sheet.Range[rowStart, 21].Text = d.ubic_orig.ToString();
                            sheet.Range[rowStart, 22].Text = d.bobina_inventariada.ToString();
                            sheet.Range[rowStart, 23].Text = d.bobi_fec_leida.ToString();
                            sheet.Range[rowStart, 24].Text = d.bca_codigo.ToString();
                            sheet.Range[rowStart, 25].Text = d.bobi_observaciones.ToString();
                            sheet.Range[rowStart, 26].Text = d.ancho.ToString();
                            sheet.Range[rowStart, 27].Text = d.espesor.ToString();
                            sheet.Range[rowStart, 28].Text = d.bobi_fecha_salida.ToString();
                        }

                        #endregion

                        break;
                    case "DI-PP": //Desarrollo de Inventario - Productos en Proceso

                        var lstReporteDIPP = await _reportesData.ListarProductosEnProcesoDExport(reporteGenericoRequest);

                        #region GENERAR EXCEL

                        //Worksheet sheet = workbook.Worksheets[0];
                        rowStart = 1;

                        //Cabecera - row: 1
                        rowStart++;
                        sheet.Range[rowStart, 1].Text = "Almacen Serie";
                        sheet.Range[rowStart, 2].Text = "Bobina Codigo";
                        sheet.Range[rowStart, 3].Text = "Bobina Serie";
                        sheet.Range[rowStart, 4].Text = "Item Codigo";
                        sheet.Range[rowStart, 5].Text = "Bobina Peso";
                        sheet.Range[rowStart, 6].Text = "Unidad Codigo";
                        sheet.Range[rowStart, 7].Text = "Bobina Longitud";
                        sheet.Range[rowStart, 8].Text = "Bobina Fecha Ingreso";
                        sheet.Range[rowStart, 9].Text = "Bobina Peso Bruto";
                        sheet.Range[rowStart, 10].Text = "Bobina Inventariada";
                        sheet.Range[rowStart, 11].Text = "Hproc Secuencial";
                        sheet.Range[rowStart, 12].Text = "Condicion Codigo";
                        sheet.Range[rowStart, 13].Text = "Orden de Trabajo";
                        sheet.Range[rowStart, 14].Text = "Proceso Codigo";
                        sheet.Range[rowStart, 15].Text = "Maquina Codigo";
                        sheet.Range[rowStart, 16].Text = "Almacen Serie Transfer";
                        sheet.Range[rowStart, 17].Text = "Dmot Codigo";
                        sheet.Range[rowStart, 18].Text = "Motivo 2";
                        sheet.Range[rowStart, 19].Text = "Mot Devolucion";
                        sheet.Range[rowStart, 20].Text = "Item Descripcion";
                        sheet.Range[rowStart, 21].Text = "Unidad Equivalente";
                        sheet.Range[rowStart, 22].Text = "Cantidad Equivalente";
                        sheet.Range[rowStart, 23].Text = "Planta Serie";
                        sheet.Range[rowStart, 24].Text = "Codigo Transaccion";
                        sheet.Range[rowStart, 25].Text = "Causa Descripcion";
                        sheet.Range[rowStart, 26].Text = "Hped Numero";
                        sheet.Range[rowStart, 27].Text = "Situacion";
                        sheet.Range[rowStart, 28].Text = "Vendedor Nombre";
                        sheet.Range[rowStart, 29].Text = "Hproc Fecha Grab";
                        sheet.Range[rowStart, 30].Text = "Ubisifi Codigo";
                        sheet.Range[rowStart, 31].Text = "Bobina Fecha Prod";
                        sheet.Range[rowStart, 32].Text = "Codigo Naturaleza";
                        sheet.Range[rowStart, 33].Text = "Bobina Fecha Leida";
                        sheet.Range[$"A1:AG1"].Style.Font.IsBold = true;
                        var dataDIPP = lstReporteDIPP.ProductosEnProceso.ToList();
                        foreach (var d in dataDIPP)
                        {
                            rowStart++;
                            sheet.Range[rowStart, 1].Text = d.almacen_serie.ToString();
                            sheet.Range[rowStart, 2].Text = d.bobi_codigo.ToString();
                            sheet.Range[rowStart, 3].Text = d.bobi_serie.ToString();
                            sheet.Range[rowStart, 4].Text = d.mitem_codigo.ToString();
                            sheet.Range[rowStart, 5].Text = d.bobi_peso.ToString();
                            sheet.Range[rowStart, 6].Text = d.unidad_codigo.ToString();
                            sheet.Range[rowStart, 7].Text = d.bobina_longitud.ToString();
                            sheet.Range[rowStart, 8].Text = d.bobi_fecha_ingreso.ToString();
                            sheet.Range[rowStart, 9].Text = d.bobina_peso_bruto.ToString();
                            sheet.Range[rowStart, 10].Text = d.bobina_inventariada.ToString();
                            sheet.Range[rowStart, 11].Text = d.hproc_secuencial.ToString();
                            sheet.Range[rowStart, 12].Text = d.condicion_codigo.ToString();
                            sheet.Range[rowStart, 13].Text = d.hord_trab_secuencial.ToString();
                            sheet.Range[rowStart, 14].Text = d.proceso_codigo.ToString();
                            sheet.Range[rowStart, 15].Text = d.maquina_codigo.ToString();
                            sheet.Range[rowStart, 16].Text = d.alm_serie_transfer.ToString();
                            sheet.Range[rowStart, 17].Text = d.dmot_codigo.ToString();
                            sheet.Range[rowStart, 18].Text = d.MOTIVO2.ToString();
                            sheet.Range[rowStart, 19].Text = d.mot_devolucion.ToString();
                            sheet.Range[rowStart, 20].Text = d.item_descripcio.ToString();
                            sheet.Range[rowStart, 21].Text = d.unidad_equivalente.ToString();
                            sheet.Range[rowStart, 22].Text = d.cantidad_equivalente.ToString();
                            sheet.Range[rowStart, 23].Text = d.planta_serie.ToString();
                            sheet.Range[rowStart, 24].Text = d.codigo_transaccion.ToString();
                            sheet.Range[rowStart, 25].Text = d.causa_descripcion.ToString();
                            sheet.Range[rowStart, 26].Text = d.hped_numero.ToString();
                            sheet.Range[rowStart, 27].Text = d.situacion.ToString();
                            sheet.Range[rowStart, 28].Text = d.vendedor_nombre.ToString();
                            sheet.Range[rowStart, 29].Text = d.hproc_fecha_grab.ToString();
                            sheet.Range[rowStart, 30].Text = d.ubifisi_codigo.ToString();
                            sheet.Range[rowStart, 31].Text = d.bobi_fec_prod.ToString();
                            sheet.Range[rowStart, 32].Text = d.cod_naturaleza.ToString();
                            sheet.Range[rowStart, 33].Text = d.bobi_fec_leida.ToString();
                        }

                        #endregion

                        break;
                    case "DI-PT": //Desarrollo de Inventario - Productos Terminados

                        var lstReporteDIPT = await _reportesData.ListarProductosTerminadosDExport(reporteGenericoRequest);

                        #region GENERAR EXCEL

                        //Worksheet sheet = workbook.Worksheets[0];
                        rowStart = 1;

                        //Cabecera - row: 1
                        rowStart++;
                        sheet.Range[rowStart, 1].Text = "Tipo";
                        sheet.Range[rowStart, 2].Text = "Descripcion del Tipo";
                        sheet.Range[rowStart, 3].Text = "Bobina Inventariada";
                        sheet.Range[rowStart, 4].Text = "Bobina Serie";
                        sheet.Range[rowStart, 5].Text = "Bobina Codigo";
                        sheet.Range[rowStart, 6].Text = "Bobina Peso";
                        sheet.Range[rowStart, 7].Text = "Bobina Peso Bruto";
                        sheet.Range[rowStart, 8].Text = "Bobina Unidad Codigo";
                        sheet.Range[rowStart, 9].Text = "Bobina Longitud";
                        sheet.Range[rowStart, 10].Text = "Item Codigo";
                        sheet.Range[rowStart, 11].Text = "Unidad Codigo";
                        sheet.Range[rowStart, 12].Text = "Almacen Serie";
                        sheet.Range[rowStart, 13].Text = "Item Descripcion";
                        sheet.Range[rowStart, 14].Text = "Planta Serie";
                        sheet.Range[rowStart, 15].Text = "Orden de Trabajo";
                        sheet.Range[rowStart, 16].Text = "Descripcion Tamaño";
                        sheet.Range[rowStart, 17].Text = "Item Gramaje";
                        sheet.Range[rowStart, 18].Text = "Unidad Equivalente";
                        sheet.Range[rowStart, 19].Text = "Cantidad Equivalente";
                        sheet.Range[rowStart, 20].Text = "Sucursal Descripcion";
                        sheet.Range[rowStart, 21].Text = "Pedido";
                        sheet.Range[rowStart, 22].Text = "Cliente";
                        sheet.Range[rowStart, 23].Text = "Hproc Secuencial";
                        sheet.Range[rowStart, 24].Text = "Condicion Codigo";
                        sheet.Range[rowStart, 25].Text = "Condicion Descripcion";
                        sheet.Range[rowStart, 26].Text = "Fecha de Grabacion";
                        sheet.Range[rowStart, 27].Text = "Ubisifi Codigo";
                        sheet.Range[rowStart, 28].Text = "Fecha de Produccion";
                        sheet.Range[$"A1:AB1"].Style.Font.IsBold = true;
                        var dataDIPT = lstReporteDIPT.ProductosTerminados.ToList();
                        foreach (var d in dataDIPT)
                        {
                            rowStart++;
                            sheet.Range[rowStart, 1].Text = d.tipo.ToString();
                            sheet.Range[rowStart, 2].Text = d.desc_tipo.ToString();
                            sheet.Range[rowStart, 3].Text = d.bobina_inventariada.ToString();
                            sheet.Range[rowStart, 4].Text = d.bobi_serie.ToString();
                            sheet.Range[rowStart, 5].Text = d.bobi_codigo.ToString();
                            sheet.Range[rowStart, 6].Text = d.bobi_peso.ToString();
                            sheet.Range[rowStart, 7].Text = d.bobina_peso_bruto.ToString();
                            sheet.Range[rowStart, 8].Text = d.bobina_unidad_codigo.ToString();
                            sheet.Range[rowStart, 9].Text = d.bobina_longitud.ToString();
                            sheet.Range[rowStart, 10].Text = d.mitem_codigo.ToString();
                            sheet.Range[rowStart, 11].Text = d.unidad_codigo.ToString();
                            sheet.Range[rowStart, 12].Text = d.almacen_serie.ToString();
                            sheet.Range[rowStart, 13].Text = d.item_descripcio.ToString();
                            sheet.Range[rowStart, 14].Text = d.planta_serie.ToString();
                            sheet.Range[rowStart, 15].Text = d.hord_trab_secuencial.ToString();
                            sheet.Range[rowStart, 16].Text = d.descripcion_tamano.ToString();
                            sheet.Range[rowStart, 17].Text = d.mitem_gramaje.ToString();
                            sheet.Range[rowStart, 18].Text = d.unidad_equivalente.ToString();
                            sheet.Range[rowStart, 19].Text = d.cantidad_equivalente.ToString();
                            sheet.Range[rowStart, 20].Text = d.pedido.ToString();
                            sheet.Range[rowStart, 21].Text = d.cliente.ToString();
                            sheet.Range[rowStart, 22].Text = d.sucursal_descripcion.ToString();
                            sheet.Range[rowStart, 23].Text = d.hproc_secuencial.ToString();
                            sheet.Range[rowStart, 24].Text = d.condicion_codigo.ToString();
                            sheet.Range[rowStart, 25].Text = d.condicion_descripcion.ToString();
                            sheet.Range[rowStart, 26].Text = d.hproc_fecha_grab.ToString();
                            sheet.Range[rowStart, 27].Text = d.ubifisi_codigo.ToString();
                            sheet.Range[rowStart, 28].Text = d.bobi_fec_prod.ToString();
                        }

                        #endregion

                        break;
                    case "PP-R": //Proceso de Producción - Reporte
                        var lstReportePPR = await _reportesData.ListarProcesoDeProduccionExport(reporteGenericoRequest);
                        #region GENERAR EXCEL
                        rowStart = 1;

                        //Cabecera - row: 1
                        rowStart++;
                        sheet.Range[rowStart, 1].Text = "Hproc Fecha Grabacion";
                        sheet.Range[rowStart, 2].Text = "Proceso Codigo";
                        sheet.Range[rowStart, 3].Text = "Maquina Codigo";
                        sheet.Range[rowStart, 4].Text = "Unidad Equivalente";
                        sheet.Range[rowStart, 5].Text = "Cantidad Equivalente";
                        sheet.Range[rowStart, 6].Text = "Plante Serie";
                        sheet.Range[rowStart, 7].Text = "Hord Trab Secuencial";
                        sheet.Range[rowStart, 8].Text = "Maquina Descripcion";
                        sheet.Range[rowStart, 9].Text = "Proceso Descripcion";
                        sheet.Range[rowStart, 10].Text = "Eproc Bobina Peso";
                        sheet.Range[$"A1:AB1"].Style.Font.IsBold = true;
                        var dataPPR = lstReportePPR.ProcesoProduccion.ToList();
                        foreach (var d in dataPPR)
                        {
                            rowStart++;
                            sheet.Range[rowStart, 1].Text = d.hproc_fecha_grab.ToString();
                            sheet.Range[rowStart, 2].Text = d.proceso_codigo.ToString();
                            sheet.Range[rowStart, 3].Text = d.maquina_codigo.ToString();
                            sheet.Range[rowStart, 4].Text = d.unidad_equivalente.ToString();
                            sheet.Range[rowStart, 5].Text = d.cantidad_equivalente.ToString();
                            sheet.Range[rowStart, 6].Text = d.planta_serie.ToString();
                            sheet.Range[rowStart, 7].Text = d.hord_trab_secuencial.ToString();
                            sheet.Range[rowStart, 8].Text = d.maquina_descripcion.ToString();
                            sheet.Range[rowStart, 9].Text = d.proceso_descripcion.ToString();
                            sheet.Range[rowStart, 10].Text = d.eproc_bobi_peso.ToString();
                        }
                        #endregion
                        break;
                }

                var memory = new MemoryStream();
                workbook.SaveToStream(memory);
                memory.Position = 0;

                _downloadFile = new DownloadFile { ContentType = "application/octet-stream", Memory = memory, FileName = $"Reporte_Reclamos_{DateTime.Now:ddMMyyyy}.xls" };
                return _downloadFile;
            }
            catch (Exception)
            {
                _downloadFile = new DownloadFile { ContentType = string.Empty, Memory = null };
                return _downloadFile;
            }

        }

    }
}
