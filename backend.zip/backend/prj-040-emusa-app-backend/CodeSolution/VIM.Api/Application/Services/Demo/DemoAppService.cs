﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using VIM.Api.Application.Repository.Demo;
using VIM.Application.Shared.TransferObject.Request.Demo;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Demo;

namespace VIM.Api.Application.Services.Demo
{
    public class DemoAppService : IDemoAppService
    {
        private readonly IDemoData _dDemo;

        public DemoAppService(IConfiguration configuration)
        {
            _dDemo = new DemoData(configuration.GetConnectionString("defaultConnection"));
        }

        public async Task<Response<bool>> ActualizarProducto(ProductoRequest productoRequest)
        {
            Response<bool> _response;
            ResultEntity _resultEntity;
            try
            {
                using (var transaction = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    _resultEntity = await _dDemo.ActualizarProducto(productoRequest);
                    transaction.Complete();
                }

                _response = new Response<bool>
                {
                    Status = _resultEntity.Result
                };
            }
            catch (Exception ex)
            {
                _response = new Response<bool>()
                {
                    Status = false,
                    Message = ex.Message
                };
            }
            return _response;
        }

        public async Task<Response<List<ProductoResponse>>> ListarProductos()
        {
            var productos = await _dDemo.ListarProductos();

            var response = new Response<List<ProductoResponse>>
            {
                Result = productos
            };

            return response;
        }

        public async Task<Response<ProductoResponse>> ObtenerProducto(ProductoRequest productoRequest)
        {
            var producto = await _dDemo.ObtenerProducto(productoRequest);

            var response = new Response<ProductoResponse>
            {
                Result = producto
            };

            return response;
        }

        public async Task<Response<bool>> RegistrarProducto(ProductoRequest productoRequest)
        {
            Response<bool> _response;
            ResultEntity _resultEntity;
            try
            {
                using (var transaction = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    _resultEntity = await _dDemo.RegistrarProducto(productoRequest);
                    transaction.Complete();
                }

                _response = new Response<bool>
                {
                    Status = _resultEntity.Result
                };
            }
            catch (Exception ex)
            {
                _response = new Response<bool>()
                {
                    Status = false,
                    Message = ex.Message
                };
            }
            return _response;
        }
    }
}
