﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Demo;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Demo;

namespace VIM.Api.Application.Services.Demo
{
    public interface IDemoAppService
    {
        Task<Response<bool>> RegistrarProducto(ProductoRequest productoRequest);
        Task<Response<bool>> ActualizarProducto(ProductoRequest productoRequest);
        Task<Response<ProductoResponse>> ObtenerProducto(ProductoRequest productoRequest);
        Task<Response<List<ProductoResponse>>> ListarProductos();

    }
}
