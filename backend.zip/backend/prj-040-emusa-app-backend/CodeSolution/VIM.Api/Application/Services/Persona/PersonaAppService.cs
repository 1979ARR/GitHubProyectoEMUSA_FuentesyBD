﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VIM.Api.Application.Services.Persona
{
    public class PersonaAppService : IPersonaAppService
    {

    }
}
