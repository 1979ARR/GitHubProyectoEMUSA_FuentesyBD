﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Application.Shared.TransferObject.Request.Indicadores;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Indicadores;

namespace VIM.Api.Application.Services.Indicadores
{
    public interface IIndicadoresAppService
    {
        Task<Response<dynamic>> ObtenerDatosERI(IndicadorERIRequest request);
        Task<Response<List<IndicadorERIResponse>>> ObtenerDatosTablaERI(IndicadorERIRequest request);
        Task<Response<IndicadorPUResponse>> ObtenerDatosPU(IndicadorPURequest request);
        Task<Response<IndicadorROResponse>> ObtenerDatosRO(IndicadorRORequest request);
        Task<Response<IndicadorCAResponse>> ObtenerDatosCA(IndicadorCARequest request);
        Task<Response<List<UsuarioInd>>> ListarUsuariosInd();
        Task<Response<dynamic>> ObtenerDatosFIFO(IndicadorFIFORequest request);
    }
}
