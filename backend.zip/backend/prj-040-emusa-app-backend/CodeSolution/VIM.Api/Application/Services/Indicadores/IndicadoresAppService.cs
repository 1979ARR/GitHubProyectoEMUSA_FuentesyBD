﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VIM.Api.Application.Repository.Indicadores;
using VIM.Application.Shared.TransferObject.Request.Indicadores;
using VIM.Application.Shared.TransferObject.Response;
using VIM.Application.Shared.TransferObject.Response.Indicadores;

namespace VIM.Api.Application.Services.Indicadores
{
    public class IndicadoresAppService : IIndicadoresAppService
    {
        private readonly IIndicadoresData _indicadoresData;
        public IndicadoresAppService(IConfiguration configuration)
        {
            _indicadoresData = new IndicadoresData(configuration.GetConnectionString("defaultConnection"));
        }
        public async Task<Response<dynamic>> ObtenerDatosERI(IndicadorERIRequest request)
        {
            dynamic result = null;
            switch (request.SubAlmacen)
            {
                case "MP":
                    result = await _indicadoresData.ObtenerDatosERIMP(request);
                    break;
                case "PP":
                    result = await _indicadoresData.ObtenerDatosERIPP(request);
                    break;
                case "PT":
                    result = await _indicadoresData.ObtenerDatosERIPT(request);
                    break;
            }

            var response = new Response<dynamic>
            {
                Result = result
            };

            return response;
        }
        public async Task<Response<List<IndicadorERIResponse>>> ObtenerDatosTablaERI(IndicadorERIRequest request)
        {
            List<IndicadorERIResponse> result = new List<IndicadorERIResponse>();
            switch (request.SubAlmacen)
            {
                case "MP":
                    result = await _indicadoresData.ObtenerDatosTablaERIMP(request);
                    break;
                case "PP":
                    result = await _indicadoresData.ObtenerDatosTablaERIPP(request);
                    break;
                case "PT":
                    result = await _indicadoresData.ObtenerDatosTablaERIPT(request);
                    break;
            }

            var response = new Response<List<IndicadorERIResponse>>
            {
                Result = result
            };

            return response;
        }
        public async Task<Response<IndicadorPUResponse>> ObtenerDatosPU(IndicadorPURequest request)
        {
            IndicadorPUResponse result = new IndicadorPUResponse();
            List<GlobalProduccion> lstProduccion = new List<GlobalProduccion>();
            GlobalProduccion itemProduccion = null;
            var data = await _indicadoresData.ObtenerDatosPU(request);

            for (var f = 0; f < 12; f++)
            {
                var item = data.Where(d => DateTime.ParseExact(d.Fecha, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture).Month == (f + 1)).ToList();

                itemProduccion = new GlobalProduccion();
                itemProduccion.Id = (f + 1);
                itemProduccion.Cantidad = item == null || item.Count == 0 ? 0 : item.Sum(i => i.Cantidad);
                itemProduccion.Items = item.OrderBy(i => Convert.ToInt32(i.Fecha.Split('-')[2])).ToList();
                lstProduccion.Add(itemProduccion);
            }

            result.ItemsProduccion = lstProduccion;

            var response = new Response<IndicadorPUResponse>
            {
                Result = result
            };

            return response;
        }

        public async Task<Response<IndicadorCAResponse>> ObtenerDatosCA(IndicadorCARequest request)
        {
            IndicadorCAResponse result = new IndicadorCAResponse();
            switch (request.Tipo)
            {
                case "MP":
                    result.MateriaPrima = await _indicadoresData.ObtenerDatosCAMP(request);
                    break;
                case "PP":
                    result.ProductosProceso = await _indicadoresData.ObtenerDatosCAPP(request);
                    break;
                case "PT":
                    result.ProductosTerminados = await _indicadoresData.ObtenerDatosCAPT(request);
                    break;
            }

            var response = new Response<IndicadorCAResponse>
            {
                Result = result
            };

            return response;
        }

        public async Task<Response<List<UsuarioInd>>> ListarUsuariosInd()
        {
            var result = await _indicadoresData.ListarUsuariosInd();
            var response = new Response<List<UsuarioInd>>
            {
                Result = result.OrderBy(u => u.Descripcion).ToList()
            };

            return response;
        }

        public async Task<Response<dynamic>> ObtenerDatosFIFO(IndicadorFIFORequest request)
        {
            dynamic result = null;
            switch (request.SubAlmacen)
            {
                case "MP":
                    result = await _indicadoresData.ObtenerDatosFIFOMP(request);
                    break;
                case "PP":
                    result = await _indicadoresData.ObtenerDatosFIFOPP(request);
                    break;
                case "PT":
                    result = await _indicadoresData.ObtenerDatosFIFOPT(request);
                    break;
            }

            var response = new Response<dynamic>
            {
                Result = result
            };

            return response;
        }

        public async Task<Response<IndicadorROResponse>> ObtenerDatosRO(IndicadorRORequest request)
        {
            IndicadorROResponse result = new IndicadorROResponse();
            List<GlobalRotacion> lstRotacion = new List<GlobalRotacion>();
            GlobalRotacion itemRotacion = null;
            var data = new List<ItemRotacion>();

            switch (request.SubAlmacen)
            {
                case "MP":
                    data = await _indicadoresData.ObtenerDatosROMP(request);
                    break;
                case "PP":
                    data = await _indicadoresData.ObtenerDatosROPP(request);
                    break;
                case "PT":
                    data = await _indicadoresData.ObtenerDatosROPT(request);
                    break;
            }

            for (var f = 0; f < 12; f++)
            {
                var item = data.Where(d => DateTime.ParseExact(d.Fecha, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture).Month == (f + 1)).ToList();

                itemRotacion = new GlobalRotacion();
                itemRotacion.Id = (f + 1);
                itemRotacion.Cantidad = item == null || item.Count == 0 ? 0 : item.Sum(i => i.Cantidad);
                itemRotacion.Items = item.OrderBy(i => Convert.ToInt32(i.Fecha.Split('-')[2])).ToList();
                lstRotacion.Add(itemRotacion);
            }

            result.ItemsRotacion = lstRotacion;

            var response = new Response<IndicadorROResponse>
            {
                Result = result
            };

            return response;
        }

    }
}
