using Autofac;
using Autofac.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Microsoft.Owin.Security.DataHandler.Encoder;
using System;
using System.Collections.Generic;
using VIM.Api.Controllers;
using VIM.Api.Infrastructure.AutofacModules;
using VIM.Api.Infrastructure.Filters;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using VIM.Cross.Proxy.Proxy;
using Serilog;
using VIM.Common.Shared.Constant;
using System.Text;
using Microsoft.AspNetCore.Http.Features;
using VIM.Api.Infrastructure.AssemblyContext;
using System.IO;

namespace VIM.Api
{
    public class Startup
    {
        readonly string CorsPolicy = IncomeWebApi.Cross.Cors;
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            services.AddCustomMvc(Configuration)
                .AddCustomSwagger(Configuration)
                .AddCustomConfiguration(Configuration)
                .AddProxyHttp()
                .AddCustomAuthentication(Configuration);

            services.Configure<FormOptions>(o => {
                o.ValueLengthLimit = int.MaxValue;
                o.MultipartBodyLengthLimit = int.MaxValue;
                o.MemoryBufferThreshold = int.MaxValue;
            });

            //Configure Autofac
            var container = new ContainerBuilder();
            container.Populate(services);
            container.RegisterModule(new MediatorModule());
            container.RegisterModule(new ApplicationModule(Configuration));
            return new AutofacServiceProvider(container.Build());

            
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            var pathBase = Configuration["PathBase"];

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();
            app.UseCors(CorsPolicy);
            app.UseHttpsRedirection();

            app.UseSwagger()
               .UseSwaggerUI(c =>
               {
                   c.SwaggerEndpoint($"{ (!string.IsNullOrEmpty(pathBase) ? pathBase : string.Empty) }/swagger/v1/swagger.json", "VIM.Api");
                   c.OAuthAppName("VIM Swagger UI");
               });

            ConfigureAuth(app);

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
                endpoints.MapControllers();
            });

        }

        protected virtual void ConfigureAuth(IApplicationBuilder app)
        {
            app.UseAuthentication();
            app.UseAuthorization();
        }

    }

    static class CustomExtensionsMethods
    {
        static string CorsPolicy = "_corsPolicy";
        public static IServiceCollection AddCustomMvc(this IServiceCollection services, IConfiguration configuration)
        {
            var CorsOriginAllowed = configuration.GetSection("AllowedOrigins").Get<List<string>>();
            var origins = CorsOriginAllowed != null ? CorsOriginAllowed.ToArray() : new string[] { "*" };

            Log.Information("Configurando Origenes para ({CORS})...", origins);
            services.AddCors(options =>
            {
                options.AddPolicy(CorsPolicy,
                    builder => builder
                    .SetIsOriginAllowed(origin => true)
                    .WithOrigins(origins)
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    .AllowCredentials()
                    );
            });
            Log.Information("Fin de Configuraci�n ({CORS})...");

            services.AddControllers(options =>
            {
                options.Filters.Add(typeof(HttpGlobalExceptionFilter));

            })
             .AddApplicationPart(typeof(BaseController).Assembly)
             .AddNewtonsoftJson()
             .AddControllersAsServices()
             .SetCompatibilityVersion(CompatibilityVersion.Version_3_0);

            services.AddSignalR();

            return services;
        }
        public static IServiceCollection AddCustomSwagger(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = $"HTTP API [{System.Net.Dns.GetHostName()}]",
                    Version = "v1",
                    Description = "Documentaci�n de los m�todos u operaciones del servicio.",
                    TermsOfService = null
                });


                options.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
                {

                    Type = SecuritySchemeType.ApiKey,
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Description = "Encabezado de autorizaci�n est�ndar utilizando el esquema de bearer (portador). Ejemplo: \"bearer {token}\"",

                });

                options.CustomSchemaIds(x => x.FullName);
                options.OperationFilter<AuthorizeCheckOperationFilter>();

            });

            return services;
        }
        public static IServiceCollection AddCustomConfiguration(this IServiceCollection services, IConfiguration configuration)
        {

            services.AddOptions();
            services.Configure<AppSettings>(configuration);
            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.InvalidModelStateResponseFactory = context =>
                {
                    var problemDetails = new ValidationProblemDetails(context.ModelState)
                    {
                        Instance = context.HttpContext.Request.Path,
                        Status = StatusCodes.Status400BadRequest,
                        Detail = "Consulte la propiedad de errores para obtener detalles adicionales."
                    };

                    return new BadRequestObjectResult(problemDetails)
                    {
                        ContentTypes = { "application/problem+json", "application/problem+xml" }
                    };
                };
            });

            return services;
        }
        public static IServiceCollection AddCustomAuthenticationExample(this IServiceCollection services, IConfiguration configuration)
        {
            var identityUrl = $"{configuration.GetValue<string>("Auth:AuthServiceUrl")}/Authorization/IsAuthorized";
            var audience = configuration.GetValue<string>("Auth:Audience");
            var iusser = configuration.GetValue<string>("Auth:Issuer");
            var secret = TextEncodings.Base64Url.Decode(configuration.GetValue<string>("Auth:Secret"));

            var signingKey = new SymmetricSecurityKey(secret);
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = signingKey,
                ValidateIssuer = true,
                ValidIssuer = iusser,
                ValidateAudience = true,
                ValidAudience = audience,
                ValidateLifetime = true,
                ClockSkew = TimeSpan.Zero,
                RequireExpirationTime = true,
            };

            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Remove("sub");

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;

            }).AddJwtBearer(options =>
            {
                options.RequireHttpsMetadata = false;
                options.TokenValidationParameters = tokenValidationParameters;

                options.Events = new JwtBearerEvents()
                {
                    //Evento para saber el detalle de un 401 (No Authorize), token invalido? token expirado?
                    OnAuthenticationFailed = context =>
                    {
                        if (context.Exception is SecurityTokenExpiredException expiredException)
                        {
                            context.Response.Headers.Add(Microsoft.Net.Http.Headers.HeaderNames.WWWAuthenticate,
                                new Microsoft.Extensions.Primitives.StringValues(new[] {
                                   JwtBearerDefaults.AuthenticationScheme,
                                   "error=\"invalid_token\"",
                                   "error_description=\"Token de acceso ha expirado\""
                                }));
                        }
                        return System.Threading.Tasks.Task.FromResult(0);
                    },
                    OnTokenValidated = context =>
                    {
                        return System.Threading.Tasks.Task.FromResult(0);
                    }
                };
            });

            return services;
        }
        public static IServiceCollection AddCustomAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            var key = Encoding.ASCII.GetBytes(configuration.GetValue<string>("Auth:Secret"));
            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
             .AddJwtBearer(options =>
             {
                 options.RequireHttpsMetadata = false;
                 options.SaveToken = true;
                 options.TokenValidationParameters = new TokenValidationParameters
                 {
                     ValidateIssuerSigningKey = true,
                     IssuerSigningKey = new SymmetricSecurityKey(key),
                     ValidateIssuer = false,
                     ValidateAudience = false
                 };
                 options.Events = new JwtBearerEvents()
                 {
                     //Evento para saber el detalle de un 401 (No Authorize), token invalido? token expirado?
                     OnAuthenticationFailed = context =>
                     {
                         if (context.Exception is SecurityTokenExpiredException expiredException)
                         {
                             context.Response.Headers.Add(Microsoft.Net.Http.Headers.HeaderNames.WWWAuthenticate,
                                 new Microsoft.Extensions.Primitives.StringValues(new[] {
                                   JwtBearerDefaults.AuthenticationScheme,
                                   "error=\"invalid_token\"",
                                   "error_description=\"Token de acceso ha expirado\""
                                 }));
                         }
                         return System.Threading.Tasks.Task.FromResult(0);
                     },
                     OnTokenValidated = context =>
                     {
                         return System.Threading.Tasks.Task.FromResult(0);
                     }
                 };
             });

            return services;
        }

    }

}
