﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Common.Shared.Constant
{
    public static class IncomeWebApi
    {
        public static class PrefixApi
        {
            public const string Demo = "api/Demo";
            public const string Seguridad = "api/Authentication";
            public const string Almacen = "api/Almacen";
            public const string Reporte = "api/Reporte";
            public const string Indicador = "api/Indicador";
        }

        public static class MethodApi
        {
            public static class Demo
            {
                public const string RegistrarProducto = "RegistrarProducto";
                public const string ActualizarProducto = "ActualizarProducto";
                public const string ObtenerProducto = "ObtenerProducto";
                public const string ListarProductos = "ListarProductos";
            }
            public static class Seguridad
            {
                public const string Login = "login";
                public const string ValidarSesion = "validarsesion";
            }
            public static class Almacen
            {
                public const string consultar = "consultar";
                public const string pendientesubicar = "pendientesubicar";
                public const string actualizarUbicacion = "actualizarUbicacion";
                public const string pendientesInventariar = "pendientesInventariar";
                public const string actualizarUbicacionInventario = "actualizarUbicacionInventario";
                public const string pendientesPickupOTBobinaApilador = "pendientesPickupOTBobinaApilador";
                public const string actualizarUbicacionPickingOTBobinaApilador = "actualizarUbicacionPickingOTBobinaApilador";
                public const string pendientesPickupOTBobinaStockero = "pendientesPickupOTBobinaStockero";
                public const string actualizarUbicacionPickingOTBobinaStokero = "actualizarUbicacionPickingOTBobinaStokero";
                public const string obtenerBobinasporSecuencialApp = "obtenerBobinasporSecuencialApp";
                public const string obtenerBobinasporSecuencialAppNI = "obtenerBobinasporSecuencialAppNI"; 
                public const string actualizarUbicacionInventarioSecuencialApp = "actualizarUbicacionInventarioSecuencialApp";
                public const string actualizarUbicacionSecuencialApp = "actualizarUbicacionSecuencialApp";

            }

            public static class Reporte
            {
                //Listado Linea
                public const string Linea = "Linea";
                //Listado Sublinea
                public const string Sublinea = "Sublinea";

                //Listado Mes Actual
                public const string MesActual = "MesActual";

                //Listado Anios
                public const string AniosxReporte = "AniosxReporte";

                //Listado Almacen
                public const string Almacen = "Almacen";

                //Pendientes por Ubicar
                public const string MateriaPrima = "MateriaPrima";
                public const string ProductosEnProceso = "ProductosEnProceso";
                public const string ProductosTerminados = "ProductosTerminados";
                
                //Kardex Bobina
                public const string KardexBobina = "KardexBobina";

                //Bobina con PNC
                public const string BobinaConPNC = "BobinaConPNC";

                //Desarrollo de Inventario
                public const string MateriaPrimaD = "MateriaPrimaD";
                public const string ProductosEnProcesoD = "ProductosEnProcesoD";
                public const string ProductosTerminadosD = "ProductosTerminadosD";

                //Proceso de Produccion
                public const string ProcesoDeProduccion = "ProcesoDeProduccion";

                //General
                public const string ExportarReporteGenerico = "ExportarReporteGenerico";
            }

            public static class Indicador
            {
                public const string ObtenerDatosERI = "ObtenerDatosERI";
                public const string ObtenerDatosTablaERI = "ObtenerDatosTablaERI";
                public const string ObtenerDatosFIFO = "ObtenerDatosFIFO";
                public const string ObtenerDatosPU = "ObtenerDatosPU";
                public const string ObtenerDatosCA = "ObtenerDatosCA";
                public const string ObtenerDatosRO = "ObtenerDatosRO";
                public const string ListarUsuariosInd = "ListarUsuariosInd";
            }

        }

        public static class Cross
        {
            public const string Cors = "_corsPolicy";
        }

    }
}
