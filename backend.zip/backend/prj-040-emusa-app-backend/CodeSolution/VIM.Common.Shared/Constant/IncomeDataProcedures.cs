﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Common.Shared.Constant
{
    public class IncomeDataProcedures
    {
        public static class Schema
        {
            public const string Dbo = "dbo";
            public const string Impor = "Impor";
            public const string Seguridad = "Seguridad";
        }

        public static class Package
        {
            public const string PkgDemo = "PKG_DEMO";
            public const string PkgMobileSeguridad = "PKG_MOBILE_SEGURIDAD";
            public const string PkgMobileAlmacen = "PKG_MOBILE_ALMACEN"; 
            public const string PkgWebReportes = "PKG_WEB_REPORTES";
        }

        public static class Procedure
        {
            public const string RegistrarProducto = "SP_INSERT_PRODUCT";
            public const string ActualizarProducto = "SP_UPDATE_PRODUCT";
            public const string ObtenerProducto = "SP_GET_PRODUCT";
            public const string ListarProductos = "SP_LIST_PRODUCTS";
            
            #region SEGURIDAD
            
            public const string ObtenerUsuario = "SP_VALIDATE_USER";

            #endregion

            #region ALMACEN
            public const string ListarMes = "SP_LISTADO_MES";
            public const string ListarAnios = "SP_LISTADO_ANIO";
            public const string ListarAlmacen = "SP_LISTAR_ALMACEN";
            public const string ObtenerBobina = "SP_GET_BOBINA";
            public const string ActualizarBobina = "SP_UPDATE_BOBINA";
            public const string ObtenerBobinaInventario = "SP_GET_BOBINA_INVENTARIO";
            public const string ActualizarBobinaInventario = "SP_UPDATE_BOBINA_INVENTARIO";

            public const string ObtenerBobinaInventarioStockero = "SP_GET_PICKINGOT_STOCKERO";
            public const string ActualizarBobinaInventarioStockero = "SP_UPDATE_PICKINGOT_STOCKERO";

            public const string ObtenerBobinaInventarioApilador = "SP_GET_PICKINGOT_APILADOR";
            public const string ActualizarBobinaInventarioApilador = "SP_UPDATE_PICKINGOT_APILADOR";

            public const string ObtenerBobinasporSecuencialApp = "SP_GET_BOBINA_POR_SECAPP";
            public const string ObtenerBobinasporSecuencialAppNI = "SP_GET_BOBINA_POR_SECAPP_NI"; 
            public const string ActualizarUbicacionInventarioSecuencialApp = "SP_UPDATE_SECAPP_INVENTARIO";
            public const string ActualizarUbicacionSecuencialApp = "SP_UPDATE_SECAPP_NI";
            #endregion

            #region REPORTES

            //Listado Linea
            public const string ListarLinea = "SP_LISTADO_LINEA";

            //Listado Sublinea
            public const string ListarSublinea = "SP_LISTADO_SUBLINEA";

            //Listado Almacen
            public const string ListarAlmacenC = "SP_LISTADO_ALMACEN_C";

            //Pendientes por Ubicar
            public const string ListarMateriaPrima = "SP_LISTADO_PENDIENTE_U_AMP";
            public const string ListarProductosEnProceso = "SP_LISTADO_PENDIENTE_U_APP";
            public const string ListarProductosTerminados = "SP_LISTADO_PENDIENTE_UBICAR";

            //Kardex Bobina
            public const string ListarKardexBobina = "SP_LISTADO_KARDEX_BOBINA";

            //Bobina con PNC
            public const string ListarBobinaConPNC = "SP_LISTADO_BOBINA_PNC";

            //Desarrollo de Inventario
            public const string ListarMateriaPrimaD = "SP_LISTADO_DESARROLLO_I_MP";
            public const string ListarProductosEnProcesoD = "SP_LISTADO_DESARROLLO_I_PP";
            public const string ListarProductosTerminadosD = "SP_LISTADO_DESARROLLO_I_PT";

            //Proceso de Produccion
            public const string ListarProcesoDeProduccion = "SP_LISTADO_PROCESO_PRODUCCION";
            #endregion

            #region EXPORTAR REPORTES

            //Pendientes por Ubicar
            public const string ListarMateriaPrimaExport = "SP_MATERIA_PRIMA_EXPORT";
            public const string ListarProductosEnProcesoExport = "SP_PROD_PROCESO_EXPORT";
            public const string ListarProductosTerminadosExport = "SP_PROD_TERMINADOS_EXPORT";

            //Kardex Bobina
            public const string ListarKardexBobinaExport = "SP_KARDEX_BOBINA_EXPORT";

            //Bobina con PNC
            public const string ListarBobinaConPNCExport = "SP_BOBINA_PNC_EXPORT";

            //Desarrollo de Inventario
            public const string ListarMateriaPrimaDExport = "SP_MATERIA_PRIMA_DI_EXPORT";
            public const string ListarProductosEnProcesoDExport = "SP_PROD_PROCESO_DI_EXPORT";
            public const string ListarProductosTerminadosDExport = "SP_PROD_TERMINADOS_DI_EXPORT";

            //Proceso de Produccion
            public const string ListarProcesoDeProduccionExport = "SP_PROCESO_PRODUCCION_EXPORT";

            #endregion

            #region INDICADORES

            public const string ObtenerIndicadorERIMP = "SP_OBTENER_IND_ERIMP";
            public const string ObtenerIndicadorTablaERIMP = "SP_OBTENER_INDTB_ERIMP";
            public const string ObtenerIndicadorTablaERIPP = "SP_OBTENER_INDTB_ERIPP";
            public const string ObtenerIndicadorTablaERIPT = "SP_OBTENER_INDTB_ERIPT";
            public const string ObtenerIndicadorERIPP = "SP_OBTENER_IND_ERIPP";
            public const string ObtenerIndicadorERIPT = "SP_OBTENER_IND_ERIPT";
            public const string ObtenerIndicadorPU = "SP_OBTENER_IND_PU";
            public const string ObtenerIndicadorROMP = "SP_OBTENER_IND_ROMP";
            public const string ObtenerIndicadorROPP = "SP_OBTENER_IND_ROPP";
            public const string ObtenerIndicadorROPT = "SP_OBTENER_IND_ROPT";
            public const string ObtenerIndicadorCAMP = "SP_OBTENER_IND_CAMP";
            public const string ObtenerIndicadorCAPP = "SP_OBTENER_IND_CAPP";
            public const string ObtenerIndicadorCAPT = "SP_OBTENER_IND_CAPT";
            public const string ObtenerUsuariosInd = "SP_OBTENER_IND_USUARIOS";
            public const string ObtenerDatosFIFOMP = "SP_OBTENER_IND_FIFOMP";
            public const string ObtenerDatosFIFOPP = "SP_OBTENER_IND_FIFOPP";
            public const string ObtenerDatosFIFOPT = "SP_OBTENER_IND_FIFOPT";

            #endregion

        }


    }
}
