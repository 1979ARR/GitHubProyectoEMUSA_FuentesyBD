﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.Exceptions
{
    public class VimDomainException : Exception
    {
        public VimDomainException()
        { }

        public VimDomainException(string message)
            : base(message)
        { }

        public VimDomainException(string message, Exception innerException)
            : base(message, innerException)
        { }
    }
}
