﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Demo
{
    public class ProductoResponse
    {
        public long IdProducto { get; set; }
        public string Nombre { get; set; }
        public decimal Precio { get; set; }
        public string FechaReg { get; set; }
    }

}
