﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Reportes
{
    public class KardexBobinaResponse
    {
        public Int64 TotalRegistros { get; set; }
        public IEnumerable<KardexBobinaResponseDetalle> KardexBobina { get; set; }
    }
    public class KardexBobinaResponseDetalle
    {
        public string id { get; set; }
        public string fechaGrabacion { get; set; }
        public string fechaOrden { get; set; }
        public int bobiCodigo { get; set; }
        public string bobiSerie { get; set; }
        public string ubifisiCodigo { get; set; }
        public string ubiAlmacenSerie { get; set; }
        public string unidadCodigo { get; set; }
        public string usuUltModif { get; set; }
        public double bobiPeso { get; set; }
        public double bobiPesoStock { get; set; }
        public int mitemCodigo { get; set; }
        public string descripcion { get; set; }
        public string almacenSerie { get; set; }
        public string bobiEstado { get; set; }
        public string linea { get; set; }
        public string sublinea { get; set; }
    }
}
