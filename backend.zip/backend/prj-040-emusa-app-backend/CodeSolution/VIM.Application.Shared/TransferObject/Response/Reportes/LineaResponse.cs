﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Reportes
{
    public class LineaResponse
    {
        public IEnumerable<LineaResponseDetalle> Linea { get; set; }
    }
    public class LineaResponseDetalle
    {
        public string LineaCodigo { get; set; }
        public string LineaDescripcion { get; set; }
    }
}
