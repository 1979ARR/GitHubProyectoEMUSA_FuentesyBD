﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Reportes
{
    public class ProductoTerminadoResponse
    {
        public Int64 TotalRegistros { get; set; }
        public IQueryable<ProductoTerminadoResponseDetalle> ProductosTerminados { get; set; }
    }
    public class ProductoTerminadoResponseDetalle
    {
        public string id { get; set; }
        public string tipo { get; set; }
        public string desc_tipo { get; set; }
        public string bobina_inventariada { get; set; }
        public string bobi_serie { get; set; } 
        public int bobi_codigo { get; set; }
        public double bobi_peso { get; set; }
        public double bobina_peso_bruto { get; set; }
        public string bobina_unidad_codigo { get; set; }
        public double bobina_longitud { get; set; }
        public int mitem_codigo { get; set; }
        public string unidad_codigo { get; set; }
        public string almacen_serie { get; set; }
        public string item_descripcio { get; set; }
        public string planta_serie { get; set; }
        public int hord_trab_secuencial { get; set; }
        public string descripcion_tamano { get; set; }
        public int mitem_gramaje { get; set; }
        public string unidad_equivalente { get; set; }
        public int cantidad_equivalente { get; set; }
        public string pedido { get; set; }
        public string cliente { get; set; }
        public string sucursal_descripcion { get; set; }
        public int hproc_secuencial { get; set; }
        public string condicion_codigo { get; set; }
        public string condicion_descripcion { get; set; }
        public string hproc_fecha_grab { get; set; }
        public string ubifisi_codigo { get; set; }
        public string bobi_fec_prod { get; set; }
        public int pagina { get; set; }
        public string fecha_hproc_orden { get; set; }
        public string fecha_prod_orden { get; set; }
    }

}
