﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Reportes
{
    public class SublineaResponse
    {
        public IEnumerable<SublineaResponseDetalle> Sublinea { get; set; }
    }
    public class SublineaResponseDetalle
    {
        public string LineaCodigo { get; set; }
        public string SublineaCodigo { get; set; }
        public string SublineaDescripcion { get; set; }
    }
}
