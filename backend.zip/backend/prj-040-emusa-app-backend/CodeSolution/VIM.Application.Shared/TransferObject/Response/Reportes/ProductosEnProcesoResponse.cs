﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Reportes
{
    public class ProductosEnProcesoResponse
    {
        public Int64 TotalRegistros { get; set; }
        public IQueryable<ProductosEnProcesoResponseDetalle> ProductosEnProceso { get; set; }
    }

    public class ProductosEnProcesoResponseDetalle
    {
        public string id { get; set; }
        public string almacen_serie { get; set; }
        public int bobi_codigo { get; set; }
        public string bobi_serie { get; set; }
        public double mitem_codigo { get; set; }
        public double bobi_peso { get; set; }
        public string unidad_codigo { get; set; }
        public double bobina_longitud { get; set; }
        public string bobi_fecha_ingreso { get; set; }
        public double bobina_peso_bruto { get; set; }
        public string bobina_inventariada { get; set; }
        public int hproc_secuencial { get; set; }
        public string condicion_codigo { get; set; }
        public int hord_trab_secuencial { get; set; }
        public int proceso_codigo { get; set; }
        public int maquina_codigo { get; set; }
        public string alm_serie_transfer { get; set; }
        public string dmot_codigo { get; set; }
        public string MOTIVO2 { get; set; }
        public string mot_devolucion { get; set; }
        public string item_descripcio { get; set; }
        public string unidad_equivalente { get; set; }
        public int cantidad_equivalente { get; set; }
        public string planta_serie { get; set; }
        public string codigo_transaccion { get; set; }
        public string causa_descripcion { get; set; }
        public int hped_numero { get; set; }
        public int situacion { get; set; }
        public string vendedor_nombre { get; set; }
        public string hproc_fecha_grab { get; set; }
        public string ubifisi_codigo { get; set; }
        public string bobi_fec_prod { get; set; }
        public string cod_naturaleza { get; set; }
        public string bobi_fec_leida { get; set; }
        public string fecha_ingreso_orden { get; set; }
        public string fecha_hproc_orden { get; set; }
        public string fecha_prod_orden { get; set; }
        public string fecha_leida_orden { get; set; }
    }
}
