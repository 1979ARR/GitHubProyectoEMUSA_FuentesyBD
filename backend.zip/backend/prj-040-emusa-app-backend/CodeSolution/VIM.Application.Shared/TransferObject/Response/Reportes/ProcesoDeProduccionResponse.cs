﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Reportes
{
    public class ProcesoDeProduccionResponse
    {
        public Int64 TotalRegistros { get; set; }
        public IEnumerable<ProcesoDeProduccionResponseDetalle> ProcesoProduccion { get; set; }
    }
    public class ProcesoDeProduccionResponseDetalle
    {
        public string id { get; set; }
        public string hproc_fecha_grab { get; set; }
        public string proceso_codigo { get; set; }
        public string maquina_codigo { get; set; }
        public string unidad_equivalente { get; set; }
        public int cantidad_equivalente { get; set; }
        public string planta_serie { get; set; }
        public string hord_trab_secuencial { get; set; }
        public string maquina_descripcion { get; set; }
        public string proceso_descripcion { get; set; }
        public double eproc_bobi_peso { get; set; }
        public string fecha_hproc_orden { get; set; }
    }  
}
