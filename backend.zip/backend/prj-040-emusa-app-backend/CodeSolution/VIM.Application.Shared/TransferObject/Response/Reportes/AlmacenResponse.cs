﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Reportes
{
    
    public class AlmacenResponse
    {
        public IEnumerable<AlmacenResponseDetalle> Almacen { get; set; }
    }
    public class AlmacenResponseDetalle
    {
        public string almacenSerie { get; set; }
        public string almacenNombre { get; set; }
    }
}
