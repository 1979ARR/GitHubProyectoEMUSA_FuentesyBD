﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Reportes
{
    public class MateriaPrimaResponse
    {
        public Int64 TotalRegistros { get; set; }
        public IEnumerable<MateriaPrimaResponseDetalle> MateriaPrima { get; set; }
    }
    public class MateriaPrimaResponseDetalle
    {
        public string id { get; set; }
        public string almacen_serie { get; set; }
        public string bobi_serie { get; set; }
        public int bobi_codigo { get; set; }
        public string ubi_almacen_serie { get; set; }
        public string ubi_subalmnum { get; set; }
        public string ubifisi_codigo { get; set; }
        public double bobi_peso { get; set; }
        public double bobi_peso_stock { get; set; }
        public int mitem_codigo { get; set; }
        public string item_descripcio { get; set; }
        public string unidad_codigo { get; set; }
        public string origen_descripcion { get; set; }
        public string linea_descripcion { get; set; }
        public string sublinea_descripcion { get; set; }
        public string bobi_fecha_ingreso { get; set; }
        public string flag { get; set; }
        public string hoia_secuencial { get; set; }
        public string trans_descripcion { get; set; }
        public string usu_ult_modif { get; set; }
        public string bobi_fec_ult_modif { get; set; }
        public string ubic_orig { get; set; }
        public string bobina_inventariada { get; set; }
        public string bobi_fec_leida { get; set; }
        public int bca_codigo { get; set; }
        public string bobi_observaciones { get; set; }
        public double ancho { get; set; }
        public double espesor { get; set; }
        public string bobi_fecha_salida { get; set; }
        public string fecha_ingreso_orden { get; set; }
        public string fecha_ult_orden { get; set; }
        public string fecha_leida_orden { get; set; }
        public string fecha_salida_orden { get; set; }
    }
}
