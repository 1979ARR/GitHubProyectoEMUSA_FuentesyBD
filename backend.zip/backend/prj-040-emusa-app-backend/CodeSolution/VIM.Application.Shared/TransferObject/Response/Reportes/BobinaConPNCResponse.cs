﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Reportes
{
    public class BobinaConPNCResponse
    {
        public Int64 TotalRegistros { get; set; }
        public IQueryable<BobinaConPNCResponseDetalle> BobinaConPNC { get; set; }
    }
    public class BobinaConPNCResponseDetalle
    {
        public string id { get; set; }
        public string almacen_serie { get; set; }
        public string bobi_serie { get; set; }
        public int bobi_codigo { get; set; }
        public double bobi_peso { get; set; }
        public double bobi_peso_stock { get; set; }
        public string hoia_fecha_oia { get; set; }
        public int hoia_secuencial { get; set; }
        public string codigo_transaccion { get; set; }
        public int porden_int_panasa { get; set; }
        public int mitem_codigo { get; set; }
        public string unidad_codigo { get; set; }
        public string bobina_inventariada { get; set; }
        public string desc_proveedor { get; set; }
        public string num_compra { get; set; }
        public string bobi_estado { get; set; }
        public string cc_result { get; set; }
        public int sec_pnc { get; set; }
        public int sec_pnc_tiempo { get; set; }
        public string ubi_almacen_serie { get; set; }
        public string ubi_subalmnum { get; set; }
        public string ubifisi_codigo { get; set; }
        public string bp_lote { get; set; }
        public string hcc_fecha_muestra { get; set; }
        public string fecha_emusa { get; set; }
        public string fecha_hoia_orden { get; set; }
        public string fecha_emusa_orden { get; set; }
        public string fecha_hcc_orden { get; set; }

    }
}
