﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Seguridad
{
    public class SeguridadResponse
    {
        public string Token { get; set; }
        public string ExpiracionToken { get; set; }
        public Usuario Usuario { get; set; }
        public List<Perfil> Perfil { get; set; }
        public List<Opciones> Opciones { get; set; }

    }
    public class Usuario
    {
        public string CodUser { get; set; }
        public string UserName { get; set; }
        public string NombreCompleto { get; set; }
    }
    public class Perfil
    {
        public string CodPerfil { get; set; }
        public string DescPerfil { get; set; }
    }
    public class Opciones
    {
        public string CodOpcion { get; set; }
        public string DescOpcion { get; set; }
    }
}
