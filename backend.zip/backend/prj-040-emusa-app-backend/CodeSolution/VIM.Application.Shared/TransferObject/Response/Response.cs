﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response
{
    public class Response<T>
    {
        public Response()
        {
        }

        public Response(bool status)
        {
            Status = status;
        }

        public Response(T result, int state, string message)
        {
            Result = result;
            State = state;
            Message = message;
        }

        public Response(T value)
        {
            Result = value;
        }

        public Response(bool status, T result) : this(status)
        {
            Result = result;
        }

        public Response(bool status, T result, string message) : this(status)
        {
            Result = result;
            Message = message;
        }

        public Response(bool status, T result, string message, int state) : this(status)
        {
            Result = result;
            Message = message;
            State = state;
        }

        public bool Status { get; set; } = true;
        public int State { get; set; } = 200;
        public string Message { get; set; } = "Ok";
        public T Result { set; get; }

    }
    public class ResultEntity
    {
        public bool Result { get; set; }
        public string Message { get; set; }
        public long IdGenerated { get; set; }
    }
    
    public class ResultList
    {
        public long TotalRegistros { get; set; }
    }
}
