﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Indicadores
{
    public class IndicadorPUResponse
    {
        public IndicadorPUResponse()
        {
            ItemsProduccion = new List<GlobalProduccion>();
        }
        public List<GlobalProduccion> ItemsProduccion { get; set; }
    }

    public class GlobalProduccion
    {
        public GlobalProduccion()
        {
            Items = new List<ItemProduccion>();
        }
        public int Id { get; set; }
        public int Cantidad { get; set; }
        public List<ItemProduccion> Items { get; set; }
    }

    public class ItemProduccion
    {
        public int Cantidad { get; set; }
        public string Fecha { get; set; }
    }

    public class UsuarioInd
    {
        public string Codigo { get; set; }
        public string Descripcion { get; set; }
    }

}
