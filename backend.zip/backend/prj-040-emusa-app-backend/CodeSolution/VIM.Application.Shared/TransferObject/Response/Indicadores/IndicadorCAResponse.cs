﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Indicadores
{
    public class IndicadorCAResponse
    {
        public ItemCAResponse MateriaPrima { get; set; }
        public ItemCAResponse ProductosProceso { get; set; }
        public ItemCAResponse ProductosTerminados { get; set; }
    }

    public class ItemCAResponse
    {
        public long LimiteVerde { get; set; }
        public long LimiteAmarillo { get; set; }
        public long LimiteRojo { get; set; }
        public decimal Valor { get; set; }
    }


}
