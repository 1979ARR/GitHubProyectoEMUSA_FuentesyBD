﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Indicadores
{
    public class IndicadorFIFOResponse
    {
        public decimal Valor1 { get; set; }
        public decimal Valor2 { get; set; }
        public decimal Valor3 { get; set; }
        public decimal Valor4 { get; set; }
        public decimal Valor5 { get; set; }
        public decimal Valor6 { get; set; }
    }
}
