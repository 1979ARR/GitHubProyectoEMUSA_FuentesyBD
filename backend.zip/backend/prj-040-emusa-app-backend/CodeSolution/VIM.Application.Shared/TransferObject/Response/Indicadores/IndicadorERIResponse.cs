﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Indicadores
{
    public class IndicadorERIResponse
    {
        public string OrigenDescripcion { get; set; }
        public string ClienteCodigo { get; set; }
        public string SucursalDescripcion { get; set; }
        public string UnidadCodigo { get; set; }
        public string LineaDescripcion { get; set; }
        public long Cantidad { get; set; }
        public decimal Peso { get; set; }
    }
}
