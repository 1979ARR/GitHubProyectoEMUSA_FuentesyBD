﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Indicadores
{
    public class IndicadorROResponse
    {
        public IndicadorROResponse()
        {
            ItemsRotacion = new List<GlobalRotacion>();
        }
        public List<GlobalRotacion> ItemsRotacion { get; set; }
    }

    public class GlobalRotacion
    {
        public GlobalRotacion()
        {
            Items = new List<ItemRotacion>();
        }
        public int Id { get; set; }
        public decimal Cantidad { get; set; }
        public List<ItemRotacion> Items { get; set; }
    }

    public class ItemRotacion
    {
        public decimal Cantidad { get; set; }
        public string Fecha { get; set; }
    }
}
