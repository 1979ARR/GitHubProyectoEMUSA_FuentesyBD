﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Almacen
{
    public class PendientesInventariarResponse
    {
        public Int32 TotalPendientesInventariar { get; set; }
        public Int32 TotalInventariado { get; set; }
 
    }
    
}
