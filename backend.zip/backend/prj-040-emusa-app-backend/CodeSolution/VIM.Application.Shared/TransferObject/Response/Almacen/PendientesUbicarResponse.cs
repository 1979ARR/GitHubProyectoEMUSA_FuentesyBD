﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Almacen
{
    public class PendientesUbicarResponse
    {
        public Int32 TotalRegistros { get; set; }
        public IEnumerable<PendientesUbicarResponseDetalle> PendientesUbicar { get; set; }
    }
    public class PendientesUbicarResponseDetalle {
        public string CodBobina { get; set; }
        public string CodItem { get; set; }
        public string DescBobina { get; set; }
        public string Peso { get; set; }
        public string UnidadMedida { get; set; }
        public string FecIngreso { get; set; }        
    }
}
