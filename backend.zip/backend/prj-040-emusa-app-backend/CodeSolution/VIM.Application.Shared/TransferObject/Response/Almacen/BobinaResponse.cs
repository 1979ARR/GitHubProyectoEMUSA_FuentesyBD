﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Almacen
{
    public class BobinaResponse
    {
    }
}
