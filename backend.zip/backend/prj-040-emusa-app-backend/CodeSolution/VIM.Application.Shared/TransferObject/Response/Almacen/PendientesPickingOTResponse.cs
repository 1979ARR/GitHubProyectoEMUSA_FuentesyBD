﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Almacen
{
    public class PendientesPickingOTResponse
    {
        public Int32 TotalRegistros { get; set; }
        public IEnumerable<PendientesPickingOTResponseDetalle> PendientesPickingOT { get; set; }
    }
    public class PendientesPickingOTResponseDetalle
    {
        public string Ubicacion { get; set; }
        public string CodBobina { get; set; }
        public string DescBobina { get; set; }
        public string Ot { get; set; }
        public string Peso { get; set; }
        public string UnidadMedida { get; set; }
        public string Cantidad { get; set; }
        public string Maquina { get; set; }
        public string FecIngreso { get; set; }
        public string CodItem { get; set; }
    }
}
