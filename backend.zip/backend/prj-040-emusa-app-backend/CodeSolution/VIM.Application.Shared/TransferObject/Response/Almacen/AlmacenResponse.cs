﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Response.Almacen
{
    public class AlmacenResponse
    {
        public string codAlmacen { get; set; }
        public string descAlmacen { get; set; }
    }
}
