﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Almacen
{
    public class PendientesUbicarRequest
    {
        public string CodAlmacen { get; set; }
        public string CodTipoProducto { get; set; }
    }
}
