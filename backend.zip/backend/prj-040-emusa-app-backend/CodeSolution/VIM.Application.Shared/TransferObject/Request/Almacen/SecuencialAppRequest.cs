﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Almacen
{
    public class SecuencialAppRequest
    {
        public string IdUsuario { get; set; }
        public string CodSecuencialApp { get; set; }
        public string CodUbicacion { get; set; }
        public string CodAlmacen { get; set; }
        public string CodTipoProducto { get; set; }
    }
}
