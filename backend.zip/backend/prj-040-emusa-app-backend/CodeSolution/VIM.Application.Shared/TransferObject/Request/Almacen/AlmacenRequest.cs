﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Almacen
{
    internal class AlmacenRequest
    {
    }
}
