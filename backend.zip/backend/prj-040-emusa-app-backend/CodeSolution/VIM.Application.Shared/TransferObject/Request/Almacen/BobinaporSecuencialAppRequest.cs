﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Almacen
{
    public class BobinaporSecuencialAppRequest
    {
        public string CodAlmacen { get; set; }
        public string CodTipoProducto { get; set; }
        public string CodSecuencialApp { get; set; }
    }
}
