﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Almacen
{
    public class BobinaRequest
    {
        public string IdUsuario { get; set; }
        public string CodBobina { get; set; }
        public string CodUbicacion { get; set; }
        public string CodAlmacen { get; set; }        
        public string CodTipoProducto { get; set; }
    }
}
