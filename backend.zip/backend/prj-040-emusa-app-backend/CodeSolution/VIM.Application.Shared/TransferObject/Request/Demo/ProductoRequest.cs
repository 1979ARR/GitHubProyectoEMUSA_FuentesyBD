﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Demo
{
    public class ProductoRequest
    {
        public long? IdProducto { get; set; }
        public string? Nombre { get; set; }
        public decimal? Precio { get; set; }
    }
}
