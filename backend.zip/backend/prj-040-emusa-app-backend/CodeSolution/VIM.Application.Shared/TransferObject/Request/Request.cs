﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request
{
    public class Request
    {
        
    }

    public class RequestList
    {
        public int NumeroPagina { get; set; }
        public int CantidadPagina { get; set; }
        public int ColumnaOrdenamiento { get; set; }
        public string DireccionOrdenamiento { get; set; }
    }
}
