﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Reportes
{
    public class MateriaPrimaRequest : RequestList
    {
        public string FechaDesde { get; set; }
        public string FechaHasta { get; set; }
        public string AlmacenSerie { get; set; }
        public string MitemCodigo { get; set; }
        public string BobiCodigo { get; set; }
        public string Linea { get; set; }
        public string SubLinea { get; set; }
        public string PeriodoMes { get; set; }
        public string PeriodoAnio { get; set; }
    }
}
