﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Reportes
{
    public class ProcesoDeProduccionRequest :RequestList
    {
        public string FechaDesde { get; set; }
        public string FechaHasta { get; set; }
        public string AlmacenSerie { get; set; }
        public int MitemCodigo { get; set; }
        public int BobiCodigo { get; set; }
        public string OrdenTrabajo { get; set; }
        public string PeriodoMes { get; set; }
        public string PeriodoAnio { get; set; }
    }
}
