﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Seguridad
{
    public class SeguridadRequest
    {
        public string UserName { get; set; }
        public string Password { get; set; }

    }
}
