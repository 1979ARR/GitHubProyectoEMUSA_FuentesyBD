﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Indicadores
{
    public class IndicadorRORequest
    {
        public string Almacen { get; set; }
        public string SubAlmacen { get; set; }
        public string Linea { get; set; }
        public string SubLinea { get; set; }
        public string Anio { get; set; }
    }
}
