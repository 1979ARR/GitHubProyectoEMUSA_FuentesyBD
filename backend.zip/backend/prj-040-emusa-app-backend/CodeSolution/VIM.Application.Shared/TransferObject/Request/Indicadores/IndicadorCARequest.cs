﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VIM.Application.Shared.TransferObject.Request.Indicadores
{
    public class IndicadorCARequest
    {
        public string Almacen { get; set; }
        public string Linea { get; set; }
        public string SubLinea { get; set; }
        public string Ubicacion { get; set; }
        public string Tipo { get; set; }
    }
}
